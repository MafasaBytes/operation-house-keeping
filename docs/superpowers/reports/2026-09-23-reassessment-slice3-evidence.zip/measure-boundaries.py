"""Slice 3 public capture/compute at previously approved structural boundaries."""
from pathlib import Path
import tempfile,time,json,resource,subprocess
from tests.reassessment_profile.test_capture import actual_case,files_for,capture
from applications.bounded_decision_workflow.reassessment_compute import compute
from applications.bounded_decision_workflow.measurement_wire import canonical_json_bytes as wire
root=Path(tempfile.mkdtemp(prefix='nr-slice3-boundaries-'));rows=[]
for name in ('P10-context8','P10-objects128','P5-conflict'):
 d=root/name;d.mkdir();c,p=actual_case(name);start=time.monotonic_ns();g=capture(*files_for(d,c,p));r,t=compute(g)
 rows.append(dict(case=name,summary=r['summary']['disposition'],logical=g.work.logical,physical=g.work.physical,result_bytes=len(wire(r)),trace_bytes=len(wire(t)),elapsed_ns=time.monotonic_ns()-start,peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024))
record=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),root=str(root),probes=rows)
(Path(__file__).parent/'boundary-measurements.json').write_bytes(wire(record));print(wire(record).decode())
