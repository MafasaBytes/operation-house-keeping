"""Reproducible Slice 1 measurement; no reassessment or prepared outcome computation."""
import base64
import json
from pathlib import Path
import resource
import subprocess
import tempfile
import time
import zipfile

from applications.bounded_decision_workflow.reassessment_build import identity
from applications.bounded_decision_workflow.reassessment_capture import capture
from applications.bounded_decision_workflow.measurement_wire import Work, sha, key, ref
from applications.bounded_decision_workflow.measurement_contracts import canonical_json_bytes as wire
from tests.reassessment_profile.test_capture import case, files_for, PACKAGE

destination=Path(__file__).parent/'candidate';destination.mkdir()
head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
w=Work();start=time.monotonic_ns();build=identity(w);elapsed=time.monotonic_ns()-start
(destination/'build.json').write_bytes(build)
rows=[]
with zipfile.ZipFile(PACKAGE) as z:
    for name in sorted(n for n in z.namelist() if n.startswith('cases/') and n.endswith('/closure.json')):
        ident=name.split('/')[1];closure=json.loads(z.read(name));iv=json.loads(z.read('cases/'+ident+'/invocation.json'))
        oldroot=key(closure['invocation']);oldbuild=key(iv['build']);iv['build']=ref('nr.build.v2',sha(build))
        raw=wire(iv);newroot=ref('nr.invocation.v2',sha(raw))
        objects={key(m['reference']):base64.b64decode(m['bytes'],validate=True) for m in closure['members']}
        objects.pop(oldroot);objects.pop(oldbuild);objects[key(newroot)]=raw;objects[key(iv['build'])]=build
        closure['invocation']=newroot
        closure['members']=[dict(reference=ref(*k),encoding='base64',bytes=base64.b64encode(v).decode()) for k,v in sorted(objects.items())]
        cwire=wire(closure);policy=z.read('cases/'+ident+'/policy.json')
        reserve=len(raw)+len(cwire)+len(build)+len(policy)+w.limits['result_bytes']+w.limits['trace_bytes']+w.limits['manifest_bytes']
        rows.append(dict(case=ident,build_bytes=len(build),closure_bytes=len(cwire),captured_bytes=sum(map(len,objects.values())),complete_bundle_upper_bound=reserve,
                         closure_fits=len(cwire)<=w.limits['closure_bytes'],bundle_fits=reserve<=w.limits['bundle_bytes']))
report=dict(head=head,build_sha256=sha(build),build_bytes=len(build),build_physical=w.physical,build_elapsed_ns=elapsed,
            peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
            kind='actual producer; static carriage and conservative retained fit, no computed reassessment output',cases=rows)
(destination/'capacity.json').write_bytes(wire(report))
root=Path(tempfile.mkdtemp(prefix='nr-slice1-candidate-measured-'));probes=[]
for name in ('P8-before','P7-newbaseline'):
    directory=root/name;directory.mkdir();c,objects=case(name)
    iv=json.loads(objects.pop(key(c['invocation'])));objects.pop(key(iv['build']))
    iv['build']=ref('nr.build.v2',sha(build));objects[key(iv['build'])]=build
    raw=wire(iv);c['invocation']=ref('nr.invocation.v2',sha(raw));objects[key(c['invocation'])]=raw
    args=files_for(directory,c,objects);start=time.monotonic_ns();g=capture(*args);duration=time.monotonic_ns()-start
    (destination/(name+'-closure.json')).write_bytes(g.closure_bytes)
    recovered=[]
    for files in g.prior_bundles.values():
        recovered.extend(dict(name=n,bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(files.items()))
    probes.append(dict(case=name,input_directory=str(directory),elapsed_ns=duration,peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
                       logical=g.work.logical,physical=g.work.physical,closure_sha256=sha(g.closure_bytes),prior_recovered=recovered))
(destination/'capture-work.json').write_bytes(wire(dict(head=head,probes=probes)))
print(wire(dict(head=head,build_bytes=len(build),build_sha256=sha(build),maxima=max(rows,key=lambda x:x['closure_bytes']),probes=probes)).decode())
