"""Same-author static cross-check, independently written from fixture assembly.

No application imports, build execution, permission assessment or runtime proof.
Public owning-model reconstruction is recorded separately, not impersonated here.
"""
import base64
import hashlib
import json
from fractions import Fraction as F
from pathlib import Path
import sys

def c(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sh(b):return hashlib.sha256(b).hexdigest()
def key(r):return r['kind'],r['sha256']
def references(x):
    if isinstance(x,dict):
        if set(x)=={'kind','sha256'}:yield x
        else:
            for y in x.values():yield from references(y)
    elif isinstance(x,list):
        for y in x:yield from references(y)
def rat(x):return F(int(x['numerator']),int(x['denominator']))
def in_decimal_domain(x):
    n=x.denominator
    for factor in [2,5]:
        while n%factor==0:n//=factor
    return n==1
def intersects(region,lo,hi):
    a=None if region['lower'] is None else rat(region['lower']);b=None if region['upper'] is None else rat(region['upper'])
    lower=max(lo,a) if a is not None else lo;upper=min(hi,b) if b is not None else hi
    if lower<upper:return True
    if lower>upper:return False
    return in_decimal_domain(lower) and (a is None or lower>a or region['lower_closed']) and (b is None or upper<b or region['upper_closed'])
def main(root):
    cases=json.loads((root/'cases.json').read_bytes());checks=[];allkeys=set()
    for case in cases:
        d=root/'cases'/case['id'];meta=json.loads((d/'input.json').read_bytes());pool={}
        for r in meta['members']:
            b=(root/'objects'/(r['sha256']+'.'+r['kind'])).read_bytes();assert sh(b)==r['sha256'];pool[key(r)]=b;allkeys.add(key(r))
        def get(r):return json.loads(pool[key(r)])
        iv=get(meta['invocation']);q=get(iv['request']);ni=get(q['original_invocation']);old=get(ni['request']);e1=get(get(q['observation'])['evidence'])
        assert len(pool)==len(meta['members']) and key(meta['invocation']) in pool
        ids={};edges={}
        for k,b in pool.items():
            if k[0]=='nm.basis':continue
            v=json.loads(b);assert c(v)==b
            ident=(k[0],v.get('id'),v.get('revision'))
            assert ident not in ids or ids[ident]==k[1],(case['id'],'identity collision',ident)
            ids[ident]=k[1];es=list(references(v))
            if k[0]=='nm.invocation.v1':es += [dict(kind='nm.build.v1',sha256=v['build_identity']),dict(kind='nm.resource-policy.v1',sha256=v['resource_policy'])]
            for r in es:assert key(r) in pool,(case['id'],'missing reference',r)
            edges[k]=[key(r) for r in es]
            if k[0].startswith('nr.') and k[0] not in ['nr.build.v2']:
                assert (v['revision']==1)==(v['predecessor'] is None)
                if v['predecessor']:
                    p=get(v['predecessor']);assert p['id']==v['id'] and p['schema']==v['schema'] and p['revision']==v['revision']-1
        active=set();done=set()
        def walk(k):
            assert k not in active,(case['id'],'cycle')
            if k in done:return
            active.add(k)
            for t in edges.get(k,[]):walk(t)
            active.remove(k);done.add(k)
        walk(key(meta['invocation']));assert done==set(pool)
        exp=case['expected'];assert get(iv['build'])['schema']=='nr.prepared-build.v2'
        x=F(case.get('x','60'));lo,hi=map(F,case['bounds']) if 'bounds' in case else (x,x)
        if exp['diagnostic'] and exp['diagnostic']['code']=='OBSERVATION_UNCERTAINTY_INCONSISTENT':assert not (lo<=x<=hi)
        if exp['exit']==0 and not case.get('observation_unavailable'):assert lo<=x<=hi
        checked_math=False
        if case['id'].startswith('P9-') and case['id']!='P9-retrospective':
            selected=get(q['procedure']);sources=[get(s) for s in old['support'] if get(s)['procedure']==q['procedure'] or get(get(s)['procedure'])['id']==selected['id']]
            mismatches=set()
            for source in sources:
                for field,target in [('procedure',q['procedure']),('decoder',q['decoder']),('context',old['context'])]:
                    if source[field]!=target:mismatches.add(field)
                assert source['hypothesis'] in old['hypotheses'] and source['evidence']==old['evidence']
            if case['id'] in ('P9-procedure','P9-decoder','P9-context'):assert mismatches=={case['id'][3:]},(case['id'],mismatches)
            else:assert not mismatches,(case['id'],mismatches)
        if exp['exit']==0:
            result=json.loads((d/'result.json').read_bytes());trace=json.loads((d/'trace.json').read_bytes())
            assert result['summary']['disposition']==exp['summary'] and result['adoption']=='derived_not_adopted'
            assert result['original']['hypotheses']==old['hypotheses'] and len(result['hypotheses'])==len(old['hypotheses'])
            assert result['original']['ranking']=='not_reassessed'
            if exp['branches'] is not None:
                dec=get(q['decoder']);bs=[o['id'] for o in dec['outcomes'] if intersects(o['region'],lo,hi)]
                assert bs==exp['branches'],(case['id'],'branch mismatch',bs,exp['branches'])
                assert bs==[b['outcome'] for b in result['interpretation']['branches']]
                for hr,expected in zip(old['hypotheses'],exp['states']):
                    if expected=='baseline_ineligible':continue
                    cells=[];ss=[get(s) for s in old['support'] if get(s)['hypothesis']==hr and get(s)['procedure']==q['procedure']]
                    for outcome in bs:
                        signs=set();unavailable=False
                        for s in ss:
                            if s['qualification']['status']=='unavailable':unavailable=True;continue
                            if outcome in s['permits']:signs.add('+')
                            if s['exclusion_basis'] and (outcome in s['excludes'] or s['coverage']=='complete_envelope' and outcome not in s['permits']):signs.add('-')
                        cells.append('?' if unavailable or len(signs)!=1 else next(iter(signs)))
                    conclusion='compatible' if set(cells)=={'+'} else 'incompatible' if set(cells)=={'-'} else 'unresolved'
                    assert conclusion==expected,(case['id'],conclusion,expected)
                checked_math=True
            manifest=json.loads((d/'manifest.json').read_bytes())
            for f in manifest['files']:
                b=(d/f['name']).read_bytes();assert len(b)==f['bytes'] and sh(b)==f['sha256']
            closure=json.loads((d/'closure.json').read_bytes());assert c(closure)==(d/'closure.json').read_bytes()
            assert {key(m['reference']):base64.b64decode(m['bytes'],validate=True) for m in closure['members']}==pool
            assert trace['required_closure']==meta['members']
        checks.append(dict(case=case['id'],canonical_hash_and_closure=True,mathematics_checked=checked_math,expected_exit=exp['exit']))
    return dict(schema='static-reassessment-preparation-check/v1',cases=len(cases),proof_groups=sorted(set(x['group'] for x in cases)),case_checks=checks,unique_referenced_objects=len(allkeys),application_executions=0,oracle_authorship='same author; separate arithmetic/source-table checker; not independent reviewer evidence')

if __name__=='__main__':
    root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
    result=main(root);print(json.dumps(result,sort_keys=True))
