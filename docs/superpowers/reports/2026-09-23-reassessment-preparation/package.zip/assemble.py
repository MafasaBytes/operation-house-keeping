"""Static fixture assembly. No application/backend imports or application execution.

Expected classifications are authored in cases.json, not learned from a selector.
Build slots are NONEXECUTABLE and require future mechanical build binding.
"""
import base64
import copy
import hashlib
import json
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROFILE = 'measurement-reassessment/v2'
def canon(v):
    return json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()
def sha(b): return hashlib.sha256(b).hexdigest()
def rr(n):
    f = Fraction(str(n)); return {'numerator': str(f.numerator), 'denominator': str(f.denominator)}
def putjson(p, v): p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(canon(v))
def refkey(r): return (r['kind'], r['sha256'])
def refs(v):
    if isinstance(v, dict):
        if set(v) == {'kind','sha256'}:
            yield v
        else:
            for x in v.values(): yield from refs(x)
    elif isinstance(v, list):
        for x in v: yield from refs(x)
def dims(v):
    stack=[(v,1)]; nodes=depth=string=0
    while stack:
        x,d=stack.pop(); nodes+=1; depth=max(depth,d)
        if isinstance(x,str): string=max(string,len(x.encode()))
        elif isinstance(x,dict):
            string=max([string]+[len(k.encode()) for k in x]);stack.extend((y,d+1) for y in x.values())
        elif isinstance(x,list): stack.extend((y,d+1) for y in x)
    return nodes,depth,string
def nr(kind, ident, **body):
    return dict(schema='nr.'+kind+'.v2', profile=PROFILE,id=ident,revision=1,predecessor=None,**body)

class Assembly:
    def __init__(self):
        w=json.loads((HERE/'authority/witness.json').read_bytes())
        self.original={refkey(m['reference']):base64.b64decode(m['bytes']) for m in w['members']}
        self.descriptor=w['descriptor'];self.pool=dict(self.original)
        self.original_by_id={json.loads(b).get('id'):json.loads(b) for k,b in self.pool.items() if k[0]!='nm.basis'}
        self.by_kind={k[0]:json.loads(b) for k,b in self.pool.items() if k[0]!='nm.basis'}
        self.basis=self.by_kind['nm.evidence.v1']['token_roles']['basis']
        self.original_i=self.by_kind['nm.invocation.v1']
        self.policy=self.add(self.by_kind['nm.resource-policy.v1'])
    def add(self,v,kind=None):
        b=canon(v);k=(kind or v['schema'],sha(b));self.pool[k]=b
        return dict(kind=k[0],sha256=k[1])
    def get(self,r):return json.loads(self.pool[refkey(r)])
    def evidence(self,x,ident='E1'):
        # Synthetic occurrence, not a replacement of the retained original.
        e=copy.deepcopy(self.by_kind['nm.evidence.v1']);e['id']=ident
        f=Fraction(x); outcome='satisfied' if f<=50 else 'violated'
        payload=b'{"result":{"eventtime":3721.845,"status":{"extruder":{"target":60,"temperature":'+x.encode()+b'}}}}'
        def rewrite(v):
            if isinstance(v,dict):
                if v.get('value_json')=='60.1':
                    v['value_json']=x
                    for k in ('occurrence_id','observation_id','raw_record_id','attempt_id'):
                        v[k]=sha(('synthetic-reassessment/'+x+'/'+k).encode())[:32]
                    # A local synthetic payload commitment, not recovered acquisition.
                    v['payload_checksum']='sha256:'+sha(payload)
                for y in v.values():rewrite(y)
            elif isinstance(v,list):
                for y in v:rewrite(y)
        rewrite(e['snapshot'])
        c=e['snapshot']['constraint_evaluations'][0]['candidates'][0]
        c['observed_decimal']=x;c['verdict']=outcome
        c['boundary_assessments'][0].update(relation='below' if f<50 else 'equal' if f==50 else 'above',satisfied=f<=50)
        e['snapshot']['conditions'][0]['outcome']=outcome
        e['snapshot']['computed_match']='matches' if f<=50 else 'does_not_match'
        pd=HERE/'synthetic-payloads';pd.mkdir(exist_ok=True);(pd/(sha(payload)+'.json')).write_bytes(payload)
        return self.add(e)
    def original_graph(self,case):
        if case.get('accepted_prior'):
            return self.add(self.original_i)
        q=copy.deepcopy(self.by_kind['nm.request.v1']);q['id']='Q-'+case['id']
        if case.get('coherent_context') or case.get('substitute')=='context':q['context']=dict(q['context'],scenario_label='revised-context')
        if case.get('baseline_unavailable'):
            e=copy.deepcopy(self.by_kind['nm.evidence.v1']);e['id']='E0-unavailable';e['snapshot']=json.loads((HERE/'authority/snapshot-unavailable-same-model.json').read_bytes());q['evidence']=self.add(e)
        if case.get('revised_baseline'):q['evidence']=self.evidence('80','E0-revised')
        h=[copy.deepcopy(self.original_by_id[x]) for x in ('H1','H2')]
        for i,x in enumerate(h):
            x['evidence']=q['evidence']
            x['context']=q['context']
            if i+1 in case.get('baseline_ineligible',[]): x['requirements'][0]['expected']=rr(80)
            if case.get('baseline_ineligible'):x['revision']=2
            if case.get('revised_baseline'):
                x['revision']=3
                if i==1:x['requirements'][0]['expected']=rr(80)
        hs=[self.add(x) for x in h];q['hypotheses']=hs
        o=copy.deepcopy(self.original_by_id['O1']);o['revision']=2
        if case.get('coherent_decoder') or case.get('substitute')=='decoder':o['revision']=3
        intervals=[('H',50,70,False,True),('L',None,50,False,True),('X',70,None,False,False)]
        if 'singleton' in case:
            n=case['singleton'];intervals=[('A',None,n,False,False),('B',n,n,True,True),('C',n,None,False,False)]
        o['outcomes']=[dict(id=i,region=dict(kind='interval',lower=None if l is None else rr(l),upper=None if u is None else rr(u),lower_closed=lc,upper_closed=uc)) for i,l,u,lc,uc in intervals]
        if case.get('decoder_fault')=='gap':o['outcomes'][1]['region']['upper_closed']=False
        if case.get('decoder_fault')=='overlap':o['outcomes'][0]['region']['lower_closed']=True
        if case.get('decoder_fault')=='remote_gap':o['outcomes'][2]['region']['lower']=rr(71)
        ore=self.add(o)
        p=copy.deepcopy(self.original_by_id['T1']);p['revision']=2;p['decoder']=ore;p['evidence']=q['evidence'];p['context']=q['context']
        if case.get('revised_baseline'):p['revision']=3
        if case.get('original_inapplicable'):p['conditions'][0]['state']='false'
        if case.get('substitute')=='procedure' or case.get('coherent_procedure'):p['method_edition']=2;p['revision']=3
        pr=self.add(p);other=copy.deepcopy(self.original_by_id['T2']);other['evidence']=q['evidence'];other['context']=q['context'];q['measurements']=[pr,self.add(other)]
        if case.get('revised_baseline'):other['revision']=2;q['measurements'][1]=self.add(other)
        sources=[]
        for i,sid in enumerate(('S1','S2','S3','S4')):
            s=copy.deepcopy(self.original_by_id[sid]);s['revision']=3 if case.get('predecessor_case') else 2;s['hypothesis']=hs[0 if i<2 else 1];s['evidence']=q['evidence'];s['context']=q['context']
            if i in (1,3):s['procedure']=q['measurements'][1]
            if i in (0,2):
                s['procedure']=pr;s['decoder']=ore;s['coverage']='explicit_exclusions';s['exclusion_basis']=self.basis
                if 'singleton' in case:
                    s['permits']=['A'] if i==0 else ['B','C'];s['excludes']=['B','C'] if i==0 else ['A']
                else:s['permits']=['H'] if i==0 else ['L'];s['excludes']=['L','X'] if i==0 else ['H','X']
                mode=case.get('support')
                if mode=='missing_X' and i==0:s['excludes'].remove('X')
                if mode=='positive_only':s['excludes']=[];s['exclusion_basis']=[];s['coverage']='partial_positive'
                if mode=='missing_L' and i==0:s['excludes'].remove('L')
                if mode=='unavailable' and i==0:s['qualification']={'status':'unavailable','reason':'missing_support'}
                if mode=='multiple':s['permits']=['H','L'];s['excludes']=['X']
                if mode=='all_excluded' and i==0:s['permits']=[];s['excludes']=['H','L','X']
                if mode=='retrospective':s['permits']=['X'];s['excludes']=['H','L']
                if case.get('substitute')=='procedure':s['procedure']=self.add(dict(p,revision=2,method_edition=1))
                if case.get('substitute')=='decoder':s['decoder']=self.add(dict(o,revision=2))
                if case.get('substitute')=='context':s['context']=self.by_kind['nm.request.v1']['context']
            sources.append(self.add(s))
        if case.get('support')=='conflict':
            s=copy.deepcopy(self.get(sources[0]));s['id']='S-opposing';s['permits']=['X'];s['excludes']=[];s['exclusion_basis']=[];s['coverage']='partial_positive';sources.append(self.add(s))
        q['support']=sorted(sources,key=lambda r:self.get(r)['id'])
        qr=self.add(q)
        d=copy.deepcopy(self.by_kind['nm.declaration.v1']);d['id']='D-'+case['id'];d['requests']=[qr]
        for index in range(case.get('extra_contexts',0)):
            d['requests'].append(self.add(dict(q,id='Q-extra-'+str(index))))
        d['requests'].sort(key=refkey)
        a=copy.deepcopy(self.by_kind['nm.selection.v1']);a['id']='A-'+case['id'];a['request']=qr;a['declaration']=self.add(d)
        iv=copy.deepcopy(self.original_i);iv['id']='I-'+case['id'];iv['request']=qr;iv['selection']=self.add(a)
        return self.add(iv)
    def make(self,case):
        previous=None
        if case.get('predecessor_case'):
            pc=next(c for c in json.loads((HERE/'cases.json').read_bytes()) if c['id']==case['predecessor_case'])
            pa=Assembly();pv=pa.make(pc);self.pool.update(pv['objects']);previous=json.loads(pv['objects'][refkey(pv['root'])])['request']
        ir=self.original_graph(case);iv=self.get(ir);q=self.get(iv['request']);pr=q['measurements'][1 if case.get('literal') else 0];o=self.get(pr)['decoder']
        er=self.evidence(case.get('x','60'))
        if case.get('observation_unavailable'):
            e=self.get(er);e['snapshot']=json.loads((HERE/'authority/snapshot-unavailable-same-model.json').read_bytes());er=self.add(e)
        provenance=list(self.basis)
        for i in range(case.get('extra_basis',0)):
            b=('Individually declared synthetic provenance premise '+str(i)).encode();k=('nm.basis',sha(b));self.pool[k]=b;provenance.append(dict(kind=k[0],sha256=k[1]))
        ob=self.add(nr('observation','OBS-'+case['id'],evidence=er,procedure=pr,decoder=o,provenance=sorted(provenance,key=refkey)))
        execution=nr('execution','EXEC-'+case['id'],observation=ob,original_context=q['context'],result_context=q['context'],
            acquisition=dict(state='known',start='2026-08-07T20:00:04Z',end='2026-08-07T20:00:06Z',basis=self.basis),
            conditions=[dict(id=i,state='unknown' if case.get('hold_unknown') and i=='hold' else 'false' if case.get('hold_false') and i=='hold' else 'true',basis=self.basis) for i in ['applicability','availability','calibration','fidelity','hold']])
        if case.get('acquisition_unknown'):execution['acquisition'].update(state='unknown',start=None,end=None)
        if case.get('acquisition_inconsistent'):execution['acquisition']['end']='2026-08-07T20:00:07Z'
        ex=self.add(execution)
        relation=case.get('relation','unknown');before=relation=='predictions_before_learning_result'
        exposure=nr('exposure','EXPOSURE-'+case['id'],original_invocation=ir,observation=ob,prior_bundle=self.descriptor if case.get('accepted_prior') and not case.get('omit_prior') else None,
            declared_relation=relation,declared_prediction_commitment_at=None if relation=='unknown' else '2026-08-07T19:00:00Z' if before else '2026-08-07T21:00:00Z',
            declared_first_learned_at=None if relation=='unknown' else '2026-08-07T20:00:00Z',basis=self.basis)
        if case.get('exposure_inconsistent'):exposure['declared_prediction_commitment_at']='2026-08-07T22:00:00Z'
        if case.get('null_chronology_times'):exposure.update(declared_prediction_commitment_at=None,declared_first_learned_at=None)
        if case.get('unknown_chronology_times'):exposure.update(declared_prediction_commitment_at='2026-08-07T19:00:00Z',declared_first_learned_at='2026-08-07T20:00:00Z')
        xr=self.add(exposure)
        policy=self.add(nr('policy','INTERPRETATION',qualification='supplied_support/v1',envelope_rule='all_intersecting_branches/v1',baseline_rule='frozen_baseline_first/v1',adoption='manual_only',exposure_rule='local_declarations_not_custody/v1'))
        unit=self.get(er)['binding']['expected_unit']
        if case.get('wrong_unit'):unit=dict(unit,code='degree_fahrenheit')
        u=dict(kind=case.get('uncertainty','declared_point'),lo=None,hi=None,unit=unit,basis=self.basis)
        if 'bounds' in case:u.update(kind='hard_interval',lo=rr(case['bounds'][0]),hi=rr(case['bounds'][1]))
        request=nr('request','REASSESS',original_invocation=ir,original_selection_pin=iv['selection']['sha256'],procedure=pr,decoder=o,observation=ob,execution=ex,exposure=xr,interpretation=u,policy=policy)
        if case.get('wrong_original_pin'):request['original_selection_pin']='0'*64
        if case.get('wrong_result_pin'):request['original_selection_pin']='ffe2d69909e356914bafcd04eabf8c1b9a96ee05243a66abdc1d2e6086eab402'
        if previous:request.update(revision=2,predecessor=previous)
        qr=self.add(request)
        for revision in range(2,case.get('history',1)+1):
            request=dict(request,revision=revision,predecessor=qr);qr=self.add(request)
        ar=self.add(nr('authority','PERMISSION',request=qr,purpose='result_reassessment',permission=case.get('permission','true'),attestor_label='local-static-fixture-author',basis=self.basis))
        # Explicitly nonexecutable slot. Never a production-valid build witness.
        build=copy.deepcopy(self.by_kind['nm.build.v1'])
        build.update(schema='nr.prepared-build.v2',profile=PROFILE,id='BUILD-SLOT',predecessor=None,status='prepared_not_executable',binding='historical_nm_manifest_for_sizing_only_replace_from_future_actual_nr_identity',supported_nm_contract_sha256=self.by_kind['nm.build.v1']['contract_sha256'])
        br=self.add(build)
        invocation=nr('invocation','ASSESS',request=qr,authority=ar,build=dict(kind='nr.build.v2',sha256=br['sha256']),resource_policy=self.policy)
        root=self.add(invocation)
        # The build slot has the required filename but intentionally refuses as a
        # prepared witness until future executable binding replaces it.
        self.pool[('nr.build.v2',br['sha256'])]=self.pool[refkey(br)]
        found={};incoming=[];stack=[root]
        while stack:
            r=stack.pop();k=refkey(r)
            if k in found:continue
            b=self.pool[k];found[k]=b
            if k[0]=='nm.basis':continue
            v=json.loads(b);edges=list(refs(v))
            if k[0]=='nm.invocation.v1':edges += [dict(kind='nm.build.v1',sha256=v['build_identity']),dict(kind='nm.resource-policy.v1',sha256=v['resource_policy'])]
            for t in edges:incoming.append(dict(source=r,target=t))
            stack.extend(edges)
        pin='0'*64 if case.get('wrong_external_pin') else ar['sha256']
        closure=dict(schema='nr.closure.v2',profile=PROFILE,invocation=root,authority_pin=pin,limits_override=None,
            members=[dict(reference=dict(kind=k[0],sha256=k[1]),encoding='base64',bytes=base64.b64encode(b).decode()) for k,b in sorted(found.items())])
        return dict(case=case,root=root,pin=pin,objects=found,closure=closure,edges=incoming,request=request,observation=self.get(ob),evidence=self.get(er),original=q,original_i=iv,authority=ar,build=build)

def main():
    cases=json.loads((HERE/'cases.json').read_bytes());measurements=[]
    for case in cases:
        a=Assembly();v=a.make(case);dest=HERE/'cases'/case['id'];dest.mkdir(parents=True,exist_ok=True)
        for k,b in v['objects'].items():
            p=HERE/'objects'/(k[1]+'.'+k[0]);p.parent.mkdir(exist_ok=True)
            if p.exists():assert p.read_bytes()==b
            else:p.write_bytes(b)
        putjson(dest/'input.json',dict(invocation=v['root'],authority_pin=v['pin'],members=[dict(kind=k[0],sha256=k[1]) for k in sorted(v['objects'])],
            binding_status='nonexecutable_build_slot_requires_future_binding'))
        putjson(dest/'expected.json',case['expected'])
        sizes=[len(b) for b in v['objects'].values()]
        parsed=[json.loads(b) for k,b in v['objects'].items() if k[0]!='nm.basis']
        role_keys={refkey(f['source']['reference']) for x in parsed if x.get('schema')=='nr.retained-bundle.v2' for f in x['files'] if 'reference' in f['source'] and f['source']['reference']['kind']=='nm.basis'}
        dimensions=[dims(x) for x in parsed]+[dims(json.loads(v['objects'][k])) for k in sorted(role_keys)]
        closure_bytes=len(canon(v['closure']));buildbytes=len(canon(v['build']))
        measurements.append(dict(case=case['id'],unique_objects=len(sizes),capture_bytes=sum(sizes),object_bytes=max(sizes),closure_bytes=closure_bytes,
            reference_occurrences=len(v['edges']),context_scan_edge_bytes=sum(len(v['objects'][refkey(e['source'])])+len(v['objects'][refkey(e['target'])])+66 for e in v['edges']),
            json_nodes=sum(d[0] for d in dimensions),json_depth=max(d[1] for d in dimensions),string_bytes=max(d[2] for d in dimensions),
            new_build_slot_bytes=buildbytes,closure_with_maximum_build_reserve=closure_bytes-4*((buildbytes+2)//3)+4*((65536+2)//3),
            prior_reconstructed_bytes=232849 if case.get('accepted_prior') and not case.get('omit_prior') else 0,
            evidence_snapshot_bytes=len(canon(v['evidence']['snapshot'])),history=max([x['revision'] for x in parsed if x.get('schema')=='nr.request.v2']),request_contexts=sum(x.get('schema') in ('nr.request.v2','nm.request.v1') for x in parsed)))
        outputs(v,dest,measurements[-1])
    putjson(HERE/'input-measurements.json',measurements)
    print(json.dumps({'cases':len(cases),'maxima':{k:max(r[k] for r in measurements) for k in measurements[0] if k!='case'}},sort_keys=True))

def outputs(v,dest,m):
    """Serialize hand-authored expected meanings; no calls to application logic."""
    c=v['case'];expect=c['expected'];q=v['original'];basis=v['evidence']['token_roles']['basis']
    if expect['diagnostic']:
        d=expect['diagnostic'];resource=None
        if expect['exit']==4:resource=c.get('resource_expectation',dict(dimension='request_chain',attempted=5,limit=4))
        diagnostic=dict(schema='nr.diagnostic.v2',code=d['code'],stage='phase_'+str(d['phase']),target=dict(request=json.loads(v['objects'][refkey(v['root'])])['request'],field=d['path'],logical_id=None,references=[],occurrence_count=None),resource=resource,retry='reduce_input_or_request_policy_review' if resource else 'correct_input',bundle_state='absent',message_key=d['code'].lower())
        if d['code'] in ('DECODER_INVALID','SUPPORT_SUBJECT_MISMATCH','ROW_ALL_EXCLUDED'):
            diagnostic['target']['request']=v['original_i']['request']
            if d['code']=='DECODER_INVALID':diagnostic['target']['references']=[v['request']['decoder']]
            if d['code']=='ROW_ALL_EXCLUDED':diagnostic['target']['references']=sorted([q['hypotheses'][0],v['request']['procedure']],key=refkey)
            if d['code']=='SUPPORT_SUBJECT_MISMATCH' and c.get('substitute') in ('procedure','decoder'):
                sr=q['support'][0];s=json.loads(v['objects'][refkey(sr)]);field=c['substitute'];actual=v['request'][field]
                diagnostic['target']['references']=sorted([sr,s[field],actual],key=refkey)
        (dest/'stderr.expected').write_bytes(canon(diagnostic)+b'\n');(dest/'stdout.expected').write_bytes(b'')
        m.update(result_bytes=0,trace_bytes=0,manifest_bytes=0,bundle_bytes=0,bundle_with_maximum_build_and_manifest_reserves=0,diagnostic_bytes=len(canon(diagnostic))+1,receipt_bytes=0)
        return
    states=expect['states'];B=expect['branches'];x=Fraction(c.get('x','60'))
    lo,hi=map(Fraction,c['bounds']) if 'bounds' in c else (x,x)
    chronology={'unknown':'exposure_unknown','predictions_before_learning_result':'declared_pre_exposure_unverified','predictions_after_learning_result':'declared_retrospective'}[c.get('relation','unknown')]
    evidence=v['evidence']
    def findocc(t):
        if isinstance(t,dict):
            if 'occurrence_id' in t and t.get('property',{}).get('json_pointer','').endswith('/temperature'):return t
            for y in t.values():
                r=findocc(y)
                if r:return r
        elif isinstance(t,list):
            for y in t:
                r=findocc(y)
                if r:return r
    occur=findocc(evidence['snapshot']) or dict(occurrence_id=None,raw_record_id=None,payload_checksum=None,received_at=None)
    def get(r):return json.loads(v['objects'][refkey(r)])
    decoder=get(v['request']['decoder'])
    branches=[]
    for label in B or []:
        region=next(o['region'] for o in decoder['outcomes'] if o['id']==label)
        def f(r):return None if r is None else Fraction(int(r['numerator']),int(r['denominator']))
        l,u=f(region['lower']),f(region['upper']);l2=lo if l is None else max(lo,l);u2=hi if u is None else min(hi,u)
        branches.append(dict(outcome=label,intersection=dict(lo=rr(l2),hi=rr(u2),lower_closed=l is None or l2>l or region['lower_closed'],upper_closed=u is None or u2<u or region['upper_closed'])))
    status={'compatible':'compatible_under_declared_model','incompatible':'conditionally_incompatible','unresolved':'unresolved','baseline_ineligible':'baseline_ineligible','not_assessed':'not_assessed'}
    rows=[]
    for i,(hr,state) in enumerate(zip(q['hypotheses'],states)):
        h=get(hr);checks=[] if state=='not_assessed' else [dict(id='baseline',expected=h['requirements'][0]['expected'],actual=rr('80' if c.get('revised_baseline') else '60.1'),status='contradicted' if state=='baseline_ineligible' else 'satisfied'),dict(id='criterion',expected='violated',actual='violated',status='satisfied')]
        cells=None
        if B is not None and state!='baseline_ineligible':
            sources=sorted([r for r in q['support'] if get(r)['hypothesis']==hr and get(r)['procedure']==v['request']['procedure']],key=refkey)
            cells=[]
            for label in B:
                # Literal fixture truth table. The independent checker separately
                # checks set intersections and compares each supplied source.
                positive=label in (['H','high','A'] if i==0 else ['L','low','B','C'])
                relation='permits' if positive else 'excludes';reasons=[]
                if c.get('support')=='multiple':relation='permits' if label in ['H','L'] else 'excludes'
                if c.get('support')=='retrospective':relation='permits' if label=='X' else 'excludes'
                if c.get('support')=='positive_only' and not positive:relation='unknown';reasons=['missing_exclusion_support']
                if i==0 and c.get('support')=='missing_X' and label=='X':relation='unknown';reasons=['missing_exclusion_support']
                if i==0 and c.get('support')=='conflict' and label=='X':relation='unknown';reasons=['opposing_qualified_sources']
                if i==0 and c.get('support')=='unavailable':relation='unknown';reasons=['missing_support']
                cells.append(dict(outcome=label,relation=relation,sources=sources,reasons=[dict(code=r,path='/support',references=sources) for r in reasons]))
        rows.append(dict(reference=hr,baseline='not_assessed' if state=='not_assessed' else 'baseline_ineligible' if state=='baseline_ineligible' else 'baseline_eligible',baseline_checks=None if state=='not_assessed' else checks,status=status[state],outcome_state='not_assessed_baseline_ineligible' if state=='baseline_ineligible' else 'assessed' if B is not None else 'not_assessed',cells=cells,reasons=[]))
        if state=='unresolved' and cells:
            reasons=[r for cell in cells for r in cell['reasons']]
            if not reasons:reasons=[dict(code='mixed_permit_exclude',path='/hypotheses/'+h['id']+'/cells',references=sources)]
            rows[-1]['reasons']=sorted({canon(r):r for r in reasons}.values(),key=lambda r:(r['code'],r['path'],canon(r['references'])))
    exposure=get(v['request']['exposure'])
    output=dict(schema='nr.result.v2',profile=PROFILE,invocation=v['root'],authority=dict(reference=v['authority'],pin=v['pin'],permission=c.get('permission','true')),
        original=dict(invocation=v['request']['original_invocation'],request=v['original_i']['request'],procedure=v['request']['procedure'],decoder=v['request']['decoder'],evidence=q['evidence'],hypotheses=q['hypotheses'],ranking='not_reassessed'),
        observation=dict(reference=v['request']['observation'],evidence=v['observation']['evidence'],availability='admitted',scalar=rr(x),occurrence_id=occur['occurrence_id'],raw_record_id=occur['raw_record_id'],payload_checksum=occur['payload_checksum'],unit=evidence['binding']['expected_unit'],received_at=occur['received_at'],as_of=evidence['question']['as_of'],reasons=[]),
        interpretation=dict(state='assessed' if B is not None else 'not_assessed',envelope=dict(lo=rr(lo),hi=rr(hi),lower_closed=True,upper_closed=True,basis_kind='declared_hard_interval' if 'bounds' in c else 'declared_point_assumption',basis=basis) if c.get('uncertainty') not in ('unknown','confidence_only') else None,branches=branches if B is not None else None,reasons=[]),
        exposure=dict(reference=v['request']['exposure'],content_relationship='prior_bundle_integrity_and_reference_verified' if exposure['prior_bundle'] else 'original_closure_verified',chronology=chronology,declared_prediction_commitment_at=exposure['declared_prediction_commitment_at'],declared_first_learned_at=exposure['declared_first_learned_at'],changed_references=[],limitation='Content and declared dependency relationships verified; chronology is locally declared and unverified. No independent pre-exposure custody or predictive-validation claim.'),
        hypotheses=rows,summary=dict(disposition=expect['summary'],compatible=sorted([r for r,s in zip(q['hypotheses'],states) if s=='compatible'],key=refkey),incompatible=sorted([r for r,s in zip(q['hypotheses'],states) if s=='incompatible'],key=refkey),unresolved=sorted([r for r,s in zip(q['hypotheses'],states) if s=='unresolved'],key=refkey),baseline_ineligible=sorted([r for r,s in zip(q['hypotheses'],states) if s=='baseline_ineligible'],key=refkey),reasons=[]),adoption='derived_not_adopted',accounting=dict(logical={},physical='recorded_in_manifest'))
    if states==['not_assessed','not_assessed']:
        for k in ('compatible','incompatible','unresolved','baseline_ineligible'):output['summary'][k]=None
    for flag,code,path,reference in [('hold_false','condition_false','/execution/conditions/4',v['request']['execution']),('original_inapplicable','condition_false','/original/procedure/conditions/0',v['request']['procedure']),('acquisition_unknown','acquisition_unknown','/execution/acquisition',v['request']['execution'])]:
        if c.get(flag):
            r=dict(code=code,path=path,references=[reference]);output['summary']['reasons']=[r]
            for row in rows:row['reasons']=[r]
    if c.get('hold_unknown') or c.get('uncertainty') in ('unknown','confidence_only') or c.get('permission','true')!='true':
        reason=dict(code='hold_unknown' if c.get('hold_unknown') else 'uncertainty_'+c['uncertainty'] if 'uncertainty' in c else 'permission_'+c['permission'],path='/execution/conditions/4' if c.get('hold_unknown') else '/interpretation' if 'uncertainty' in c else '/authority/permission',references=[v['request']['execution']] if c.get('hold_unknown') else [v['root']] if 'uncertainty' in c else [v['authority']])
        output['summary']['reasons']=[reason]
        if c.get('permission','true')=='true':
            for r in rows:r['reasons']=[reason]
    logical={k:m[k] for k in ['unique_objects','capture_bytes','object_bytes','closure_bytes','reference_occurrences','json_nodes','json_depth','string_bytes']}
    logical.update(containment_comparisons=3 if 'bounds' in c else 0,interval_intersections=len(decoder['outcomes']) if B is not None else 0,baseline_checks=0 if states==['not_assessed']*2 else 4,qualified_cells=sum(len(decoder['outcomes']) for s in states if s not in ('baseline_ineligible','not_assessed')) if B is not None else 0,source_contributions=sum(len(decoder['outcomes']) for sr in q['support'] if get(sr)['procedure']==v['request']['procedure']) if B is not None else 0,prior_bundle_bytes=m['prior_reconstructed_bytes'])
    output['accounting']['logical']=logical
    output['summary']['reasons']=sorted({canon(r):r for row in rows for r in row['reasons']}.values(),key=lambda r:(r['code'],r['path'],canon(r['references']))) or output['summary']['reasons']
    eligible=[r['reference'] for r in rows if r['baseline']=='baseline_eligible']
    logical['source_contributions']=sum(len(decoder['outcomes']) for sr in q['support'] if get(sr)['procedure']==v['request']['procedure'] and get(sr)['hypothesis'] in eligible) if B is not None else 0
    if v['request']['predecessor']:
        prev=get(v['request']['predecessor']);pi=get(prev['original_invocation']);pq=get(pi['request'])
        pairs=[('/original_invocation',prev['original_invocation'],v['request']['original_invocation']),('/original/request',pi['request'],v['original_i']['request']),('/original/evidence',pq['evidence'],q['evidence']),('/procedure',prev['procedure'],v['request']['procedure']),('/decoder',prev['decoder'],v['request']['decoder'])]
        pairs.extend(('/original/support/'+str(i),a,b) for i,(a,b) in enumerate(zip(pq['support'],q['support'])))
        pairs.extend(('/original/hypotheses/'+str(i),a,b) for i,(a,b) in enumerate(zip(pq['hypotheses'],q['hypotheses'])))
        output['exposure']['changed_references']=sorted([dict(path=p,before=a,after=b) for p,a,b in pairs if a!=b],key=lambda d:d['path'])
    if c.get('observation_unavailable'):
        output['observation'].update(availability='unavailable',scalar=None,occurrence_id=None,raw_record_id=None,payload_checksum=None,unit=None,received_at=None,reasons=[dict(code='observation_absent',path='/snapshot/constraint_evaluations/0/candidates/0/not_evaluated_reason',references=[v['observation']['evidence']])])
        output['interpretation']['envelope']=None
        output['summary']['reasons']=output['observation']['reasons']
        for row in rows:row['reasons']=output['observation']['reasons']
    if c.get('baseline_unavailable'):
        for row in rows:row.update(baseline='baseline_unknown',baseline_checks=None,outcome_state='not_assessed_baseline_unknown')
        logical['baseline_checks']=0
        reason=dict(code='observation_absent',path='/original/evidence/snapshot/constraint_evaluations/0/candidates/0/not_evaluated_reason',references=[q['evidence']])
        output['summary']['reasons']=[reason]
        for row in rows:row['reasons']=[reason]
    trace=dict(schema='nr.trace.v2',profile=PROFILE,invocation=v['root'],required_closure=[dict(kind=k[0],sha256=k[1]) for k in sorted(v['objects'])],phases=[dict(phase=i,state='not_assessed' if (i==6 and states==['not_assessed']*2) or (i==7 and B is None) else 'assessed',reasons=output['summary']['reasons'] if i in (5,6) else []) for i in range(1,9)],dependencies=sorted([dict(result_path='/observation',references=[v['request']['observation'],v['observation']['evidence']]),dict(result_path='/hypotheses',references=sorted(q['hypotheses']+q['support']+[q['evidence'],v['request']['decoder']],key=refkey)),dict(result_path='/exposure',references=[v['request']['exposure']]),dict(result_path='/authority',references=[v['authority']])],key=lambda r:r['result_path']))
    reason_phase=5 if states==['not_assessed']*2 else 6 if B is None else 7
    for row in trace['phases']:row['reasons']=output['summary']['reasons'] if row['phase']==reason_phase else []
    files={'invocation.json':v['objects'][refkey(v['root'])],'closure.json':canon(v['closure']),'result.json':canon(output),'trace.json':canon(trace),'build.json':canon(v['build']),'policy.json':v['objects'][refkey(get(v['root'])['resource_policy'])]}
    manifest=dict(schema='nr.bundle.v2',profile=PROFILE,completeness='complete',files=[dict(name=n,bytes=len(b),sha256=sha(b)) for n,b in files.items()],physical=dict(status='static_not_observed',bytes_read=None,read_operations=None,bytes_written=None,write_operations=None,elapsed_ns=None,peak_rss_bytes=None))
    # Manifest physical nulls explicitly mark a sizing artifact, not a production
    # execution receipt. Full production manifest reservation is separately used.
    files['manifest.json']=canon(manifest)
    for n,b in files.items():(dest/n).write_bytes(b)
    receipt=dict(schema='nr.receipt.v2',operation='reassessment-evaluate',evaluation_permitted=c.get('permission','true')=='true',disposition=expect['summary'],result_sha256=sha(files['result.json']),bundle_sha256=sha(files['manifest.json']))
    (dest/'stdout.expected').write_bytes(canon(receipt)+b'\n');(dest/'stderr.expected').write_bytes(b'')
    m.update(result_bytes=len(files['result.json']),trace_bytes=len(files['trace.json']),manifest_bytes=len(files['manifest.json']),bundle_bytes=sum(map(len,files.values())),diagnostic_bytes=0,receipt_bytes=len(canon(receipt))+1,
        bundle_with_maximum_build_and_manifest_reserves=sum(len(b) for n,b in files.items() if n not in ('manifest.json','build.json','closure.json'))+16384+65536+m['closure_with_maximum_build_reserve'])

if __name__=='__main__':main()
