"""Prepare closed wire shapes; semantic constraints remain in frozen clauses.

This writes documentation data, not a runtime schema loader or application.
"""
import json
from pathlib import Path
from collections import defaultdict

P=Path(__file__).resolve().parent
def C(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def ref(kind=None):
    return dict(type='object',additionalProperties=False,required=['kind','sha256'],properties=dict(kind=dict(const=kind) if kind else dict(type='string',pattern=r'^(nm\.[a-z-]+(?:\.v1)?|nr\.[a-z-]+\.v2)$'),sha256=dict(type='string',pattern='^[0-9a-f]{64}$')))
def union(xs):
    unique={C(x):x for x in xs};values=list(unique.values())
    return values[0] if len(values)==1 else {'anyOf':values}
def shape(values,name=''):
    groups=defaultdict(list)
    for v in values:groups['null' if v is None else 'boolean' if type(v)==bool else 'integer' if type(v)==int else 'number' if type(v)==float else 'string' if isinstance(v,str) else 'array' if isinstance(v,list) else 'object'].append(v)
    choices=[]
    for typ,vs in groups.items():
        s={'type':typ}
        if typ=='object':
            variants=defaultdict(list)
            for v in vs:variants[tuple(sorted(v))].append(v)
            branches=[]
            for keys,rows in variants.items():branches.append(dict(type='object',additionalProperties=False,required=list(keys),properties={k:shape([r[k] for r in rows],k) for k in keys}))
            s=union(branches)
        elif typ=='array':
            flattened=[x for v in vs for x in v];s['items']=shape(flattened) if flattened else {}
        elif typ=='string':
            if name in ['schema','profile','kind','purpose','declared_relation','permission','adoption','ranking','qualification','envelope_rule','baseline_rule','exposure_rule','coverage_rule']:
                s['enum']=sorted(set(vs))
            elif name=='sha256' or name.endswith('_sha256'):s['pattern']='^[0-9a-f]{64}$'
            elif name=='checkpoint':s['pattern']='^[0-9a-f]{40}$'
            elif name in ['id','outcome']:s.update(pattern='^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$')
            elif name=='numerator':s['pattern']='^(0|-?[1-9][0-9]{0,127})$'
            elif name=='denominator':s['pattern']='^[1-9][0-9]{0,127}$'
            elif name in ['start','end','as_of','received_at','declared_prediction_commitment_at','declared_first_learned_at']:s['format']='date-time'
        choices.append(s)
    return union(choices)

values=defaultdict(list);seen=set();cases=json.loads((P/'cases.json').read_bytes())
for case in cases:
    path=P/'cases'/case['id'];meta=json.loads((path/'input.json').read_bytes())
    for r in meta['members']:
        k=r['kind'],r['sha256']
        if k in seen or not k[0].startswith('nr.'):continue
        seen.add(k);v=json.loads((P/'objects'/(k[1]+'.'+k[0])).read_bytes())
        if v['schema']=='nr.prepared-build.v2':
            v={a:b for a,b in v.items() if a not in ('status','binding')};v['schema']='nr.build.v2'
        values[v['schema']].append(v)
    for filename in ['result.json','trace.json','closure.json','manifest.json']:
        if (path/filename).exists():
            v=json.loads((path/filename).read_bytes())
            if filename=='manifest.json':v['physical']={k:0 if k!='status' else 'observed_before_manifest_write' for k in v['physical']}
            values[v['schema']].append(v)
    for filename in ['stdout.expected','stderr.expected']:
        b=(path/filename).read_bytes()
        if b:v=json.loads(b);values[v['schema']].append(v)
defs={kind:shape(vs) for kind,vs in sorted(values.items())}
for kind,d in defs.items():
    props=d['properties']
    if 'predecessor' in props:
        props['predecessor']={'anyOf':[{'type':'null'},ref(kind)]};props['revision']={'type':'integer','minimum':1}
        d['allOf']=[{'if':{'properties':{'revision':{'const':1}}},'then':{'properties':{'predecessor':{'type':'null'}}},'else':{'properties':{'predecessor':ref(kind)}}}]
    if kind=='nr.receipt.v2':props['operation']={'enum':['reassessment-evaluate','reassessment-verify','reassessment-replay']}
    if kind=='nr.build.v2':props['id']={'type':'string','pattern':'^[0-9a-f]{64}$'}
    if kind=='nr.bundle.v2':props['physical']['properties']['status']={'const':'observed_before_manifest_write'}
    if kind=='nr.result.v2':
        props['exposure']['properties']['changed_references']={'type':'array','items':{'type':'object','additionalProperties':False,'required':['path','before','after'],'properties':{'path':{'type':'string','pattern':'^/'},'before':{'anyOf':[{'type':'null'},ref()]},'after':{'anyOf':[{'type':'null'},ref()]}}}}
    if kind=='nr.trace.v2':
        props['phases']['items']['properties']['phase']={'type':'integer','minimum':1,'maximum':8}
    if kind=='nr.diagnostic.v2':
        props['target']['properties']['request']={'anyOf':[{'type':'null'},ref('nr.request.v2'),ref('nm.request.v1')]}
        props['target']['properties']['references']={'type':'array','items':ref()}
        props['target']={'anyOf':[{'type':'null'},props['target']]}
        props['target']['anyOf'][1]['properties']['logical_id']={'anyOf':[{'type':'null'},{'type':'string','pattern':'^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$'}]}
        props['target']['anyOf'][1]['properties']['occurrence_count']={'anyOf':[{'type':'null'},{'type':'integer','minimum':0}]}

# Shape observations do not narrow declared future revisions or the approved
# conditional interval/attestation variants that happen not to occur in the corpus.
u=defs['nr.request.v2']['properties']['interpretation'];ratio=shape([{'numerator':'0','denominator':'1'}])
u['properties']['lo']=u['properties']['hi']={'anyOf':[{'type':'null'},ratio]}
u['properties']['kind']={'enum':['declared_point','hard_interval','unknown','confidence_only']}
u['allOf']=[{'if':{'properties':{'kind':{'const':'hard_interval'}}},'then':{'properties':{'lo':ratio,'hi':ratio,'basis':{'minItems':1}}},'else':{'properties':{'lo':{'type':'null'},'hi':{'type':'null'}}}},
             {'if':{'properties':{'kind':{'const':'declared_point'}}},'then':{'properties':{'basis':{'minItems':1}}}}]
for kind in ['nr.observation.v2','nr.authority.v2']:
    name='provenance' if kind=='nr.observation.v2' else 'basis';defs[kind]['properties'][name].update(minItems=1,uniqueItems=True,items=ref('nm.basis'))
execution=defs['nr.execution.v2']['properties'];row=execution['conditions']['items'];row['properties']['state']={'enum':['true','false','unknown']}
execution['conditions'].update(minItems=5,maxItems=5)
execution['acquisition']['properties']['state']={'enum':['known','unknown']}
catalog={'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'urn:ohk:reassessment:v2:preparation-wire-catalog','$defs':defs,
    'description':'Closed wire shapes with approved conditional extensions. All cross-reference, role, ordering, exact arithmetic, bounds, admissibility, phase and custody rules in CONTRACTS.md and frozen candidate/amendment are additionally normative. Schema validation is not runtime qualification or permission.'}
(P/'wire-catalog.json').write_bytes(C(catalog))
print(json.dumps({'schema_definitions':len(defs),'kinds':list(defs)}))
