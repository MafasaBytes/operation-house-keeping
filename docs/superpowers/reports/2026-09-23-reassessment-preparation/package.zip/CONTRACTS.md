# Reassessment v2 preparation contract supplement

This is an exact-package candidate, not implementation approval. The owner-approved
corrected candidate §§2–8 and carriage amendment §§2–4 govern. Their frozen bytes
and commitments are in `authority/`; this supplement completes preparation wire
choices without changing their model-relative meaning. Historical v1 documents
remain recoverable. No v1 payload is silently reinterpreted as v2.

## 1. Authority, inputs and ownership

The only new application profile is `measurement-reassessment/v2`. The nr kinds
are invocation, request, observation, execution, exposure, authority, policy,
retained-bundle and build, each `.v2`. Every semantic object has exactly
`schema,profile,id,revision,predecessor` plus the body in corrected candidate §3,
with nr references changed to v2 and retained-bundle replaced by amendment §2.
All fields are mandatory; unknown fields refuse. Nullability is explicit in the
candidate. `wire-catalog.json` records closed shapes; the cited clauses supply
cross-field, numerical, authority and temporal constraints, not optional hints.

Common IDs are case-sensitive `[A-Za-z0-9][A-Za-z0-9_.-]{0,63}`. Revisions are
strict positive integers, not Boolean values. Predecessor is null exactly at
revision 1; otherwise it identifies the same kind/ID at revision minus one.
All references are exactly `{kind,sha256}`, lower-case 64-digit SHA-256 over the
complete canonical bytes. Existing nm contracts and opaque `nm.basis` are reused
without changing their versions. Nomination uniqueness, ordering and collisions
retain the accepted nm contract. Each required ancestor is retained through 1.

I.request supplies the reassessment Q; I.authority explicitly authorizes that Q
for `result_reassessment`. External pin equals that authority's SHA. Q references
the original nm I, whose Q alone nominates H/P/S and E0. Q.procedure must be one
of those P, and Q.decoder exactly that P's decoder. The original_selection_pin
equals original I.selection.sha256, not any result digest. New observation O
references E1 and those exact P/O definitions. No filename nominates candidates.
No second caller scalar, computed outcome, survivor list or supplied calculation
is an input. Generic evidence sources remain source-agnostic; the first numerical
profile is deliberately only reference-scalar Celsius with finite decimal values.

Public StateClassificationResult reconstruction owns model identity, snapshots,
indices, primitive tokens, provenance and numerical availability. Existing public
admission owns the exact E binding. Subject, variable, assertion context and
scenario agree across E0/P/execution/E1; the distinct as_of is explicit. Conditions,
acquisition, hold, local permission, uncertainty and exposure chronology are local
attestations. They establish neither performance of a physical procedure nor
authenticated identity, calibration, causal truth or empirical prediction accuracy.
The source snapshot is retained, not a hidden handle into a live store.

Application ownership: closed nr schemas, orchestration, exact joins, authority,
interval interpretation, reporting, budgets, capture and replay. Public contracts
and existing supplied-support qualification keep their owners. No new backend
package, general inference layer, physical adapter or adoption endpoint is needed.

## 2. Numerical, exposure and baseline rules

Canonical UTF-8 JSON has sorted keys, compact separators, no final newline, no
duplicate keys/BOM/nonfinite JSON numbers; streams add exactly one LF. Exact R
is reduced numerator/positive-denominator integer strings, zero `0/1`. Existing
128-digit rational limits apply to nr scalars and endpoints, including conversion
from the admitted public decimal. Check expanded digit demand before allocating
an out-of-policy rational. Public admission may accept a wider numerical value;
nr then refuses `RESOURCE_LIMIT_EXCEEDED`, dimension integer_digits, without
rounding or changing that public contract. Individual comparison cross-products
can require 256 digits, as the existing measurement contract already documents.
Public structural limits remain stricter than the outer object limits where
applicable (131,072 bytes; depth 32; 8,192 nodes; 256-byte strings; 32 model records;
8 conditions/evaluations; 4 candidates per evaluation). No outer allowance waives
them. Exact points are `[x,x]` with a declared-point assumption, not zero error.

Hard intervals check bound order and both containment comparisons. Failure is
`OBSERVATION_UNCERTAINTY_INCONSISTENT`, exit 3, `/interpretation`, before envelope
intersections or support qualification. Unknown/confidence-only envelopes cannot
eliminate H. Validate all original decoder partitions first, including gaps away
from the observation. Intersect every branch with the closed envelope in the
finite-decimal domain. A singleton is supported only if its reduced denominator
has no prime factors other than 2 and 5. Preserve original empty branches and all
original identities; only genuinely nonempty intersections enter B.

Every eligible H needs all B cells to permit for compatibility, or all to carry
justified exclusions for conditional incompatibility. Mixed, missing, unavailable
or conflicting support gives unresolved. Positive support alone has no complement.
All-outcome row validity remains mandatory. Baseline-ineligible H have null cells
and remain baseline-ineligible for this assessment; a separately authorized new
baseline is a different assessment. No-fit is model_prediction_mismatch, multiple
fits remain multiple, and zero baseline-eligible H is its own disposition. No
nearest hypothesis, implicit pruning or reranking is introduced.

Prior-bundle integrity and recorded references are verifiable. The three chronology
outputs are `declared_pre_exposure_unverified`, `declared_retrospective` and
`exposure_unknown`, solely from the explicit declaration. Never infer chronology
from file presence, hashes or timestamps. An internally consistent false chronology
can pass. Changed original I/Q/H/P/O/S/E0 references are disclosed against a retained
request predecessor; changes never overwrite the earlier request or predictions.
No trusted custody mechanism is introduced. Adoption remains `derived_not_adopted`.

## 3. Validation and diagnostics

Use the candidate's eight phases exactly: (1) bounded capture/canonical dispatch,
actual build/policy and external pin; (2) complete typed/ancestor/role closure and
original decoder integrity; (3) original selection pin, exact semantic joins and
both public reconstructions; (4) uncertainty/timing/exposure consistency;
(5) new permission; (6) baseline and execution/availability; (7) branch-local
qualification and assessment; (8) bounded output/publication. Resource/path guards
refuse at the attempted operation. Same-phase semantic ordering is code, ASCII
pointer, exact reference; owning nm subvalidation keeps its internal precedence.
Do not claim later work after refusal. Public CN numerical reconstruction is not
observation-envelope intersection or prediction qualification.

Completed withholding vocabulary in this package: evaluation_denied,
evaluation_permission_unknown, baseline_unavailable, no_baseline_eligible_hypotheses,
observation_unavailable, withheld_due_to_unknown_execution,
withheld_due_to_inapplicable_execution, withheld_due_to_unknown_uncertainty.
Assessment summaries are one_compatible, multiple_compatible, incomplete_assessment
and model_prediction_mismatch. These are reports (exit 0), never technical success
at physical acquisition. Preserve the exact public unavailable reason, condition
ID/state/basis and support-cell reasons. Zero compatible plus unresolved is not
model mismatch. Conditions are ordered applicability/availability/calibration/
fidelity/hold; every reached reason survives, sorted, rather than picking a winner.

Diagnostics retain the nm diagnostic layout, changing schema to nr.diagnostic.v2:
`schema,code,stage,target,resource,retry,bundle_state,message_key`. Target is null
only in bounded fallback; otherwise exactly `request,field,logical_id,references,
occurrence_count`. Preserve the owning request/reference when delegating an nm
error; new nr errors name the nr Q. Field is an ASCII JSON pointer. Resource is
null or exactly `dimension,attempted,limit`. No unbounded exception text enters a
stream. `diagnostic-catalog.json` binds expected codes, targets, stages and exits.
The inherited receipt and diagnostic shapes have no profile field; profile is
explicit on the semantic and retained envelopes. No heuristic profile dispatch.

Exact streams: completed operation emits one canonical receipt plus LF to stdout,
empty stderr; refusal emits one canonical diagnostic plus LF to stderr, empty
stdout. Exit classes are 0 completed, 2 usage, 3 input, 4 resource, 5 path,
6 retention, 7 internal/output-channel failure. A broken channel may prevent
delivery of a diagnostic; it cannot become success. Diagnostic overflow uses the
existing bounded DIAGNOSTIC_LIMIT_EXCEEDED fallback. Preserve absent/incomplete/
complete-visible-durability-unknown publication states; never emit a success receipt
for a missing manifest or failed publication.

## 4. v2 shared carriage and complete closure

Apply the exact approved fixed recipe, not a general reconstruction interpreter.
Descriptor files are seven constant names, lexically sorted. Invocation/build/policy
reference their original nm kinds; manifest/result/trace are exact complete nm.basis
byte members with mandatory file-role validation. Only closure.json has
`{recipe:"original_closure"}`. The recipe carries exactly original schema/profile/
invocation/authority_pin/limits_override plus sorted unique required member refs.
Replace each ref with its exact base64 captured bytes in the original canonical
closure serialization; verify original manifest and all six committed files.
Manifest itself is content-bound by the descriptor. Check completeness both ways.

Ordinary opaque premises remain opaque; retained-file roles must pass their own
schemas and joins. Sharing does not transfer authority or turn retained output into
a support claim. A build in a result role refuses even when its digest is correct.
Output reference checks do not discover additional inputs. Active-path cycles are
not completed sharing. Hash/type validation precedes traversal. No SHA-consistent
public cycle is claimed; missing/digest public twins and test-only synthetic
traversal tests have different evidentiary scope.

Each complete raw member keeps object_bytes and each reconstructed original file
keeps its file-specific bound. The reconstructed original bundle keeps bundle_bytes.
Outer transport alone has the derived base64-string allowance. No compression,
fragmentation, cache fallback, arbitrary paths or reconstructed oversize objects.
Charge each ref use/role check/context scan/reconstruction even when bytes are shared.
The original 232,849-byte witness is one demonstrated input, not a promise about
every selector bundle or every combination of maximum dimensions.

## 5. Commands, capture and publication

Future maintained entrypoint: `python -m applications.bounded_decision_workflow`.
Exactly these new subcommands, alongside unchanged thermal/governed/measurement:

```text
reassessment-evaluate --invocation FILE --objects-dir DIR --authority-pin SHA --output-dir NEWDIR [--limits FILE]
reassessment-verify --bundle DIR
reassessment-replay --bundle DIR --output-dir NEWDIR [--limits FILE]
```

Unknown/repeated/abbreviated flags refuse; no bypass, expected-result, callback,
automatic adoption, discovery or rerank option. Invoke only after separately
authorized implementation. Capture I first and only named `<sha256>.<kind>` members
reachable through declared references. Unreferenced files in an objects directory
are not nominees and are never opened. Extraneous retained closure members refuse.
Negative cases must be recovered from their own member list, never repaired from
the global preparation pool or a neighboring valid twin.

Reuse maintained descriptor-relative root containment, no-follow component walks,
regular-file admission, bounded reads and before/open/after metadata checks. Pin
directory descriptors, detect pathname/inode replacement and avoid later rereads
of captured originals. Captured bytes feed every stage and retention. Actual
executable/dependency hashing is separate live build verification, not a reread of
caller computation or evidence. Runtime files/results stay on the approved Linux
local ext4 boundary. This source-tree preparation makes no filesystem qualification
claim and does not change any legacy route's policy.

Reserve complete output plus the allowed manifest before creating NEWDIR. Refuse
collisions without overwriting. Use the established seven names, write manifest
last, check directory stability, fsync files/directory/parent as maintained.
Retain honest incomplete state after interrupted writes. No power-loss, alternate
platform or stronger durability guarantee follows from static recovery.

`--limits` is a canonical partial map of existing names to positive integers no
larger than the build-owned ceilings. Replay enforces the same or stricter effective
ceilings but reserializes the original retained limits_override; it must not change
the semantic closure merely because the caller tightens an operational guard.

## 6. Build binding and independent replay

The real nr.build.v2 has C plus the fields in candidate §3. Its source manifest
enumerates the complete maintained executable Python tree and exact dependency
lock; environment identity includes CPython/interpreter bytes, platform/libc,
installed distribution artifact manifests and lock digest. Derive from the actual
clean executable, never from caller assertions. Bind the exact v2 contract set,
unchanged policy digest and supported historical nm contract
`2e802d1a04f570378c83963d21f7979415b061bc7f68794024a2c9fc9231fa24`.
Retain the original nm build as historical input; do not compare it to the new nr
executable or claim that reassessment reran the historical selector.

Preparation inputs contain a deliberately nonexecutable nr.prepared-build.v2 slot
under the expected build filename. It carries the historical full manifest solely
for representative sizing. It must fail NONEXECUTABLE_BUILD_WITNESS unchanged.
After implementation is separately authorized, derive a real build, substitute
only the build slot, mechanically rehash I and its dependent output/trace refs,
recompute structural accounting/hashes and record a binding receipt. Do not learn
expected classifications or relations from application output. Byte templates here
are conditional on that binding, not successful production invocations today.

Verify: complete stored set, manifest/member integrity, actual nr build/policy,
required closure, public reconstruction and joins. It does not recompute conclusions.
Replay: recover solely from the retained nr closure; reconstruct E0/E1 and all
required historical material; repeat admission, declarations, permission, frozen
baseline, full-envelope decoding and support qualification; derive result/trace
afresh and compare their canonical semantic bytes. Compare against retained
expectations only after deriving them. Rehashed forged conclusions must produce
REPLAY_SEMANTIC_MISMATCH; they are never a supplied computation. No callback trust
boundary or hidden original directory is allowed.

Physical manifest values are observed only at runtime and excluded from semantic
equality. Preparation manifests explicitly have static_not_observed/null physical
fields and are not production manifests. Runtime stdout receipt hashes are derived
from independently bound expected result and the actual physical manifest; do not
freeze invented times/RSS or compare a runtime receipt against static placeholder
manifest hashes. Preserve every original failed invocation during qualification.

## 7. Proof provenance and compatibility

`cases.json` contains hand-authored semantic expectations. Assembly only lays out
their bytes/references and declared truth table. `check_static.py` separately uses
rational set intersections and source contributions to challenge that table.
Both are by the same lead author; this is independence from a future runtime,
not independent reviewer evidence. Pure owning-public-contract checks validate
synthetic input carriers, not a reassessment implementation or physical acquisition.
The supplied raw synthetic payloads match the carried checksum; public snapshots
are sufficient for recovery without any acquisition store.

Old reports, packages, original failure/oracle histories and acceptance markers
remain unchanged. No nr result is an observed-state mutation or an adopted H set.
No automatic discovery, probabilities, cost ranking, physical permission, causal
truth, empirical accuracy or global optimum is claimed. C remains unresolved;
IN-001 and CI-001 remain open and unselected. Exact package/resource-policy approval,
implementation authorization and later runtime qualification are distinct gates.

END OF REASSESSMENT V2 PREPARATION CONTRACT SUPPLEMENT.
