"""Bounded static checking of the emitted JSON Schema subset, no runtime imports.

This is not a general JSON Schema engine or substitute for semantic validation.
Date-time strings additionally belong to the recovered public owning contracts.
"""
import json
import re
from pathlib import Path
P=Path(__file__).resolve().parent
def valid(v,s):
    if 'anyOf' in s and not any(valid(v,b) for b in s['anyOf']):return False
    if 'allOf' in s and not all(valid(v,b) for b in s['allOf']):return False
    if 'if' in s:
        branch='then' if valid(v,s['if']) else 'else'
        if branch in s and not valid(v,s[branch]):return False
    if 'const' in s and v!=s['const']:return False
    if 'enum' in s and v not in s['enum']:return False
    typ=s.get('type')
    checks={'object':isinstance(v,dict),'array':isinstance(v,list),'string':isinstance(v,str),'null':v is None,'integer':type(v)==int,'number':type(v) in (int,float),'boolean':type(v)==bool}
    if typ and not checks[typ]:return False
    if isinstance(v,dict):
        if not set(s.get('required',[]))<=set(v):return False
        if s.get('additionalProperties') is False and not set(v)<=set(s.get('properties',{})):return False
        if any(not valid(x,s.get('properties',{}).get(k,{})) for k,x in v.items()):return False
    if isinstance(v,list):
        if len(v)<s.get('minItems',0) or len(v)>s.get('maxItems',len(v)):return False
        if s.get('uniqueItems') and len({json.dumps(x,sort_keys=True) for x in v})!=len(v):return False
        if any(not valid(x,s.get('items',{})) for x in v):return False
    if isinstance(v,str) and 'pattern' in s and not re.search(s['pattern'],v):return False
    if type(v) in (int,float) and (v<s.get('minimum',v) or v>s.get('maximum',v)):return False
    return True
defs=json.loads((P/'wire-catalog.json').read_bytes())['$defs'];checked=0;seen=set()
for case in json.loads((P/'cases.json').read_bytes()):
    d=P/'cases'/case['id'];meta=json.loads((d/'input.json').read_bytes())
    for r in meta['members']:
        if not r['kind'].startswith('nr.') or r['kind']=='nr.build.v2' or r['sha256'] in seen:continue
        seen.add(r['sha256']);v=json.loads((P/'objects'/(r['sha256']+'.'+r['kind'])).read_bytes())
        assert valid(v,defs[v['schema']]),(case['id'],r['kind'],r['sha256']);checked+=1
    for n in ['result.json','trace.json','closure.json','stderr.expected','stdout.expected']:
        f=d/n
        if not f.exists() or not f.read_bytes():continue
        v=json.loads(f.read_bytes());assert valid(v,defs[v['schema']]),(case['id'],n);checked+=1
result=dict(checked=checked,status='emitted subset shape consistency',application_executions=0,exclusions=['Nonexecutable build slots and static physical manifests are deliberately not production schemas.','Semantic negative cases may be shape-valid. Cross-field/numerical/role/authority rules require frozen contract checks.','This checker supports only the emitted keywords; not a general schema implementation.'])
(P/'shape-checks.json').write_text(json.dumps(result,sort_keys=True,separators=(',',':')))
print(json.dumps(result))
