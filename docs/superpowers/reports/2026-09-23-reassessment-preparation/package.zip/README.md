# Reassessment v2 preparation package candidate

Static preparation only. Read [READINESS.md](READINESS.md), then the manifest and
recovery receipt. This is not an executable application or an approved runtime
package. No generated observation is empirical evidence.

The package entry points are [CONTRACTS.md](CONTRACTS.md),
[IMPLEMENTATION-PLAN.md](IMPLEMENTATION-PLAN.md), [RESOURCES.md](RESOURCES.md) and
[ORACLE.md](ORACLE.md). `wire-catalog.json` supplies closed nr wire shapes;
`authority/next-measurement-frozen-authority.zip` retains the existing nm contracts,
public schemas and their original frozen package. `authority/accepted-source-context.zip`
recovers all 164 source/lock members of the accepted original build manifest.
It does not contain an interpreter or installable dependency environment.

`cases.json` names 72 cases across 12 approved groups. Each case has exact inputs
and expected semantic outputs or refusal. `command-matrix.json` is planned data,
not an executable script. `objects/` is the preparation content-addressed pool:
only `cases/ID/input.json.members` nominates a case's required objects. Inactive
draft objects are preserved and committed by the manifest as preparation history,
not additional inputs. Never repair a negative fixture by searching the pool.

The standard-library `recover_static.py PACKAGE.zip NEWDIR` verifies the archive,
recovers exact bytes, checks closure/arithmetic and reconstructs the accepted
original seven-file bundle from complete new closures. It does not run an
application command. The external standard-library Python prerequisite remains.
`check_public_inputs.py` additionally needs the existing accepted public source and
its external Pydantic environment; the observed check is recorded separately.

Case invocations intentionally carry `nr.prepared-build.v2` bytes. They are not
production-valid until a future authorized build-binding step derives the real
executable and mechanically updates affected commitments. Static manifests carry
null physical observations. Neither placeholder can be accepted as runtime evidence.

The owner approved the v2 carriage amendment at SHA-256
`d7136af5c4a086361e92be159d9aadc3c9d552d315dc2b2a3ecbf7df952a1676`.
Its historical wording remains unchanged. Earlier review commitment
`9909d9e7a439f97ae255ffe39402e9232bda4144acf21cef71eeaaf9de54b826`
remains unresolved; the adopted local review is
`5fb61f732f72e93b6c4ab9dd5459a6829468ce0ac209acfd9b2f00f63556ce06`.

END OF REASSESSMENT V2 PREPARATION PACKAGE NOTICE.
