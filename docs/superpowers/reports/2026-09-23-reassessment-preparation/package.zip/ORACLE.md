# Oracle and evidence provenance

The lead authored the case table from the approved scalar/interval definitions and
per-cell supplied prediction table. The future reassessment runtime does not exist
and supplied no oracle values. `assemble.py` serializes those chosen fixtures and
expected meanings; `check_static.py` was written separately to enumerate exact
interval intersections and qualified source signs and compare them with the table.
Both programs share an author, contracts and interpretation. Their agreement is
not independent reviewer, empirical, calibration or custody evidence.

The 12 approved groups are P1, P2, P3, P3b, P4, P5, P6, P7, P8, P9, P10 and P10b.
The current case catalog gives each core case exact input refs and a hand conclusion.
Delivery controls supplement P8/P10 and do not replace these cases. The earlier
selector's 142-command matrix and six harness-only controls are not reassessment
proof counts. New internal guard/cycle probes and manual work are separately listed.

For the three-outcome model, H1 permits H and explicitly excludes L/X; H2 permits
L and explicitly excludes H/X. L is (-∞,50], H is (50,70], X is (70,∞).
The actual accepted prior bundle has its original two-outcome low/high decoder,
complete-envelope support and other nominated procedure. It is preserved byte for
byte in the prior-carriage cases, not rewritten to impersonate the three-outcome
example. All assumptions remain explicit supplied synthetic conditional premises.

Membership checks use exact Fractions, not floating-point samples. A positive-width
interval contains a finite decimal. A singleton is counted only when both closed
boundaries include it and its reduced denominator factors into 2s and 5s. Thus the
empty 1/3 branch is retained in the original decoder but not fabricated as an
observed scalar. The 1/2 twin includes its point branch. A mixed permit/exclude
envelope is unresolved; all qualified exclusions are necessary for incompatibility.
An unavailable row taints its cells; opposing sources do not cancel into a winner.

Synthetic E1 is a complete public carrier, separate from E0. Raw payload bytes,
their checksums, synthetic occurrence identifiers and all repeated public copies
are recoverable. Existing public contract reconstruction checks the carrier; it
does not prove physical acquisition or the truth of its asserted procedure/hold.
`prepare_absence.py` uses existing pure public contracts to construct a no-observation
twin on the same model revision. It invokes no application command, store or ledger.

P7-newbaseline retains the earlier nr request as predecessor, changes E0 explicitly
to 80 under separate authority, and leaves the earlier ineligible assessment intact.
P9-retrospective retains the old x=80 mismatch request while changing supplied support
to permit X. Its declared retrospective fit is not predictive validation. Current
and predecessor closures both remain required; no automatic adoption follows.

The prepared build and static physical manifests are not runtime evidence. Semantic
templates become runnable only after actual-build binding and its recorded mechanical
ref/hash/accounting changes. Classification, source relationships, branches, exposure
meaning, baseline precedence and exact refusal rules must not change during binding.
Receipt/manifest physical hashes are checked by their derivation rule at runtime;
placeholder time/RSS values must never be promoted into observations.

Manual dossier: an internally consistent false chronology is indistinguishable from
a true declaration on these inputs; record the limitation rather than a passing
custody test. Manual adoption is outside the application. C is unresolved and has
zero automatic adjudication commands. IN-001 and CI-001 remain open and unselected.

END OF REASSESSMENT ORACLE PROVENANCE.
