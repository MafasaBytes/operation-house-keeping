# Lead proposal: maintained measurement-result reassessment

Design only; not an approved contract, implementation plan or milestone allocation.

## 1. Question, checkpoint and contribution

**Given an explicitly supplied result for a nominated measurement, which retained
hypotheses remain compatible, which are contradicted under the declared model,
and what remains unresolved?** The consumer is the existing source-agnostic
bounded decision workflow and maintained next-measurement selector.

Local verification on 2026-09-23: branch `main`, HEAD and locally recorded
`origin/main` both `15bd9dcb1559898944149cab0ec78b962019ab50`. The remote-tracking
reflog says `update by push`; origin is
`https://github.com/MafasaBytes/operation-house-keeping.git`. This corroborates the
owner's publication statement locally; **no fresh remote verification or remote
operation was performed**. Accepted tested implementation is
`23b60a42c2279fc228168967d47491b8983658fb`. The [acceptance record](2026-09-23-next-measurement-final-owner-acceptance.md)
matches SHA-256 `f29bc2a6f518ababb03b7269e4ea981a4824a32497ac41d6fa60f0f469f66833`.
The application/backend diff from that candidate contains only application README
status documentation. Starting index/tracked tree were clean: actual inventory
was **1,444 untracked paths and 2,698 tracked/untracked regular files**, hashed
before editing. This proposal alone is added; no tests or experiments are run.

Bounded objective contributions: **2**, disclose a newly admitted observation
without mutating system state or claiming global currentness; **3**, distinguish
supplied explanations consistent/inconsistent with that result under assumptions,
not causal diagnosis; **4**, provide traceable information for an explicitly
revised future selection request; **7**, separate observation, decoding,
conditional inference, assumptions, authority and unknowns.

## 2. Existing capability and exact gap

The maintained [guide](../../next-measurement/README.md) and [coverage map](../../next-measurement/coverage.md)
supersede historical statements that next-test ranking is absent. Inspection used
the frozen package's `CONTRACTS.md` and `IMPLEMENTATION-PLAN.md` inside committed
`2026-09-23-next-measurement-slice6-correction-evidence/frozen-authority.zip`, plus
these maintained implementation boundaries:

| Existing owner / contract | Reuse and limit |
| --- | --- |
| [Public admission](../../../applications/bounded_decision_workflow/admission.py), `_admit_observed_value`; [public value compatibility](../../../backend/observation_compatibility/contracts.py) | Reconstruct public state/evidence, exact indexed candidate, subject/variable/constraint, quantity/role/unit, model/interpretation revision, raw occurrence/checksum and received-at/cutoff consistency. No physical execution certification; application scalar admission currently requires a numeric temperature role. Public shape compatibility is broader than that adapter. |
| [Measurement graph](../../../applications/bounded_decision_workflow/measurement_wire.py), `BODIES`, `Graph._joins/_intrinsic/_decoder` | Closed I→Q→E/H/P/S carriage, exact versions/digests, authority closure, bounded ancestry; P method/edition and O partition. Current profile has at most two H/two P, three outcomes, fixed H account kinds and scalar-Celsius or literal-code procedures. Source-agnostic does not mean arbitrary domain support. |
| [Support qualification](../../../applications/bounded_decision_workflow/support_qualification.py), `qualify_supplied_support` | Exact H/P/O/E/context joins; positive, exclusion, unavailable and opposing contributions. Exclusions need explicit warrants or a warranted complete envelope. Qualified first-release premises are explicitly synthetic conditional support, not empirical predictions. |
| [Composition](../../../applications/bounded_decision_workflow/measurement_compute.py), `compute`; [minimax](../../../applications/bounded_decision_workflow/measurement_ranking.py) | Baseline H checks and prospective outcome cells/branches, whole-set withholding, ties and repeated/empty branches. No acquired-result input or observation-to-outcome interpretation. `nm.result.v1` is a selection result, not a measured result. |
| [Runtime](../../../applications/bounded_decision_workflow/measurement_runtime.py), `evaluate/verify/replay`; [CLI](../../../applications/bounded_decision_workflow/measurement_cli.py) | Safe captured closure, real build/policy binding, no-overwrite seven-file publication and independently recomputing replay. No reassessment command; verification alone is not semantic recomputation. |
| [Decision review](../../../applications/bounded_decision_workflow/decision_review.py), [governed review](../../../applications/bounded_decision_workflow/governed_review.py) | Maintained thermal/action dependency comparisons are profile-specific. Measurement review only lists seven dependency groups with `comparison=not_requested`; neither accepts a new observed-result reassessment automatically. |

**Missing behavior:** bind a subsequent observation to an immutable nominated P
and prediction context, decode it without suppressing uncertainty, and retain
per-H conditional conclusions with reasons and exposure history. Reading a stored
survivor branch manually lacks those admission, interpretation and authority joins.
Replacing baseline E with the new observation changes the prediction question and
is not reassessment of the original commitments.

Pure application composition can display historical branches but cannot supply
this missing contract. Recommend a **minimal application extension**, one supplied
scalar result against one original nominated procedure, producing a derived report.
Do not copy archived BRC/conditional/model-derived experimental implementations.
No demonstrated backend semantic or integrity gap requires an extension. General
code-result admission and arbitrary measurement models are deferred; do not pass
codes through the numeric admission adapter or invent temperature semantics.

## 3. Proposed contract and lifecycle

Use a separately versioned reassessment profile, not extra fields silently added
to closed `nm.*.v1` objects. The following are proposed semantic fields, not a
frozen wire grammar or new authorized CLI:

| Captured record | Required meaning and joins |
| --- | --- |
| Assessment request | Exact original invocation/Q and selection, nominated P and O references, one result reference, reassessment policy/build and explicit local authority pin. Recover original full required closure; recompute original qualification rather than trusting stored cell claims. No requirement that P was the winning recommendation. |
| Result evidence | Separate owning public snapshot/question/binding and raw occurrence identity/checksum/value/unit. Reuse public reconstruction and numeric admission. Do not repurpose original E. Bind the exact P revision/method edition and O, subject/variable and assertion context; incompatible or substituted bindings refuse. |
| Execution/context attestation | Declared acquisition interval, source/result availability and exposure times, same-subject/configuration relation to the original prediction context, and applicability/calibration/fidelity/hold basis for that interval. Received-at is ingestion time, not acquisition time. Different cutoffs are explicit; require the declared hold/context relation, not equality of old and new `as_of`. Unknown relation or execution applicability withholds interpretation. These are local assertions, not authenticated performance records. |
| Interpretation | Immutable observed scalar plus separately declared uncertainty. First scope: exact point, or a finite closed rational interval containing that scalar with explicit hard-bound basis; unknown uncertainty is unresolved. A confidence interval is not a hard envelope and cannot authorize elimination. Preserve units exactly; no implicit conversion. |
| Exposure record | Exact original prediction/support/decoder commitments and their asserted commitment time; result exposure state `before/after/unknown`, available timestamps and local basis. Missing chronology means unknown, not prospective. Content hashes prove identity, not that predictions were committed before exposure. |
| Derived assessment | Original H identity map, each baseline eligibility finding separately, interpreted possible outcomes, per-cell warrants, per-H status/reasons, exposure disclosure, authority and work trace. No adopted H set or mutation of observations is implied. |

Lifecycle: capture → integrity/typed closure/public reconstruction → permission
for this reassessment → actual-result/context applicability → decode → qualify
original supplied support → derive statuses → retain. Preserve lower reasons;
permission denial, unknown applicability, missing support and contradictory
support are distinct. Malformed bytes, wrong profile/version/subject/unit, broken
closure or resource exhaustion are technical refusals. Valid but insufficient
evidence yields a completed unresolved/withheld assessment, not a fabricated fit.
Original permission to hypothetically evaluate is not automatically permission
for this new assessment: require separately pinned local authorization for its
request and purpose. No authority here permits physical acquisition.

Original predictions, support, uncertainty, evidence, nominated sets and selection
remain immutable. A rehashed changed prediction is a new interpretation request,
never a replacement for the original. It must name its predecessor and disclose
result exposure and changed commitments. Historical or retrospective assessment
is allowed with that label; it establishes no independent predictive validation.
Do not auto-detect or certify a person's prior knowledge from timestamps.

## 4. Interpretation and conclusions

Existing decoder partitions use exact rational endpoints and closure flags.
For an admitted point, find its exact branch. For a justified hard interval,
retain **every** intersecting branch, including endpoint-only intersections;
never round to one branch. Unknown uncertainty, unsupported domain, out-of-domain
code or invalid partition cannot be turned into a nearest branch. Invalid
partitions are integrity refusals; unsupported result domains are explicit
out-of-scope refusals. No probabilistic interpretation is introduced.

Let B be the nonempty set of possible decoded outcomes. After permission and
applicability, requalify each original H/P/outcome cell. Proposed conservative rule:

- **Compatible:** every b in B has qualified positive permission for H, with no
  unavailable or opposing contribution in those cells.
- **Incompatible under declared assumptions:** every b in B has justified exclusion
  for H. This is conditional contradiction, not unconditional physical falsification.
- **Unresolved:** all other combinations, including mixed permit/exclude, missing
  support, conflict or unknown interpretation. Retain which branches could fit;
  do not call a mixed interval definitely compatible merely because one value fits.

Keep baseline H findings separate; an already baseline-ineligible H is labelled
as such, not newly eliminated by this observation. All original H remain in the
report. Unrelated missing cells can keep the original ranking withheld while a
fully qualified observed branch supports a local assessment; disclose this
difference. A missing/opposed source that taints the observed cells remains
unresolved. This narrower per-result rule is a proposed owner decision, not a
change to the selector's whole-matrix requirement.

All applicable retained H explicitly exclude every possible branch: report
**model/prediction mismatch**, no nearest hypothesis and no new hypothesis.
Zero compatible H with any unresolved H is **insufficient support**, not proven
no-fit. Multiple compatible H preserve ambiguity. Empty/repeated prospective
branches remain historical evidence; no branch deduplication or retroactive
editing of the original score is permitted.

## 5. Adoption and downstream reuse

Deliver a derived reassessment only. Retain explicit dependency references from
each conclusion to observation, decoder, context/hold assumptions and qualified
support. Existing thermal/governed dependency review cannot consume this as a
thermal action result; reuse its traceability discipline, not its fixed row schema.
No general influence layer or automatic cross-bundle comparator is necessary.

A later recommendation requires an explicitly nominated, authorized new Q and
traceable adoption of a working interpretation. Unresolved H cannot silently
disappear. Original Q is unchanged, even if a new Q retains fewer H. Record the
assessment and adoption basis through explicit retained provenance/basis content;
existing opaque basis carriage preserves bytes but does not itself validate an
adoption decision. New context/evidence requires coherently rebound P/H/S, not
stale support copied by ID. The obtained measurement is historical; future P
nominations are explicit, even for an intentional repeat. Recommend manual
handoff, with no adoption command or automatic reranking in this first extension.

## 6. Smallest decisive proof design (not executed)

Use the accepted two-H/two-P synthetic premises; add a scalar T1 partition
L=(-∞,50], H=(50,70], X=(70,∞), with exact rational endpoints. H1 permits H and
explicitly excludes L/X; H2 permits L and explicitly excludes H/X. T2 is
nondiscriminating with complete warranted support. These are new proposed fixture
premises, not modifications to frozen oracles. Unless noted, every case supplies
public scalar evidence, exact P/O/E/context joins, pinned assessment permission,
hold/calibration assertions and disclosed pre-exposure local prediction commitment.

| Case and nearest twin | Expected conclusion / limiting authority |
| --- | --- |
| T1=60 versus T1=40 | H1 compatible/H2 conditionally incompatible, then reverse; no diagnosis or empirical accuracy claim. Exact scalar and endpoint set membership independently hand checked. |
| Both H positively permit H with separately warranted remaining cells, T1=60 | Both compatible; no winner. Contrast the original discriminating fixture, with new support identities, not a hidden edit. |
| T1=80 versus T1=60 | Both explicitly exclude X: model/prediction mismatch, not nearest H. A missing X exclusion makes that H unresolved and prevents the all-H mismatch claim. |
| Remove H2's H exclusion; then supply an opposing positive source | H2 unresolved with missing and then conflict reasons; H1 may remain compatible. Add warranted exclusion only as the valid twin. Positive-only L support must not eliminate H2 at H. C is not adjudicated. |
| Scalar 50 with hard interval [49,51] versus [49,50] and point 50 | First intersects L/H: both unresolved; second/point map only L. Unknown bound or confidence-only declaration withholds. Bounds and assumption basis are retained separately from observed value. |
| Correctly rehash P edition, context relation or O boundary; retain original support/result joins | Fail the specific semantic join despite digest validity. Valid twin is a separately identified coherent request with all relevant support/attestations rebound and exposure disclosed. Never relabel as the original prospective test. |
| After seeing 80, revise H1 to permit X | Original remains mismatch; new explicitly retrospective interpretation may fit, but has no prospective-validation status. Unknown exposure remains unknown. Missing change disclosure refuses; truthful disclosure is the twin. |
| Wrong subject/unit, unavailable public evidence, denied assessment or unknown hold versus exact admitted/permitted twin | Integrity refusal for wrong bindings; unavailable/denied/unknown reasons remain distinct and block dependent work. A non-winning nominated P is not refused just because it was not recommended. |
| Explicit later Q retains only compatible H1 after 60; compare ambiguous T2 result retaining both H | Manual adoption/new Q can yield `no_discrimination_needed` versus unchanged T1 preference with coherent complete supplied support. No zero-H Q after mismatch; no automatic chaining. This is a composition check only, not a new ranking algorithm or adoption feature. |

Independent checking should enumerate rational interval intersections and the
three-valued cell table from declared premises, compare full identity/provenance
maps, and check refusal precedence with nearest valid twins. Add missing-ancestor,
resource-exhaustion and standalone replay twins: forged-but-rehashed conclusions
must fail recomputation; original input paths absent must not prevent valid replay.
Oracles written by the implementer are same-author evidence, not independent
review. No proof outputs, measurements or passing claims exist from this design.

## 7. Delivery boundaries, decisions and next gate

Reuse bounded typed closure, canonicalization, public reconstruction, exact
authority references, safe capture, immutable publication and semantic replay.
An accepted old bundle must retain its original interpretation/build, not be
rewritten under a new profile. A reassessment bundle needs the original required
closure, new observation/attestation bytes and policy, plus derived result/trace;
hashes alone cannot support recovery. Replay must independently admit, decode,
qualify and reassess from captured bytes under its supported build. Historical
replay asserts neither current applicability nor current adoption.

Keep existing thermal/governed/nm schemas, commands, seven-file bundle meanings
and numerical policies unchanged. No command name/grammar is frozen here. New
profile delivery needs an explicit contract and resource preparation before
implementation: count both snapshots, unique/shared objects, all reference
occurrences and complete ancestor chains, contextual reconstruction, decoder
intersections, source contributions, outputs, physical reads/writes and retained
bytes. Reuse existing ceilings conservatively where applicable, including four
complete revisions, 128 unique objects, eight contexts and 1 MiB capture/bundle;
do not claim combined inputs fit or invent capacity. Refuse exhaustion without
truncation. No unlimited reassessment history, implicit squashing, no-follow
bypass, dependency acquisition or new durability/platform promise.

Genuine owner choices for a reviewed specification:

1. Approve the proposed first scope: one scalar result/one nominated P, no code
   adapter, automatic adoption, general dependency comparison or chaining.
2. Approve conservative interval unanimity and branch-local qualification, with
   explicit unresolved outcomes even when another possible value would fit.
3. Approve separate local reassessment permission, declared exposure chronology
   and retrospective labelling; no authentication or predictive-validation claim.
4. Decide whether a later adopted-set handoff should remain documentation-only
   as recommended; executable adoption would require separately scoped semantics.

Recommended next gate: separately authorize independent adversarial review of
this proposal, concentrating on uncertainty/exclusion quantifiers, temporal and
procedure joins, retrospective leakage, and adoption/replay closure. Resolve its
findings before contract/fixture/resource preparation; then require explicit
implementation authorization. No backend prerequisite is demonstrated. C remains
unresolved; IN-001 and CI-001 remain open and unselected. No hypothesis generation,
probabilities, empirical accuracy, causal truth, physical execution, monitoring
or autonomous control follows.

END OF LEAD PROPOSAL — DESIGN ONLY; IMPLEMENTATION UNAUTHORIZED.
