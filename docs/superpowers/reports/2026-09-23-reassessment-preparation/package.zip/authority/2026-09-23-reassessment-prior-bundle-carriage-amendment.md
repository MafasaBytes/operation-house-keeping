# Proposed amendment: shared prior-bundle carriage

Documentation and one static reconstruction witness only. **Not frozen, not an
operational-limit change, and not permission to resume full package preparation.**

## 1. Authority and measured cause

Verified [discrepancy report](2026-09-23-measurement-result-reassessment-preparation-discrepancy.md)
SHA-256 `46cebf3dd5d31a18ecb21231e06cd49b41c2c8f05adc62788e70c0fb1aa1ed65`.
Read the approved [reassessment contract](2026-09-23-measurement-result-reassessment-corrected-candidate.md),
including its unchanged closure/replay obligations, and the exact accepted
measurement delivery evidence. No frozen document or source bundle is edited.
Local authority remains `15bd9dcb1559898944149cab0ec78b962019ab50`.
Starting inventory: 1,449 untracked paths, 2,703 regular tracked/untracked files;
sorted path→SHA-256 inventory commitment
`7c3f00b452228d9fffe39351fef8a6542209d1b4248fa5cd2743b368c4365220`.
The unresolved historical review digest remains unresolved; this investigation
does not reopen its reconciliation or confer pre-exposure custody.

The accepted bundle is the seven `result/` members of committed
`2026-09-23-next-measurement-release-evidence/committed-only-delivery.zip`, archive
SHA-256 `d1608a25394c9ce7229d8d4517bf7ccc35fb43277e75fd2b420536948bdc8867`.
It contains **232,849 original file bytes** and 19 required original closure
objects totaling **129,617 decoded bytes**. Required material is not disposable.

The excess is the representation, not 232,849 bytes of distinct new evidence:

- Original closure.json is 175,931 bytes: 172,836 base64 payload bytes plus 3,095
  framing bytes. It already carries all 19 required original objects.
- The old prior object base64-encodes all seven files (310,472 bytes), including
  that already encoded closure; wrapper/reference/duplicate-manifest overhead
  adds 1,496 bytes, yielding the 311,968-byte object.
- Outer carriage encodes that object again and separately retains the same 19
  required typed inputs. Encoded payload alone is 588,796 bytes; a comparable
  static witness envelope is **591,913 bytes**. This exceeds 512 KiB before E1.
- Build, policy and invocation also appear both as standalone original files and
  within the original closure. The original manifest is duplicated in the old
  wrapper as parsed content and exact file bytes.

Eliminating duplicate storage does not eliminate original reconstruction, parsing,
hash checks, authority joins, context scans or later public admission work.

## 2. Smallest proposed correction and field mapping

First assessed the simpler **whole-file references only** alternative: reference
the raw original closure as another bounded opaque member, with no recipe. It
fits this prior-material witness: 1,152-byte descriptor, 24 members, 336,073 decoded
bytes and 451,797 wire bytes. It leaves only 72,491 closure bytes; another E-sized
snapshot like the existing 86,310-byte E would require 115,080 base64 bytes before
any new framing/build. This is a representative sizing argument, not proof that
every possible E1 needs that size. The alternative remains viable for explicitly
fitting combinations and introduces fewer fields, but does not address the main
duplicate closure or provide that representative preparation headroom. Exact
figures are in [alternatives.json](2026-09-23-reassessment-carriage-evidence/alternatives.json).

Recommend the following one fixed recipe as the smallest additional mechanism
that removes that remaining duplication. It reuses the existing canonical closure
serialization rather than a new general encoding. No claim of globally minimal
representation or complete reassessment fit follows.

Reuse the existing exact `{kind,sha256}` object pool, ordinary opaque `nm.basis`
byte storage and outer closure base64 transport. Introduce **one bounded descriptor
and one fixed canonical reconstruction recipe**, not compression, chunking, generic
patch instructions, paths or callbacks. The original seven files remain exactly
recoverable; only the unused v1 *wrapper* is not reconstructed.

Descriptor `nr.retained-bundle.v2` has common semantic header plus exactly
`{files,closure}`. For this proposed revision the header profile is
`measurement-reassessment/v2`. `files` is lexically ordered, exactly seven rows
`{name,source}` with fixed names. All content references resolve from captured
members, never from a directory search or cache.

| v1 carriage | Proposed v2 source and mandatory role |
| --- | --- |
| Parsed top-level `manifest` plus encoded manifest.json | One `nm.basis` ref in the manifest.json file row. Preserve exact bytes, validate nm.bundle.v1 schema/profile/completeness and six-file commitments. Descriptor digest commits this manifest reference. No second parsed-manifest copy. |
| Encoded invocation.json | `{reference: original nm.invocation.v1 ref}`; byte-identical to original I. |
| Encoded build.json | `{reference: original nm.build.v1 ref}`; exact I.build_identity digest, retained historical witness, not a new executable claim. |
| Encoded policy.json | `{reference: original nm.resource-policy.v1 ref}`; exact original resource-policy digest. |
| Encoded result.json, trace.json | Each `{reference: nm.basis ref}` to complete exact raw file bytes; independently validate the corresponding nm.result.v1 / nm.trace.v1 role, original I joins, sizes and commitments. No interpretation as a basis *claim* and no supplied result as reassessment computation. |
| Encoded closure.json | `{recipe: "original_closure"}`. The descriptor's `closure` carries the original six-field closure header, but its `members` is a sorted unique list of exact typed refs, not encoded copies. |

The closure recipe fields are exactly `schema,profile,invocation,authority_pin,
limits_override,members`. The first five preserve original values; schema/profile
must be nm.closure.v1 / bdw.measurement.supplied.v1. Each member is an exact ref.
Reconstruct the original canonical closure by replacing each ref with
`{reference:ref,encoding:"base64",bytes:base64(exact captured bytes)}` in original
canonical order. No whitespace, normalization, substitution or regenerated old
result is allowed. Canonical serialization must reproduce the manifest's original
closure length and hash. Noncanonical or unsupported original encodings refuse;
they are not silently reserialized into a different accepted bundle.

Opaque storage is not an unchecked escape: retained-file roles validate ordinary
bounded JSON, schema/profile and every applicable original identity join even
though their storage key is nm.basis. For result/trace, use the supported original
retained-envelope contract; carried refs must name the appropriate captured original
objects. Those output refs are integrity-check work, not authority to discover
additional files. A build supplied under a result role fails, even if its digest
is correct. Ordinary raw nm.basis premises keep their prior meaning and byte bound.

Version behavior: publish a v2 reassessment contract identity/profile and propagate
the nr schema/ref versions in the connected request graph; all unaffected fields
and semantics remain those approved for v1. Existing nm schemas/policies/commands
are unchanged. v1 carriage is neither heuristically accepted as v2 nor rewritten
in place. Any conversion is an explicit new request/bundle, retaining its original
source commitments; no same-kind predecessor rule is faked across schema versions.
New v2 lineages still retain all declared same-kind ancestors through revision 1.
The v2 executable must bind the amended contract exactly; the static descriptor
is not a prepared executable witness or an authorized runtime input today.

## 3. Complete recovery and validation boundaries

The descriptor identifies exactly the seven required files. Its original closure
member list must equal the full typed/declaration/predecessor closure of original
I: no missing or extraneous member, no added basis obtained by hidden discovery.
The original authority pin equals I.selection.sha256. The descriptor must bind the
same original I as reassessment; the separate new reassessment authority pin is
unchanged. Verify the original manifest and all six listed file hashes/sizes;
manifest.json itself is bound by its content reference in the descriptor.

Capture through the maintained fixed `<sha256>.<kind>` lookup, root containment,
no-follow regular-file admission and race checks. Within standalone replay all
member bytes come from the retained outer closure. No original directory, network
or local cache may fill a missing object. File names are constants, not paths.
Only original closure.json uses the fixed recipe; all other files use whole byte
objects. No generic reconstruction program is accepted as input.

Resolution validates hash and expected role before traversal, retains complete
ancestry, checks global kind/id/revision collisions and scoped joins, and separates
active-path cycles from completed shared targets. Repeated references to identical
typed bytes share storage, not permission or semantic role. Matching SHA alone
does not alias different kinds. A declared opaque byte role still undergoes its
file-specific validation. The fixed closure recipe's references are dependencies;
its output hash is a commitment, not a recursively discoverable object. It cannot
refer to its own reconstructed output as an input or create digest-based fallback.

Refusal precedence: safe-capture/resource guards at the attempted operation;
version/shape errors before interpretation; missing/digest/role/closure errors
before a verified-prior-bundle claim; reconstructed size/hash mismatch before
reassessment. Preserve exact cause. No malformed supplied bundle becomes absent,
partial success or a chronology upgrade. Stable codes/stream fixtures belong to
the later amended package, not an invented passing application result here.

## 4. Accounting without evading limits

All current numerical ceilings remain unchanged. Distinguish:

| Charge | Enforcement boundary |
| --- | --- |
| Capture and decoded member bytes | Count each distinct captured key once in logical capture; enforce ≤256 KiB per complete raw object, ≤128 unique objects, aggregate capture ≤1 MiB before allocation. Every actual reread/copy is separately physical work. |
| Reference occurrences and traversal | Charge descriptor file refs, recipe member refs and invocation ref, every original incoming typed edge, ancestor edges and scoped validations. Transport index checks and carried result/trace ref checks incur their own validation work; sharing never removes those obligations. Existing 4,096 reference/edge ceilings and contextual limits remain. |
| Ordinary strings/JSON | Descriptor and retained JSON file roles retain 4,096-byte strings, depth/node/integer guards. Only the existing outer base64 transport uses its established derived transport allowance. No inner-string exemption. |
| Reconstruction | Precompute/reserve original closure size from exact member lengths plus canonical framing before emission; bound incremental work. Check closure ≤512 KiB, each other reconstructed file against its original file-specific cap, and total reconstructed original bundle ≤1 MiB. Respect stricter effective retained/request limits. Count every reconstructed/emitted/scanned byte even if not written to disk. |
| Retained v2 delivery | Charge full new closure wire, all other new files, duplicated inspection copies and manifest reserve under their original per-file and ≤1 MiB total bundle ceilings. This witness is only the prior-material contribution, not that full bundle. |
| Actual work | Separately report decoded bytes, base64 encode/decode work, object hashing, original manifest checks, repeated role/context scans, public reconstructions and physical read/write operations. Future runtime measures CPU/wall/RSS and refusal timing; no static byte saving substitutes for them. |

No object is fragmented to reconstruct a larger object outside its bound. Original
closure is a transport with its existing 512 KiB limit, not an ordinary semantic
object granted a new exception. Its complete reconstructed size remains checked.
The 311,968-byte v1 wrapper is not an original user file and has no logical role
in v2. We do not reconstruct it and then conceal that allocation. No compression
is used. Immutable policy capacities, four-revision and eight-context bounds still
apply; no maximum-size prior bundle is guaranteed merely because its wire shrinks.

## 5. Static witness and exact recovery

[Supporting measurements](2026-09-23-reassessment-carriage-evidence/measurements.json),
[self-contained witness](2026-09-23-reassessment-carriage-evidence/witness.json),
[reconstruction checker](2026-09-23-reassessment-carriage-evidence/reconstruct.py),
[seven original file commitments](2026-09-23-reassessment-carriage-evidence/expected-files.json),
and [isolated recovery receipt](2026-09-23-reassessment-carriage-evidence/standalone-recovery.json)
are retained. The checker imports only the Python standard library; it is a
narrow static audit program, not the production validator or reassessment runtime.

| Measured quantity, same original bundle | Old carriage | Proposed carriage |
| --- | ---: | ---: |
| Prior descriptor bytes | 311,968 | 3,323 |
| Distinct captured bytes including original 19 objects | 441,585 | 162,313 |
| Outer base64 payload bytes | 588,796 | 216,436 |
| Comparable standalone witness wire | 591,913 | 219,976 |
| Complete recovered original seven files | 232,849 | 232,849 |

New witness: 23 objects, largest complete member 86,310 bytes; ordinary parsed
strings max 93 bytes, JSON value depth max 16 and 5,246 unique parsed value nodes
under this audit's counting convention. These are static observations, not the
runtime's total scoped node/work counts. The original typed walk observes 62
reference occurrences over 19 objects; descriptor contributes 26 refs (19 member,
6 direct file and 1 original-I ref), plus the outer descriptor/index checks.
There is real sharing, not 62 separate object copies. These subtotals do not
claim every future contextual, output-reference or public reconstruction charge.

Descriptor SHA-256:
`349a817ecc5a4cdd257efdfbce85d7211ce7c6d2ab6776d2a0299d9dfcca1c1b`.
Witness SHA-256:
`d91332ea6f277c9415125b5e4273e83986a2b2a936718801e0a2a161a0a1efb4`.
Recovered closure.json: 175,931 bytes,
`5d8df562890d51a2bfdba10ddc460fcc822c1f31adc247651c825305eda405cd`.
Recovered original manifest.json: 972 bytes,
`8d88a43b5536326fb6020947ba8afe56fd59abace501be06fdd9b75ce6d86239`.
All seven original files were compared **byte-for-byte**, not only by hashes.
The expected-files artifact carries each original length and digest.

A second reconstruction ran in a new isolated `/tmp/nr-carriage-static-*` location
containing only witness.json and reconstruct.py; no original bundle directory was
available there. The program reads only its witness argument and writes a new
directory, with seven files plus a static report. All seven recovered bytes match
the original archive in an independent post-recovery comparison. This verifies
standalone byte recovery, not filesystem attack resistance or application semantics.
The preserved receipt names the exact location. No application import/execution,
new build identity, semantic proof matrix or operational policy change occurred.

The [recovery archive](2026-09-23-reassessment-carriage-evidence/recovery.zip)
contains 15 evidence files plus their manifest: 475,291 bytes, ZIP_STORED, SHA-256
`cd07349f8b639e57f92ad38e073a8953e54d6506e4695354595a405e8d05a674`.
All 16 archive members were checked byte-for-byte against source/manifest; expanded
size is 473,423 bytes. These are evidence-package sizes, not runtime bundle charges.
[Manifest](2026-09-23-reassessment-carriage-evidence/MANIFEST.json) SHA-256:
`9904a5a12662984ce8cc1eb978d1188fa800d0accde5f044a55f9134c21bccca`.
[Recovery receipt](2026-09-23-reassessment-carriage-evidence/recovery-receipt.json)
SHA-256: `b81c88c1f06080a928b9ee909b1844aa4beefa1a17cc3b87f6a4fe33d6d2b701`.

Reproduce after recovering the supporting files:

```text
python3 -B reconstruct.py witness.json NEW_OUTPUT_DIRECTORY
```

The source archive is not needed by that command. External Python 3 standard
library is required. The supplied checker intentionally does not validate all
public model semantics, production preallocation guards or every role-schema
field; those remain explicit production obligations. The input here is a fixed
bounded audited artifact. Mathematical byte counts and the checker are same-author
evidence, not an independent review, empirical model validation or custody proof.

## 6. Nearest valid/adverse cases and owner gate

Static reconstruction checks actually performed: missing captured member; wrong
original authority pin; omitted recipe member; wrong result-file role with valid
referenced bytes; duplicate recipe member; missing seventh file. Each rejects.
The unchanged shared-closure twin reconstructs all seven originals exactly.
See [static controls](2026-09-23-reassessment-carriage-evidence/static-controls.json).
These are six byte/reference perturbations plus one valid static twin, **not**
the earlier selector's six harness controls or an application proof matrix.

Additional acceptance obligations remain proposed: self-consistently rehashed
manifest versus payload mismatch; stale/foreign original I; compatible sharing
versus same bytes in an incompatible role; complete fourth revision versus missing
ancestor/fifth revision; malformed canonical closure; object/string/closure and
reconstructed-bundle exact-limit/plus-one refusal before allocation; test-only
synthetic active-cycle traversal distinct from public digest precedence; path
substitution, collisions and interrupted publication. Valid twins preserve exact
required content and references. No result is claimed for unexecuted cases.

**Feasibility conclusion:** this accepted 232,849-byte bundle has a sound, statically
recoverable prior-material representation under the unchanged relevant byte limits.
There is no demonstrated need to raise limits for this witness. This does not prove
that the full new E1/authority/exposure/history/build/output package fits, that every
previously intended prior bundle fits, or that runtime work is feasible. General
support is conditional on all original reconstruction limits and aggregate new
limits, not solely raw prior-bundle length. No silent supported-input restriction
is adopted. If later combined preparation fails, consolidate it before choosing
a justified limit amendment or explicit restriction with the owner.

**Precise approval needed:** approve this v2 descriptor/fixed-recipe and connected
contract-version change, reuse of exact opaque byte members with mandatory file-role
validation, and the stated reconstruction/accounting boundaries under unchanged
limits. Then separately authorize resumption of bounded package preparation.
This candidate is not frozen by its creation. Reassessment semantics, separate
authority, unverified exposure declarations and manual adoption are unchanged.
The current seven-file delivery pattern remains; the independent semantic replay
must still recover/re-admit/requalify/recompute rather than trust old result bytes.
Implementation, application proof execution, physical acquisition and autonomous
pruning/reranking remain unauthorized. C remains unresolved; IN-001 and CI-001
remain open and unselected.

END OF PRIOR-BUNDLE CARRIAGE AMENDMENT CANDIDATE — NOT APPROVED.
