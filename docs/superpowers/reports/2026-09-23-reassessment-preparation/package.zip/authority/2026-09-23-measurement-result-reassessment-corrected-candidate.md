# Measurement-result reassessment: corrected application-contract candidate

Documentation only. Proposed semantics and proof obligations; no implementation,
fixtures, executable qualification or owner design approval is claimed.

## 1. Authority, provenance and finding traceability

Checkpoint: `15bd9dcb1559898944149cab0ec78b962019ab50` on local `main`.
The complete [lead proposal](2026-09-23-measurement-result-reassessment-lead-proposal.md)
was read and remains frozen at SHA-256
`6a11958e692d620be6cacd9a84ef2332eb6bf23fb42edc2a4276ba3045864f28`.
The complete [independent review](2026-09-23-measurement-result-reassessment-independent-adversarial-review.md)
was read and is newly frozen by the owner at
`5fb61f732f72e93b6c4ab9dd5459a6829468ce0ac209acfd9b2f00f63556ce06`:
20,682 bytes, 211 lines, ending marker on line 210 and final blank line preserved.

Earlier expected digest
`9909d9e7a439f97ae255ffe39402e9232bda4144acf21cef71eeaaf9de54b826`
remains an **unresolved historical commitment**. Only the identified local version
was recovered; an earlier retained task-output capture matches its exact bytes.
Neither a typo nor equivalence was demonstrated. This candidate changes neither
input nor earlier receipt. Content similarity is corroboration, not byte identity.
Starting inventory: 1,446 untracked paths, 2,700 tracked/untracked regular files;
tracked tree/index clean. Only this candidate and its focused review may be added.

| Finding | Individual disposition proposed here |
| --- | --- |
| H1, high | §4 requires exact admitted x and lo ≤ x ≤ hi; inconsistency is technical refusal before decoding/qualification. Proof P2 isolates both violations. |
| H2, high | §5 separates verified content/dependency relationships from declared chronology. Reject the review's proposed `provably_pre_exposure` tier: ordinary local retention cannot establish it. This is an explicit epistemic disagreement, not an implementation of that wording. |
| M1, medium | §6 fixes `baseline_ineligible` for the exact captured baseline/assessment, before measurement conclusions. The local review does not claim permanent ineligibility across future versions; no such claim is attributed to it. |
| L1, low | §4 maps point input to closed [x,x], retaining its declared-point basis and absence of a physical zero-error guarantee. |

The review's “observed reality” explanation is narrowed to consistency with the
declared model. Its cross-platform bit-for-bit replay statement is not adopted:
only a future qualified matching build/environment can make a replay claim.
Reviewer endorsement is neither owner approval nor evidence of physical custody.

## 2. Scope and reuse

Question: given one explicitly supplied scalar result for one nominated procedure,
which retained H remain compatible, which are conditionally incompatible, and
which remain unresolved? Output is a derived report, never an adopted H set.
No automatic pruning, reranking, acquisition, monitoring, probabilities, cost
ranking, hypothesis/prediction discovery, causal diagnosis or empirical validation.
C remains unresolved; IN-001 and CI-001 remain open and unselected.

Reuse public snapshot reconstruction and exact numeric admission, the maintained
measurement typed graph/decoder grammar, and `qualify_supplied_support`. Their
owners remain authoritative. Sources:
[admission](../../../applications/bounded_decision_workflow/admission.py),
[wire/joins](../../../applications/bounded_decision_workflow/measurement_wire.py),
[qualification](../../../applications/bounded_decision_workflow/support_qualification.py),
[computation](../../../applications/bounded_decision_workflow/measurement_compute.py),
[retention/replay](../../../applications/bounded_decision_workflow/measurement_runtime.py).
Existing baseline E is not replaced by result evidence E1. Selection result
`nm.result.v1` is not an acquired measurement. Thermal/governed dependency review
has no reassessment input contract; only its explicit dependency discipline is
reused. No backend extension is demonstrated as necessary.

First profile preserves existing H/P nomination limits and synthetic conditional
support qualification. The selected P must be `reference_scalar` with the accepted
scalar-Celsius decoder domain. It need not have been the recommendation. Literal
codes and other quantity domains refuse as unsupported; source-agnostic does not
mean arbitrary measurement semantics. Historical reassessment is allowed, including
results acquired before the baseline cutoff, only with an explicitly asserted
context/hold relationship; no universal t1 > t0 condition is invented.

## 3. Closed proposed objects and field rules

New application profile literal `measurement-reassessment/v1`; proposed kinds
`nr.*.v1` below. Existing `nm.*` bytes/schemas/commands are unchanged. All listed
fields are mandatory, unknown fields reject, JSON null is allowed only where
specified. No evaluator callbacks, supplied computed matrices or latest lookup.

Common semantic header C = `{schema,profile,id,revision,predecessor}`. Schema is
the table's kind, profile the literal above; LocalId is the maintained case-sensitive
1–64 ASCII grammar; revision is strict positive integer. Predecessor is null iff
revision 1, otherwise exact same-kind/id previous-revision reference. Ref is exactly
`{kind,sha256}` with lowercase SHA-256 of complete canonical bytes. All basis
arrays contain exact opaque `nm.basis` references, sorted unique by (kind,sha256);
their bytes are required, not interpreted as executable rules. This exact opaque
kind is confirmed by maintained `measurement_wire.basis`; no alternative opaque
kind is silently accepted.

Canonical JSON, rational grammar, public token/time grammar, no duplicate keys,
ordering and bounded parsing retain the existing measurement rules. Rational R is
`{numerator,denominator}` with reduced integer strings, positive denominator and
zero `0/1`; conversion of admitted finite decimal x is exact, never binary float.
UTC time fields use the public aware-time grammar. New semantic arrays explicitly
named below are ID-ordered or reference-ordered, with no silent normalization.

| Kind | Exact body in addition to C |
| --- | --- |
| `nr.request.v1` | `original_invocation` (nm I ref), `original_selection_pin` (SHA), `procedure` (nm P ref), `decoder` (nm O ref), `observation` (nr observation ref), `execution` (nr execution ref), `exposure` (nr exposure ref), `interpretation` (inline U below), `policy` (nr policy ref). |
| `nr.observation.v1` | `evidence` (nm E1 ref containing separate public snapshot/question/binding/token roles), `procedure` (nm P ref), `decoder` (nm O ref), `provenance` (basis array, nonempty). No second caller scalar. Occurrence/raw/checksum/unit are extracted from the admitted E1 and reported, not trusted duplicate inputs. |
| `nr.execution.v1` | `observation` (nr ref), `original_context` (exact original Q context), `result_context` (same closed context shape for E1), `acquisition` (T below), `conditions` (five rows exactly, IDs applicability/availability/calibration/fidelity/hold; each `{id,state,basis}`, state true/false/unknown, basis nonempty for true/false). |
| `nr.exposure.v1` | `original_invocation` (same nm I ref), `observation` (same nr ref), `prior_bundle` (nr retained-bundle ref or null), `declared_relation` (predictions_before_learning_result / predictions_after_learning_result / unknown), `declared_prediction_commitment_at` (UTC/null), `declared_first_learned_at` (UTC/null), `basis` (nonempty when relation is known). |
| `nr.authority.v1` | `request` (nr Q ref), `purpose` (literal result_reassessment), `permission` (true/false/unknown strings), `attestor_label` (bounded string), `basis` (nonempty). This is separate local assessment permission, not nm hypothetical-evaluation adoption or authentication. |
| `nr.invocation.v1` | `request` (nr Q ref), `authority` (nr ref), `build` (nr build ref), `resource_policy` (exact approved nm resource-policy ref). External authority pin must equal authority.sha256. |
| `nr.policy.v1` | `qualification` (supplied_support/v1), `envelope_rule` (all_intersecting_branches/v1), `baseline_rule` (frozen_baseline_first/v1), `adoption` (manual_only), `exposure_rule` (local_declarations_not_custody/v1). All literals fixed. |

U has exactly `{kind,lo,hi,unit,basis}`. Kind is declared_point/hard_interval/unknown/
confidence_only. For point, lo=hi=null on input, basis nonempty; derive [x,x]. For
hard_interval, lo/hi are finite R, basis nonempty. For unknown/confidence_only,
lo=hi=null, basis may be empty; preserve statistical claims as basis bytes, never
as elimination bounds. Unit is the exact public unit token admitted for E1 and
mapped by explicit role evidence to the P/O Celsius domain. Missing unit refuses.

T is `{state,start,end,basis}`: known/unknown; known requires ordered UTC start/end
and nonempty basis, unknown requires null endpoints. A declared acquisition end
later than E1's recorded receipt is an inconsistent local declaration and refuses;
unknown acquisition withholds. The receipt timestamp is not certified acquisition
time. Original/result contexts must have identical subject/variable/assertion
context/scenario label; their `as_of` cutoffs may differ. Different configuration
is out of this profile, not repaired by relabelling it “hold”. The hold assertion
covers the entire interval spanning original cutoff and declared acquisition.

`nr.retained-bundle.v1` has C plus `{manifest,files}`. Manifest is the exact parsed
nm bundle manifest; files are sorted `{name,encoding,bytes}` rows for all seven
original files, encoding base64, exact bounded bytes. Validate required names,
canonical contents, manifest digests and full closure; its invocation must equal
the request's original I. No filesystem path or timestamp is added as custody.
If absent, no prior-bundle verification is claimed. If supplied but invalid, refuse,
not downgrade it to absence. Embedded required objects participate in closure
collision checks and resource accounting; preserve original file bytes verbatim.

`nr.build.v1` has C plus `{checkpoint,source_manifest,environment_manifest,entrypoint,
contract_sha256,resource_policy_sha256,supported_nm_contract_sha256}` using the
existing real-build manifest field grammars. The new build must match the actual
executable/dependency/policy identity; no prepared witness or caller assertion.
Original nm build is retained as historical content, not compared to the new
executable as if both builds were identical. The new build explicitly supports
the exact frozen nm input contract and recomputes its baseline/support semantics;
this is new-build reassessment, not execution of the old selector's replay command.
Unsupported historical contract refuses. Original stored scores are not used as
computed facts. A claim of matching original selector execution still requires
the original supported build; this profile cannot create that claim.

## 4. Validation precedence, containment and decoding (H1/L1)

Phases below are ordered. Resource/path guards can refuse at the operation that
would exceed their bounds; no unbounded search for a preferred diagnostic.
Within a reached semantic phase, order by code then ASCII JSON pointer then exact
reference; nm subvalidation retains its established internal precedence. No
later-phase reason is claimed assessed when an earlier phase stops work.

1. Safe bounded capture, canonical wire/header/build/policy dispatch; exact required
   authority pin. Foreign profiles refuse; no guessing grammar from shape.
2. Resolve all typed refs/basis/ancestors, hash/header/role checks before cycle
   traversal; detect identity collisions and missing content. Validate all original
   Q integrity and decoder partitions before using any original support.
3. Validate exact P nomination, O=P.decoder, E0/Q/S joins, observation/execution/
   exposure subjects, revisions, units and authority request/purpose. Reconstruct
   both public snapshots, preserving all existing lower admission checks.
   `original_selection_pin` must equal original I.selection.sha256, with that ref
   resolving as `nm.selection.v1` for original I.request. It is the original
   authority-selection pin, not a digest of the selector's computed result.
   Mismatch refuses `ORIGINAL_SELECTION_PIN_MISMATCH` before assessment. The
   external new authority pin independently binds `nr.authority.v1`.
4. Validate U's shape, rational order and units. If x admitted and U is a hard
   interval, require **lo ≤ x ≤ hi**. Reversed bounds or containment failure:
   `OBSERVATION_UNCERTAINTY_INCONSISTENT`, input exit 3, target `/interpretation`.
   No x replacement, rounding, widened bound, observation-envelope intersection
   or support qualification. Earlier decoder grammar/integrity validation is
   deliberately not blocked by this later containment check. If x is
   unavailable, containment is not assessed, never presumed. Point derives closed
   [x,x] using exact x; derived envelope is null until x is admitted. Its label is
   `declared_point_assumption`, explicitly **not evidence of zero physical error**.
   Validate consistent declared times and exposure shape here as well.
5. Assess separate permission. false/unknown: completed `evaluation_denied` /
   `evaluation_permission_unknown`, no baseline compatibility/decode/support work.
6. Recompute frozen baseline H eligibility; unavailable E0 leaves baseline unknown.
   Assess selected P's original applicability and declared execution conditions,
   receipt/context/hold relationship and E1 availability. false/unknown conditions
   are completed withholding, retaining exact IDs/states/bases. U unknown or
   confidence_only withholds interpretation even if x is known.
7. Decode the full represented interval and qualify applicable H/selected-P cells;
   derive §6 statuses. No ranking is invoked.
8. Bound result/trace/whole bundle, publish immutable report, or technical retention
   refusal with honest absent/incomplete/complete-visible state.

Other proposed input codes: `OBSERVATION_JOIN_MISMATCH`, `RESULT_DOMAIN_UNSUPPORTED`,
`ACQUISITION_DECLARATION_INCONSISTENT`, `EXPOSURE_DECLARATION_INCONSISTENT`,
`ORIGINAL_CONTRACT_UNSUPPORTED`. Missing support is not a technical input error;
malformed nm support still receives the owning contract's technical refusal.
Existing unsupported-exclusion guards remain; there is no production bypass.

Decoder intervals must be the complete disjoint nm partition, including open/closed
endpoint rules. Gaps, overlaps, missing domain coverage or illegal boundaries
receive `DECODER_INVALID`, exit 3 in phase 2, **even outside the observed envelope**.
Represented scalar points are exact; there is no measurement rounding tolerance.
For a valid decoder, B contains each outcome with nonempty set intersection with
the closed envelope **within the declared finite-decimal value domain**. Labels
remain separate. Rational endpoints are comparison boundaries, not an extension
of the admitted value domain to all rationals or reals. A nonempty interval
interior contains finite decimals; an endpoint-only singleton counts iff included
by both sets and its reduced denominator has only factors 2 and 5. Thus [1/3,1/3]
contains no supported scalar value, whereas [1/2,1/2] does. Original decoder
branches remain retained even when empty in that domain; no branch is rewritten
or removed from the original selector. Admitted x in the envelope guarantees at
least one supported value. All comparisons and this singleton test are exact,
bounded rational work, never decimal approximation. Any defensive detection of
uncovered or multiply assigned supported points in
phase 7 refuses `DECODER_INVALID`; never discard portions and assess the rest.
Thus uncertainty crossing a valid boundary is completed ambiguity, whereas an
invalid boundary partition is refusal. Code/out-of-profile values refuse, not
nearest-outcome matching. No empty B can yield a vacuous all-permit/all-exclude.

## 5. Exposure and revision meaning (H2)

Report two independent dimensions:

- `content_relationship`: `original_closure_verified` or, when supplied and
  verified, `prior_bundle_integrity_and_reference_verified`. Report exact original
  I/P/O/S refs, predecessor refs and verified differences, not “provably” custody.
- `chronology`: `declared_pre_exposure_unverified`, `declared_retrospective`, or
  `exposure_unknown`, derived solely from the declared_relation. Optional timestamps
  are labelled declared and must agree with a known declared relation (strictly
  before for before, at/after for after). Contradictory supplied assertions refuse.
  Null times do not invalidate a supported local relation declaration; they do
  not strengthen it. Unknown relation remains unknown even with a prior bundle.

Result wording: “Content and declared dependency relationships verified; chronology
is locally declared and unverified. No independent pre-exposure custody or
predictive-validation claim.” A workstation can verify bytes, references and
recorded predecessor relationships. It cannot establish when an operator first
learned a result from local timestamps, hashes, file presence or receipts. An
untruthful but internally consistent chronology declaration may pass; disclose that
limitation rather than claim detection. No trusted timestamp/authentication system
is introduced. Never emit `provably_pre_exposure` or unqualified “prospective”.

Original predictions, uncertainty, decoder and baseline remain immutable. Each
nr request revision declares its predecessor and carries the complete chain.
If original I/P/O/S/E0 changes, report the exact differing references as a revised
interpretation; do not replace the earlier result. The exposure statement binds
the selected original I for this assessment, not an earlier model opportunistically
reused as proof. A changed model with declared after-exposure status is explicitly
retrospective; a claimed before-exposure change remains an unverified declaration.
No requirement to pretend a historical result was acquired after its baseline.

## 6. Baseline, cell qualification and result meanings (M1)

After permission, compute baseline eligibility only from frozen E0 and H checks.
For each original H retain one row, exact ref and checks:

- `baseline_ineligible`: E0's checks contradict H. Final status for this exact
  captured assessment is `baseline_ineligible`; outcome assessment is
  `not_assessed_baseline_ineligible`, cells null. No resurrection or elimination
  credited to the later observation, regardless of what its branches would say.
- `baseline_unknown`: prerequisite E0 is unavailable; final status unresolved,
  no outcome assessment. Never turn lack of baseline into a contradiction.
- `baseline_eligible`: only these H may receive measurement-derived conclusions.

This is not permanence across versions. A separately authorized new baseline
with its own evidence/authority creates a new assessment and new eligibility.
Earlier baseline findings remain intact. This clarifies the local review rather
than attributing a permanent-ineligibility claim to it.

For each eligible H and **every b in B**, use all Q-nominated S for exact H/P,
including all unavailable/opposing contributions. Require exact decoder, E0 and
context bindings, origin/qualification/uncertainty premises and basis. E1 does
not replace S.evidence. Qualified positive permits require the existing supplied
conditional premise. Exclusion requires explicit warranted exclusion or a
warranted complete envelope; partial positive support never implies complement.
An unavailable S taints all its row cells as in the maintained qualifier; a
conflict in an intersecting cell leaves that cell unknown. Missing, insufficient
or unsupported contributions remain reasoned unknown, never exclusion.

All B cells permits → `compatible_under_declared_model`. All B cells justified
excludes → `conditionally_incompatible`. Otherwise → `unresolved` (mixed relations,
missing support or conflict). No correct diagnosis, physical falsification or
truth is implied. Missing cells outside B do not themselves block this assessment;
report `ranking_not_reassessed` and do not change original whole-set withholding.
Full known all-excluded prediction rows remain invalid under nm semantics; this
is not licensed by branch-local evaluation. Such row validity must be checked
for all outcomes of each assessed H/P before interpreting its B cells.

Aggregate precedence: denial/unknown permission; unavailable baseline; then
`no_baseline_eligible_hypotheses` if none eligible (never vacuous model mismatch);
then completed execution/evidence/uncertainty withholding; then assessment summary.
Within reached withholding retain all reasons in phase/condition/code/ref order.
For assessed eligible H: all incompatible → `model_prediction_mismatch`; otherwise
any unresolved → `incomplete_assessment` (include compatible/incompatible lists);
otherwise one compatible → `one_compatible`; more than one → `multiple_compatible`.
Zero compatible plus unresolved is not no-fit. No derived “survivor” set silently
drops baseline-ineligible or unresolved H: all original rows remain visible.

Proposed closed `nr.result.v1` fields: `schema,profile,invocation,authority,
original,observation,interpretation,exposure,hypotheses,summary,adoption,accounting`.
Authority = `{reference,pin,permission}`. Original = `{invocation,request,procedure,
decoder,evidence,hypotheses,ranking}` with ranking literal not_reassessed.
Observation = `{reference,evidence,availability,scalar,occurrence_id,raw_record_id,
payload_checksum,unit,received_at,as_of,reasons}`; unavailable scalar/provenance
fields are null as required by public admission, reasons retained. Interpretation
= `{state,envelope,branches,reasons}`, envelope null or `{lo,hi,lower_closed:true,
upper_closed:true,basis_kind,basis}`, branches null when not assessed, otherwise
ID-ordered `{outcome,intersection}`. Intersection is exactly
`{lo,hi,lower_closed,upper_closed}` with finite R endpoints and Boolean flags,
denoting the clipped interval restricted to finite-decimal values as in §4;
only nonempty such intersections appear. A rational endpoint does not assert
that the endpoint itself is a supported scalar. Exposure
= `{reference,content_relationship,chronology,declared_prediction_commitment_at,
declared_first_learned_at,changed_references,limitation}`; limitation is the fixed
wording in §5, changed_references sorted `{path,before,after}` exact refs/null.
Hypotheses are original-ID-ordered `{reference,baseline,baseline_checks,status,
outcome_state,cells,reasons}`, cells null if unassessed or outcome-ID-ordered
`{outcome,relation,sources,reasons}`. Reasons are closed `{code,path,references}`,
refs sorted; baseline_checks reuse maintained check rows. Summary = `{disposition,
compatible,incompatible,unresolved,baseline_ineligible,reasons}` with sorted refs;
unassessed categories are null, assessed empty categories are []. Adoption is
literal `derived_not_adopted`. Accounting = `{logical,physical}` with physical
literal `recorded_in_manifest`, logical the reached named counts from §8.

Trace has exactly `{schema,profile,invocation,required_closure,phases,dependencies}`;
phases are ordered `{phase,state,reasons}` (assessed/not_assessed); dependencies
are sorted `{result_path,references}`. Permission-blocked H rows retain identities
but baseline/status are not_assessed, checks/cells null. Other blocked eligible
rows are unresolved with exact withholding reasons. This is an output specification,
not a caller-supplied conclusion interface.

## 7. Required closure, retention, replay and manual lifecycle

Every schema-table Ref, basis ref, original nm typed edge and declared predecessor
is required transitively through revision 1. Original nm build/resource-policy
and every declaration-member Q remain required. Shared dependencies are stored
once after byte identity checks but every incoming edge is charged; active-path
cycles refuse. Same kind/id/revision with different bytes refuses globally;
nomination IDs/order/aliases retain nm semantics. Historical nr requests receive
integrity, joins, reconstruction and containment validation, not fresh eligibility
or support adjudication. Historical unknown/retrospective declarations do not
poison a current complete assessment. No digest-only terminal witness; no optional
history is pulled in by path discovery. Supplied prior bundles become required
content; absent ones imply no custody claim. No unlimited revisions or implicit
squashing; complete closure over the supported history envelope or refusal.

Proposed separate application commands follow the maintained pattern:
`reassessment-evaluate --invocation FILE --objects-dir DIR --authority-pin SHA --output-dir NEWDIR [--limits FILE]`,
`reassessment-verify --bundle DIR`, and
`reassessment-replay --bundle DIR --output-dir NEWDIR [--limits FILE]`.
Unknown/repeated flags refuse. Required filename is `<sha256>.<kind>`; filenames
do not nominate anything. Capture once using maintained root containment,
no-follow regular-file rules, read-race checks and supported local filesystem
policy. No callback, bypass, automatic authority discovery or original-file reread.

New profile retains seven files with the established names, under distinct nr
envelopes: invocation, closure, result, trace, build, policy, then manifest last.
Closure fields `{schema,profile,invocation,authority_pin,limits_override,members}`
use sorted `{reference,encoding:base64,bytes}` exact members. Policy/build files
must equal their captured copies. Manifest/receipt/diagnostic field layouts and
bounded stream/exit rules reuse nm shapes with nr schema/profile and operation
literals; receipt disposition is reassessment summary, never ranking. Exit 0 is
a completed report, including withholding; exits 2/3/4/5/6/7 remain usage/input/
resource/path/retention/internal. No-overwrite, incomplete publication and durability
limitations remain. No change to any existing nm bundle interpretation.

Verify establishes stored integrity/closure/build and public joins, not renewed
semantic conclusions. Replay recovers all captured bytes without original paths,
reconstructs E0/E1, validates declarations, repeats permission/baseline/decoding/
qualification and compares fresh semantic result/trace. Physical counters are
fresh, outside deterministic semantic comparison. Rehashed forged conclusions
must fail replay. Replay uses the exact nr executable/environment/policy; historic
nm witness remains a content dependency as specified in §3. No current applicability
or adoption follows. Qualification of portability/durability remains future work.

User manually chooses whether to adopt a working interpretation; this profile
implements no adoption, mutation or reranking endpoint. Any later Q explicitly
names its H and future P, holds its own authority, and retains adoption/reassessment
basis. Original Q and all H rows remain unchanged. An obtained P is historical;
future repetition is a new explicit nomination. The existing selector requires
its complete whole-nominated matrix even when reassessment could reason locally.

## 8. Minimal decisive proof and resource obligations — planned only

Base: both H baseline-eligible, one selected nominated scalar P; decoder
L=(-∞,50], H=(50,70], X=(70,∞). H1 permits H/excludes L,X; H2 permits L/excludes H,X,
with warranted exclusions and immutable supplied synthetic predictions. The other
original nominated P remains captured, not reassessed. Public E1 admits x, exact
unit/subject; authority permits; original and execution applicability/hold true.
These premises are explicit local assumptions, never physical-performance proof.

| Proof / finding | Adverse or boundary and nearest valid twin; expected evidence |
| --- | --- |
| P1 scalar / L1 | x=60 point becomes [60,60]: H1 compatible/H2 incompatible; x=40 reverses. Hard [60,60] has same branches/status but preserves different declared basis. Neither proves zero physical error. |
| P2 containment / H1 | x=60.1 with [40,50], [61,62], or reversed [61,59] refuses code/exit in §4 with zero decoding/qualification. Twin [59.5,60.5] passes containment and maps H. Wrong-unit twin refuses joins earlier. |
| P3 endpoints | x=50, [49,51] and [50,51] map L/H → both unresolved. [49,50] and point 50 map L. Point 70 maps H; [70,71] maps H/X. Independent rational set intersections include singleton endpoints. |
| P3b domain singleton | Coherent three-region decoder (-∞,1/3), [1/3,1/3], (1/3,∞), x=0 with envelope [0,1/3]: only the first branch intersects the supported finite-decimal domain. Twin boundary 1/2 includes its singleton branch as well. Preserve both decoders' original three identities. Never approximate 1/3 or manufacture a public point observation at 1/3. |
| P4 gaps/overlaps | Correctly rehash a decoder leaving 50 uncovered, doubly covered, or a finite-domain gap outside [59,61], with coherent references to avoid earlier joins. All DECODER_INVALID, not partial decoding. Original contiguous partition is valid twin. Literal-code/result-domain substitution refuses unsupported scope. |
| P5 support/mismatch | x=80: both exclude X → mismatch. Remove one X exclusion → unresolved/incomplete, not no-fit. Add opposing positive S → conflict unresolved. x=60 with missing unrelated L cell can remain compatible for H1; an unavailable row source taints H1's H cell and withholds it. Warranted exclusion and complete positive twins; no complement inference. |
| P6 mixed/multiple | [49,51] with permits/excludes mixed gives unresolved. New coherently bound S permitting both L/H for both H gives multiple compatible. Fully all-excluded row refuses nm row validity, not mismatch evidence. |
| P7 baseline / M1 | E0 makes H2 ineligible; result would either permit or exclude it: both keep baseline_ineligible, no H2 outcome cells. Both H baseline-ineligible → no_baseline_eligible_hypotheses, not mismatch. Separate authorized revised baseline may make H2 eligible, as a new request; old row unchanged. |
| P8 exposure / H2 | Verified prior bundle plus before declaration yields declared_pre_exposure_unverified, never provably. Same without bundle lacks only integrity evidence. After/unknown stay retrospective/unknown even with bundle. Inconsistent time assertions refuse. An internally consistent false chronology is not detectable; no proof case may claim otherwise. |
| P9 revisions/substitution | Correctly rehash P edition, O or context while retaining stale support/observation joins: semantic-join refusal, not digest failure. Coherently rebound new request/support/execution/exposure is valid, disclosed interpretation. After seeing 80 revise permits to X: old mismatch stays; new retrospective fit is not prospective confirmation. |
| P10 gates/replay | Denied vs permitted authority; unknown hold vs true; unavailable E0/E1 vs admitted: preserve distinct reached phases. Missing ancestor, collision and resource refusal versus complete shared-DAG twins. Standalone matching-build replay with originals absent succeeds only in future proof; rehashed forged result fails recomputation, wrong build/policy refuses. No automatic reranking. |
| P10b original pin | Valid closure but a different well-formed original_selection_pin refuses ORIGINAL_SELECTION_PIN_MISMATCH in phase 3. Twin uses exactly original I.selection.sha256. Independently wrong external nr authority pin refuses in phase 1; a computed nm.result digest never substitutes for either authority pin. |

Future oracle must enumerate interval intersections and per-cell truth tables
independently of runtime outputs, include construction/order permutations, exact
diagnostic precedence and zero-work assertions. Distinguish public digest-before-
cycle cases from test-only synthetic graph traversal; no public SHA-consistent
cycle claim. No new harness bypass is needed: unsupported exclusion is checked by
the real negative/valid twins. If a counterfactual control is later approved, it
must stay outside production. Same-author arithmetic checks are not independent
empirical evidence. No cases have been executed and no fixture bytes are claimed.

Future resource preparation must account for E0/E1 public reconstruction separately,
unique/shared objects, all reference occurrences, scoped scans, full predecessor
chains and embedded prior-bundle bytes, rational intermediates, containment and
intersection comparisons and bounded denominator-factor checks, all source contributions/row validity and output/trace
construction. Separate deterministic logical counts from physical reads/writes,
recovery, CPU/wall/RSS and total retained fit, including base64 and repeated copies.
Additional logical counters are named `containment_comparisons`,
`interval_intersections`, `baseline_checks`, `qualified_cells`, `source_contributions`,
`prior_bundle_bytes`, alongside existing measurement counters. Charge underlying
operations to existing bounds as well; these counters confer no unbounded work.
Guard before allocation/traversal/reconstruction/publication. Preserve approved
128-object, four-complete-revision, eight-context and 1 MiB capture/bundle ceilings
and all narrower byte/node/work limits. Count each distinct scoped original Q and
reassessment request toward the context ceiling. No new numerical capacity is
invented; combined feasibility, reserves, exact-limit/plus-one cases and retained
fit require separately authorized preparation and policy approval before code.

## 9. Decisions and next gate

Recommended application-only first scope: one scalar result/one P, exact point or
justified hard interval, baseline precedence, branch-local unanimity, separately
pinned local permission and truthful exposure declarations, derived reporting and
manual adoption. Genuine owner decisions are approval of those semantics, the
new profile/command/retention contract, explicit historical-nm/new-build treatment,
and whether to authorize bounded fixture/resource preparation after review. No
existing permission is interpreted as implementation approval.

Focused independent re-review must examine H1/H2/M1/L1 and consequential joins,
coverage quantifiers, provenance, build/replay and resource boundaries. It must
challenge the rejected custody tier rather than rubber-stamp the original review.
Any remaining defect or disagreement is recorded separately; neither review nor
local receipt demonstrates pre-exposure custody. Only after owner design approval
and measured package/resource approval may implementation be separately scoped.

END OF CORRECTED REASSESSMENT CANDIDATE — DOCUMENTATION ONLY.
