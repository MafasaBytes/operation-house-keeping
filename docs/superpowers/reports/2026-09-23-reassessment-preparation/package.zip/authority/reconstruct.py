"""Static carriage witness checker. No application imports or semantic execution.

Run: python reconstruct.py WITNESS.json NEW_OUTPUT_DIRECTORY
Writes seven recovered files plus static-check.json to a newly created directory.
This deliberately narrow audit program is not a future production validator.
"""
import base64
import hashlib
import json
import pathlib
import sys


def canonical(v):
    return json.dumps(v, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode()


def digest(b):
    return hashlib.sha256(b).hexdigest()


def key(r):
    assert set(r) == {"kind", "sha256"}
    assert len(r["sha256"]) == 64
    assert all(c in "0123456789abcdef" for c in r["sha256"])
    return r["kind"], r["sha256"]


def reference(k):
    return dict(kind=k[0], sha256=k[1])


NAMES = sorted(["invocation.json", "closure.json", "result.json", "trace.json",
                "build.json", "policy.json", "manifest.json"])
CAPS = dict(zip(["invocation.json", "closure.json", "result.json", "trace.json",
                 "build.json", "policy.json", "manifest.json"],
                [16384, 524288, 65536, 131072, 65536, 262144, 16384]))
ROLES = {"invocation.json": "nm.invocation.v1", "build.json": "nm.build.v1",
         "policy.json": "nm.resource-policy.v1", "result.json": "nm.basis",
         "trace.json": "nm.basis", "manifest.json": "nm.basis"}
SCHEMAS = dict(ROLES, **{"result.json": "nm.result.v1",
                         "trace.json": "nm.trace.v1", "manifest.json": "nm.bundle.v1"})


def json_dimensions(value):
    nodes, strings, depth = 0, 0, 0
    pending = [(value, 1)]
    while pending:
        v, d = pending.pop()
        nodes += 1
        depth = max(depth, d)
        if isinstance(v, str):
            strings = max(strings, len(v.encode()))
        elif isinstance(v, dict):
            strings = max([strings] + [len(k.encode()) for k in v])
            pending.extend((child, d + 1) for child in v.values())
        elif isinstance(v, list):
            pending.extend((child, d + 1) for child in v)
    assert strings <= 4096 and depth <= 40 and nodes <= 65536
    return nodes, strings, depth


def original_edges(v):
    """Fixed accepted nm reference roles, manually transcribed for this audit."""
    out = []

    def one(path, r, kind):
        if r is not None:
            assert key(r)[0] == kind, (path, "role")
            out.append((path, key(r)))

    def many(field, kind):
        for i, r in enumerate(v[field]):
            one('/' + field + '/' + str(i), r, kind)

    k = v['schema']
    if k == 'nm.invocation.v1':
        for f, t in [('request', 'nm.request.v1'), ('selection', 'nm.selection.v1'),
                     ('adoption', 'nm.adoption.v1')]:
            one('/' + f, v[f], t)
        for f, t in [('build_identity', 'nm.build.v1'), ('resource_policy', 'nm.resource-policy.v1')]:
            one('/' + f, dict(kind=t, sha256=v[f]), t)
    elif k == 'nm.request.v1':
        for f, t in [('evidence', 'nm.evidence.v1'), ('policy', 'nm.policy.v1'), ('predecessor', k)]:
            one('/' + f, v[f], t)
        for f, t in [('hypotheses', 'nm.hypothesis.v1'), ('measurements', 'nm.procedure.v1'), ('support', 'nm.support.v1')]:
            many(f, t)
    elif k in ('nm.selection.v1', 'nm.adoption.v1'):
        one('/declaration', v['declaration'], 'nm.declaration.v1')
        one('/request', v['request'], 'nm.request.v1')
        if k == 'nm.adoption.v1':
            one('/selection', v['selection'], 'nm.selection.v1')
    elif k == 'nm.declaration.v1':
        many('requests', 'nm.request.v1')
    elif k in ('nm.hypothesis.v1', 'nm.procedure.v1', 'nm.support.v1'):
        one('/evidence', v['evidence'], 'nm.evidence.v1')
        if k != 'nm.hypothesis.v1':
            one('/decoder', v['decoder'], 'nm.decoder.v1')
        if k == 'nm.support.v1':
            one('/hypothesis', v['hypothesis'], 'nm.hypothesis.v1')
            one('/procedure', v['procedure'], 'nm.procedure.v1')
            many('basis', 'nm.basis')
            many('exclusion_basis', 'nm.basis')
            for i, r in enumerate(v['uncertainty']['basis']):
                one('/uncertainty/basis/' + str(i), r, 'nm.basis')
        if k == 'nm.procedure.v1':
            for i, c in enumerate(v['conditions']):
                for j, r in enumerate(c.get('basis', [])):
                    one(f'/conditions/{i}/basis/{j}', r, 'nm.basis')
    elif k == 'nm.evidence.v1':
        for i, r in enumerate(v['token_roles']['basis']):
            one('/token_roles/basis/' + str(i), r, 'nm.basis')
    return sorted(out)


def recover(wire):
    assert len(wire) <= 524288
    w = json.loads(wire)
    assert canonical(w) == wire
    assert set(w) == {'schema', 'descriptor', 'members'}
    assert w['schema'] == 'nr.carriage-witness.v2'  # not an application invocation
    pool = {}
    for m in w['members']:
        assert set(m) == {'reference', 'encoding', 'bytes'} and m['encoding'] == 'base64'
        k = key(m['reference'])
        assert k not in pool
        b = base64.b64decode(m['bytes'], validate=True)
        assert base64.b64encode(b).decode() == m['bytes']
        assert len(b) <= 262144 and digest(b) == k[1]
        pool[k] = b
    assert list(pool) == sorted(pool) and len(pool) <= 128
    assert sum(map(len, pool.values())) <= 1048576
    root = key(w['descriptor'])
    d = json.loads(pool[root])
    assert canonical(d) == pool[root]
    assert set(d) == {'schema', 'profile', 'id', 'revision', 'predecessor', 'files', 'closure'}
    assert d['schema'] == root[0] == 'nr.retained-bundle.v2'
    assert d['profile'] == 'measurement-reassessment/v2'
    assert d['revision'] == 1 and d['predecessor'] is None
    dimensions = [json_dimensions(d)]
    assert [r['name'] for r in d['files']] == NAMES
    recipe = d['closure']
    assert set(recipe) == {'schema', 'profile', 'invocation', 'authority_pin', 'limits_override', 'members'}
    assert recipe['schema'] == 'nm.closure.v1' and recipe['profile'] == 'bdw.measurement.supplied.v1'
    original = [key(r) for r in recipe['members']]
    assert original == sorted(set(original))
    reached, active, occurrences, identities = set(), set(), [], {}

    def walk(k, depth=1):
        assert depth <= 32 and k in pool
        b = pool[k]
        assert digest(b) == k[1]
        v = None if k[0] == 'nm.basis' else json.loads(b)
        if v is not None:
            assert v['schema'] == k[0] and canonical(v) == b
            ident = (k[0], v['id'], v['revision'])
            assert identities.setdefault(ident, k[1]) == k[1]
            if k[0] == 'nm.request.v1':
                assert v['revision'] <= 4
                if v['predecessor'] is not None:
                    old = json.loads(pool[key(v['predecessor'])])
                    assert old['id'] == v['id'] and old['revision'] == v['revision'] - 1
        assert k not in active
        if k in reached:
            return
        if v is not None:
            dimensions.append(json_dimensions(v))
        active.add(k)
        for path, target in [] if v is None else original_edges(v):
            occurrences.append((k, path, target))
            assert len(occurrences) <= 4096
            walk(target, depth + 1)
        active.remove(k)
        reached.add(k)

    walk(key(recipe['invocation']))
    assert reached == set(original), 'missing or extraneous original closure member'
    iv = json.loads(pool[key(recipe['invocation'])])
    assert recipe['authority_pin'] == iv['selection']['sha256']
    closure = dict(recipe, members=[dict(reference=reference(k), encoding='base64',
                                         bytes=base64.b64encode(pool[k]).decode()) for k in original])
    recovered = {}
    file_refs = []
    for row in d['files']:
        assert set(row) == {'name', 'source'}
        name, src = row['name'], row['source']
        if name == 'closure.json':
            assert src == {'recipe': 'original_closure'}
            data = canonical(closure)
        else:
            assert set(src) == {'reference'}
            k = key(src['reference'])
            assert k[0] == ROLES[name]
            file_refs.append(k)
            data = pool[k]
            v = json.loads(data)
            assert canonical(v) == data and v['schema'] == SCHEMAS[name]
            assert v['profile'] == 'bdw.measurement.supplied.v1'
            if k[0] == 'nm.basis':
                dimensions.append(json_dimensions(v))
        assert len(data) <= CAPS[name]
        recovered[name] = data
    assert set(pool) == reached | set(file_refs) | {root}
    assert recovered['invocation.json'] == pool[key(recipe['invocation'])]
    assert digest(recovered['build.json']) == iv['build_identity']
    assert digest(recovered['policy.json']) == iv['resource_policy']
    for name in ['result.json', 'trace.json']:
        assert json.loads(recovered[name])['invocation'] == recipe['invocation']
    manifest = json.loads(recovered['manifest.json'])
    assert manifest['completeness'] == 'complete'
    assert [r['name'] for r in manifest['files']] == ['invocation.json', 'closure.json', 'result.json',
                                                    'trace.json', 'build.json', 'policy.json']
    for r in manifest['files']:
        assert set(r) == {'name', 'bytes', 'sha256'}
        assert len(recovered[r['name']]) == r['bytes'] and digest(recovered[r['name']]) == r['sha256']
    assert sum(map(len, recovered.values())) <= 1048576
    report = dict(schema='static-carriage-check/v1', original_members=len(original),
                  original_reference_occurrences=len(occurrences),
                  descriptor_reference_occurrences=len(original) + len(file_refs) + 1,
                  pool_objects=len(pool), unique_captured_bytes=sum(map(len, pool.values())),
                  encoded_member_bytes=sum(len(m['bytes']) for m in w['members']),
                  witness_wire_bytes=len(wire), descriptor_bytes=len(pool[root]),
                  reconstructed_closure_bytes=len(recovered['closure.json']),
                  recovered_bundle_bytes=sum(map(len, recovered.values())),
                  max_ordinary_string_bytes=max(x[1] for x in dimensions),
                  max_json_depth=max(x[2] for x in dimensions),
                  unique_parsed_json_value_nodes=sum(x[0] for x in dimensions),
                  files=[dict(name=n, bytes=len(b), sha256=digest(b)) for n, b in sorted(recovered.items())],
                  limitation='Static identity/reconstruction checks only; no public admission, build execution, or reassessment.')
    return recovered, report


if __name__ == '__main__':
    data = pathlib.Path(sys.argv[1]).read_bytes()
    files, report = recover(data)
    destination = pathlib.Path(sys.argv[2])
    destination.mkdir()  # fail if anything exists; no overwrite or cleanup
    for name, raw in files.items():
        with (destination / name).open('xb') as stream:
            stream.write(raw)
    with (destination / 'static-check.json').open('xb') as stream:
        stream.write(canonical(report))
    print(canonical(report).decode())
