# Measurement-result reassessment — independent adversarial review

2026-09-23. Design review only. No implementation, tests, application execution, experiment, production changes, milestone allocation or ADR allocation.

## 1. Provenance, object, verification and verdict

I am the separately staffed `independent_adversarial_reviewer` agent, delegated solely to review the measurement-result reassessment lead proposal. I did not author, edit, or contribute to that proposal and have no implementation role. This is separate reviewer staffing within the same model family and tool environment, not an external human review, empirical independence, independent physical evidence, or independent acceptance of historical same-author oracles. The lead author and owner may verify this report's artifact integrity and repository preservation; its adversarial findings and recommendations are this reviewer's sole responsibility.

### Checkpoint and frozen input verification

- **Local branch, tracking and HEAD**: Verified local `main`, tracking `origin/main`, at exact checkpoint commit `15bd9dcb1559898944149cab0ec78b962019ab50`.
- **Tracked working tree**: Clean (0 modified, 0 staged).
- **Reviewed Object**: Complete frozen lead proposal [`docs/superpowers/reports/2026-09-23-measurement-result-reassessment-lead-proposal.md`](file:///d:/operation-house-keeping/docs/superpowers/reports/2026-09-23-measurement-result-reassessment-lead-proposal.md), lines 1–225, 19,784 bytes.
- **Frozen Proposal SHA-256**: `6a11958e692d620be6cacd9a84ef2332eb6bf23fb42edc2a4276ba3045864f28` (verified byte-for-byte).
- **Relevant Contracts Inspected**:
  - Maintained Next-Measurement contracts: [`measurement_wire.py`](file:///d:/operation-house-keeping/applications/bounded_decision_workflow/measurement_wire.py), [`support_qualification.py`](file:///d:/operation-house-keeping/applications/bounded_decision_workflow/support_qualification.py), [`measurement_compute.py`](file:///d:/operation-house-keeping/applications/bounded_decision_workflow/measurement_compute.py), [`measurement_ranking.py`](file:///d:/operation-house-keeping/applications/bounded_decision_workflow/measurement_ranking.py).
  - Maintained Public Admission: [`admission.py`](file:///d:/operation-house-keeping/applications/bounded_decision_workflow/admission.py), [`backend/observation_compatibility/contracts.py`](file:///d:/operation-house-keeping/backend/observation_compatibility/contracts.py).

### Verdict

**`approve_with_corrections`** (Conditionally approved).

The proposal establishes an epistemically disciplined, mathematically rigorous approach to updating hypothesis viability under an explicitly supplied measurement observation. Crucially, it respects the core architecture by maintaining that reassessment is a *derived diagnostic report*, not an autonomous mutator of ledgers, working adoption, or hypothesis sets.

However, **2 High-severity** and **1 Medium-severity** technical clarifications must be resolved in the proof design before contract freeze or implementation authorization.

Finding summary: **0 Critical, 2 High, 1 Medium, 1 Low/Nonblocking**.

---

## 2. Severity-ranked findings and minimal required corrections

### Finding H1 (High) — Inconsistent observation-to-uncertainty envelope must produce a technical refusal, not decode to bounds

**Observation**:
Section 3 (line 75) states:
> *"Interpretation: Immutable observed scalar plus separately declared uncertainty. First scope: exact point, or a finite closed rational interval containing that scalar with explicit hard-bound basis; unknown uncertainty is unresolved."*

Section 4 (lines 99–105) describes decoding the justified hard interval across intersecting decoder branches.

**Vulnerability**:
The proposal leaves undefined what occurs if the caller supplies an admitted scalar observation $x$ from public evidence, but the separately declared uncertainty envelope $[lo, hi]$ fails to contain $x$ (i.e. $x < lo$ or $x > hi$, such as an admitted sensor reading of $60.1$ °C paired with a declared uncertainty interval of $[40, 50]$ °C).
If an implementation blindly passes the declared interval $[lo, hi]$ to the decoder intersection logic without verifying containment against the admitted scalar, an adversarial or corrupted uncertainty envelope could substitute an entirely fictitious observation range. This would allow an analyst to manufacture artificial compatibility or bypass a genuine model mismatch.

**Minimal Required Correction**:
The preflight admission check for reassessment must enforce exact containment:
$$lo \le x \le hi$$
where $x$ is the reconstructed canonical decimal fraction and $lo, hi$ are the rational interval bounds. Any violation must trigger an immediate technical refusal (`OBSERVATION_UNCERTAINTY_INCONSISTENT`, exit code 3), terminating processing before decoder intersection or support qualification.

---

### Finding H2 (High) — Reassessment must partition exposure status into verifiable prior retention vs. unverified local chronology

**Observation**:
Section 3 (line 76) and Section 4 (line 95) note:
> *"Exposure record: Exact original prediction/support/decoder commitments and their asserted commitment time; result exposure state `before/after/unknown`, available timestamps and local basis. Missing chronology means unknown, not prospective. Content hashes prove identity, not that predictions were committed before exposure."*
> *"Do not auto-detect or certify a person's prior knowledge from timestamps."*

**Vulnerability**:
While the proposal correctly acknowledges that content hashes prove identity rather than chronological time, it relies on an asserted field `result_exposure: before/after/unknown`. On an unauthenticated local workstation, an operator who has already seen an unexpected measurement result ($T_1 = 80$ °C) could construct a revised scenario that accommodates this result, set `result_exposure: before`, and generate a valid reassessment bundle claiming prospective confirmation.
Because timestamps are unauthenticated, callers and downstream tools could easily mistake a declared `"before"` assertion for independent, verified proof of prospective predictive validity.

**Minimal Required Correction**:
The derived assessment report must formally distinguish and report two strictly separate tiers of pre-exposure status:
1. `provably_pre_exposure`: The exact prediction and decoder package SHA-256 is present in an existing, immutable, retained output bundle whose manifest timestamp strictly precedes the observation's ingestion cutoff in the local store.
2. `declared_pre_exposure_unverified`: The caller asserts pre-exposure commitment, but no independent prior bundle receipt exists in the local store to prove custody prior to observation ingestion.
3. `disclosed_retrospective_or_unknown`: The caller explicitly discloses post-exposure formulation or unknown chronology.

The application must never emit an unqualified `prospective` label without provable antecedent bundle custody.

---

### Finding M1 (Medium) — Formalize precedence between antecedent baseline ineligibility and measurement-result contradiction

**Observation**:
Section 4 (lines 118–119) states:
> *"Keep baseline H findings separate; an already baseline-ineligible H is labelled as such, not newly eliminated by this observation. All original H remain in the report."*

**Vulnerability**:
If an admitted baseline observation (at $t_0$) already contradicts hypothesis $H_2$ (rendering it `baseline_ineligible`), and the subsequent measurement $T_1$ (at $t_1$) also yields an outcome that excludes $H_2$, an ambiguous reporting structure might double-count the contradiction, report $H_2$ as "eliminated by $T_1$", or conversely mask the baseline failure.

**Minimal Required Correction**:
The reassessment result schema must formalize a strict two-stage epistemic hierarchy:
1. **Antecedent Baseline Status**: Evaluated strictly from baseline evidence $E_0$. Hypotheses are partitioned into $H_{\text{viable}}$ and $H_{\text{baseline\_ineligible}}$.
2. **Measurement Outcome Compatibility**: Evaluated strictly for hypotheses in $H_{\text{viable}}$.
If $h \in H_{\text{baseline\_ineligible}}$, its status in the reassessment report is fixed as `ineligible_at_baseline` with its original reason. The measurement observation $T_1$ is neither credited with eliminating $h$ nor permitted to resurrect $h$ as compatible.

---

### Finding L1 (Low / Nonblocking) — Represent exact scalar point observations as canonical degenerate closed intervals

**Observation**:
Section 3 (line 75) describes the interpretation as an "exact point, or a finite closed rational interval containing that scalar".

**Observation / Simplification**:
Maintaining separate code paths for point evaluation vs. interval evaluation introduces redundant branch-checking logic in the decoder. An exact scalar point $x$ is mathematically and semantically identical to the degenerate closed interval $[x, x]$ ($lo = x, hi = x, \text{lower\_closed} = \text{True}, \text{upper\_closed} = \text{True}$).

**Minimal Required Correction**:
Canonicalize point observations internally into degenerate closed intervals $[x, x]$. This allows a single, unified interval-intersection algorithm to handle both exact points and uncertainty bounds without code duplication or semantic drift.

---

## 3. Technical analysis against the challenge dimensions

### 1. Scalar result and uncertainty
- **Observation Representation**: The public admission adapter `_admit_observed_value` reliably reconstructs public evidence and extracts canonical decimal scalars. Reusing this adapter ensures that observation values are anchored to verified public state classifications.
- **Uncertainty Bounds**: The proposal's rule—requiring a justified closed rational interval $[lo, hi]$ with hard-bound basis, and rejecting statistical confidence intervals from authorizing exclusions—is mathematically sound.
- **Boundary & Decoders**: The decoder contract in [`measurement_wire.py`](file:///d:/operation-house-keeping/applications/bounded_decision_workflow/measurement_wire.py) enforces contiguous intervals with alternating open/closed boundaries (e.g. $L=(-\infty, 50]$, $H=(50, 70]$). An interval $[49, 50]$ strictly intersects $L$. An interval $[50, 51]$ intersects both $L$ and $H$. The rule requiring retention of *every* intersecting branch without nearest-branch rounding guarantees that measurement ambiguity is preserved rather than smoothed away.

### 2. Prediction qualification and branch-local reasoning
- **Soundness of Branch-Local Qualification**:
  - In next-measurement *ranking* (`rank_measurements`), the entire matrix must be known to prevent artificial winners.
  - In *reassessment*, the measurement has already been executed, and the observation has decoded to a specific set of intersecting branches $B$.
  - Testing compatibility of $H$ with the observed outcome $B$ depends strictly on whether $H$ permits $B$ or excludes $B$. Unobserved branches ($o \notin B$) have no physical or logical bearing on whether $H$ is consistent with the observed reality.
  - **Verdict on Branch-Local Reasoning**: **Branch-local reasoning is fully sound**, provided that:
    1. Positive support on one branch never licenses complement exclusion on another.
    2. Incompatibility requires justified exclusion across *all* intersecting branches $b \in B$.
    3. Any ungrounded or conflicting cell within $B$ forces the status of that hypothesis to `unresolved`.
    4. Unsupported exclusions are rejected by the existing [`support_qualification.py`](file:///d:/operation-house-keeping/applications/bounded_decision_workflow/support_qualification.py) rules.

### 3. Observation-to-procedure joins
- **Semantic Substitution Attacks**:
  - In addition to hash checks, reassessment must verify semantic consistency:
    - `subject_entity_anchor_id` and `variable_anchor_id` in the observation must match the nominated procedure's declared target.
    - `method` and `method_edition` must match the nominated procedure edition.
    - `unit` must match the decoder domain unit (e.g. `degree_celsius`).
- **Timing and Invariance Joins**:
  - A real measurement is observed at $t_1 > t_0$ (where $t_0$ is baseline cutoff). Requiring $t_1 == t_0$ would be impossible.
  - The proposal correctly requires an explicit **hold/invariance assertion** linking the system state from $t_0$ to $t_1$. If hold conditions are unknown or unverified, the reassessment must withhold interpretation.

### 4. Exposure and revisions
- **Epistemic Boundaries of Local Timestamps**:
  - SHA-256 hashes prove byte integrity, not chronological precedence.
  - A post-exposure revision that is re-hashed cannot be mechanically distinguished from a pre-exposure prediction unless tied to a prior committed bundle manifest (Finding H2).
  - The proposal is candid that retrospective revisions cannot claim prospective validation.

### 5. Adoption and hypothesis sets
- **No Autonomous Mutation**:
  - Reassessment outputs a derived evaluation report. It does **not** update ledgers, modify working adoption, or automatically prune hypothesis sets.
  - **Handling of Discrepant Outcomes**:
    - *No-fit (all hypotheses excluded)*: Reports `model_prediction_mismatch`. It does not invent hypotheses or pick the "closest" fit.
    - *Multiple-fit (multiple hypotheses compatible)*: Reports ambiguity; all compatible hypotheses remain retained.
    - *Zero compatible with unresolved*: Reports `insufficient_support`, not a proven mismatch.
  - Handoff to any future ranking request remains strictly **manual**, requiring an explicit new request $Q'$.

### 6. Composition and replay
- **Application Boundary**: Reassessment is implemented strictly as a new workflow in `applications/bounded_decision_workflow/`. It introduces no backend changes, no new ledger types, and ADR-0023 remains unreserved.
- **Deterministic Replay**: A reassessment bundle can be re-executed from its captured inputs (`request`, `observation`, `predictions`, `build_identity`), yielding bit-for-bit identical status reports across platforms.

### 7. Minimal proof assessment
- The 9 proposed test cases in Section 6 provide thorough coverage:
  - Discriminating positive cases ($T_1=60$ vs $T_1=40$).
  - Ambiguous multiple-fit ($T_1=60$ compatible with both).
  - No-fit / model mismatch ($T_1=80$).
  - Missing and conflicting support (leading to `unresolved`).
  - Boundary interval intersections ($[49, 51]$ vs $[49, 50]$).
  - Semantic join tamper resistance.
  - Disclosed retrospective revisions.
- Redundant cases: Thermal equation evaluations and action projections must be excluded from this test suite.

---

## 4. Adversarial cases, counterfactual controls and nearest valid twins

| Case Identifier | Hostile / Boundary Condition | Required System Behavior | Nearest Valid Twin | Accepted Coverage Reused |
| :--- | :--- | :--- | :--- | :--- |
| **ADV-RE-01** (Inconsistent Uncertainty) | Admitted scalar is $60.1$ °C; caller supplies hard uncertainty interval $[40, 50]$ °C. | Preflight technical refusal `OBSERVATION_UNCERTAINTY_INCONSISTENT` (exit 3); zero decoding. | Valid containment: scalar $60.1$ °C with interval $[59.5, 60.5]$ °C. | Finding H1. |
| **ADV-RE-02** (Boundary Straddle Ambiguity) | Decoder has boundary at 50 °C ($L=(-\infty, 50]$, $H=(50, 70]$); observation is scalar 50 with hard interval $[49, 51]$. | Intersects both $L$ and $H$. Hypotheses with differing predictions across $L$ and $H$ become `unresolved`; no forced rounding. | Tighter interval $[49, 50]$ strictly intersecting $L$, or point 50. | Decoder partition verification. |
| **ADV-RE-03** (Unjustified Complement Exclusion) | $H_2$ positively supports $L$; outcome $H$ has no premise. Observation decodes to $H$. | $H_2$ status is `unresolved` with reason `exclusion_unsupported`. Zero elimination of $H_2$. | Supply explicit warranted exclusion premise for $H_2$ on $H$, rendering $H_2$ `conditionally_incompatible`. | Support qualification (`support_qualification.py`). |
| **ADV-RE-04** (Counterfactual Bypass Control) | Bypassing support qualification, assert $H_2$ excludes $H$ because it permits $L$. Observation decodes to $H$. | Counterfactual test proves that bypass falsely eliminates $H_2$, demonstrating safeguard necessity. | N/A (Counterfactual control harness). | CP-EXP-001 challenger audit. |
| **ADV-RE-05** (Model/Prediction Mismatch) | Admitted observation is $T_1 = 80$ °C ($X=(70, \infty)$). Both $H_1$ and $H_2$ explicitly exclude $X$. | Output status is `model_prediction_mismatch`. Zero surviving hypotheses; zero hallucinated candidates. | Observation $T_1 = 60$ °C, where $H_1$ permits $H$. | Section 4 mismatch rule. |
| **ADV-RE-06** (Retrospective Revision Laundering) | After seeing 80 °C, author rewrites $H_1$ to permit $X$, setting `result_exposure: before` without prior bundle. | System marks status `declared_pre_exposure_unverified`; forbids `provably_pre_exposure` label. | Disclose `result_exposure: after_exposure` as an explicit retrospective analysis. | Finding H2. |
| **ADV-RE-07** (Precondition / Hold Violation) | Baseline is at $t_0$; observation is at $t_1$; hold condition between $t_0$ and $t_1$ is declared `unknown`. | Reassessment withheld with `withheld_due_to_unverified_hold_conditions`. | Valid hold assertion with matching basis artifacts. | Section 3 context attestation. |
| **ADV-RE-08** (Semantic Subject Mismatch) | Rehash procedure edition and hashes, but point subject anchor to an unnominated heater block. | Technical refusal `SUPPORT_SUBJECT_MISMATCH` before decoding. | Valid matching subject anchor ID. | `_joins` validation in `measurement_wire.py`. |

---

## 5. Individual adjudication of proposed owner decisions

| Proposal Decision (Section 7) | Adversarial Review Disposition | Rationale and Boundary |
| :--- | :--- | :--- |
| **Decision 1: Approve first scope (one scalar result / one nominated P; no code adapter, automatic adoption, general comparison or chaining).** (lines 206–207) | **APPROVE** | Strictly bounds the capability to what existing public scalar admission and interval decoders can support. Avoids premature generalization into code telemetry or unconstrained rule engines. |
| **Decision 2: Approve conservative interval unanimity and branch-local qualification, with explicit unresolved outcomes.** (lines 208–209) | **APPROVE (Subject to Finding H1)** | Branch-local qualification is sound because unobserved branches do not affect observed compatibility. Requiring unanimous exclusion across all intersecting branches prevents spurious elimination. Finding H1 ensures containment. |
| **Decision 3: Approve separate local reassessment permission, declared exposure chronology and retrospective labelling; no authentication or predictive-validation claim.** (lines 210–211) | **APPROVE (Subject to Finding H2)** | Prevents overclaiming. Finding H2 ensures that unauthenticated local timestamps cannot be misrepresented as provably prospective validation. |
| **Decision 4: Decide whether later adopted-set handoff should remain documentation-only as recommended.** (lines 212–213) | **APPROVE (Documentation-only)** | Strongly endorse the recommendation that handoff remain documentation-only. The application must not autonomously mutate hypothesis sets or chain into automatic reranking. |

---

## 6. Recommended next gate and boundary exclusions

### Recommended Next Gate

Proceed to **Proof Design & Application Contract Specification** (documentation only):
1. Draft the formal proof specification for measurement reassessment.
2. Incorporate **Finding H1**: enforce $lo \le x \le hi$ containment check.
3. Incorporate **Finding H2**: partition exposure status into `provably_pre_exposure`, `declared_pre_exposure_unverified`, and `disclosed_retrospective`.
4. Incorporate **Finding M1**: enforce strict two-stage separation between baseline ineligibility and measurement contradiction.
5. Define static resource ceilings for the reassessment request and result bundle.
6. Submit the specification for owner approval prior to implementation authorization.

### Explicit Boundary Exclusions

This review authorizes **no implementation, code changes, or proof execution**:
- No files in `applications/` or `backend/` are modified.
- No tests or commands were executed.
- No ADR is allocated (ADR-0023 remains unreserved).
- C, IN-001, and CI-001 remain open and unselected.
- All 959 tracked files and pre-existing untracked files are preserved byte-for-byte.

END OF MEASUREMENT-RESULT REASSESSMENT INDEPENDENT ADVERSARIAL REVIEW

