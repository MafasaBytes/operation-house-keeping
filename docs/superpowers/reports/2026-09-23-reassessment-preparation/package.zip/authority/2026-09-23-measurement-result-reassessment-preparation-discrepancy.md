# Reassessment preparation: consolidated carriage discrepancy

Status: **preparation blocked before fixture/package generation**. This is a
readiness discrepancy, not a prepared package or a revised semantic contract.
The owner approved the corrected semantics and application/replay contract, with
bounded preparation only and explicit direction to consolidate infeasible
obligations rather than fill gaps. No application or proof was executed.

## 1. Verified authority and preservation boundary

Local HEAD: `15bd9dcb1559898944149cab0ec78b962019ab50`.
Read the complete [corrected candidate](2026-09-23-measurement-result-reassessment-corrected-candidate.md)
and [focused review](2026-09-23-measurement-result-reassessment-focused-review.md).
Their exact SHA-256 commitments match:

- Candidate: `04db2d0ecd2e825f61285e37106c08b735dcf6ae3f86b467626cd0e47eed94e3`.
- Focused review: `e3cb305e420ef1c441b868950eb03c0aae7470920f245932a145f7283851ba1d`.

All prior proposal/review bytes remain untouched. The earlier review commitment
`9909d9e7a439f97ae255ffe39402e9232bda4144acf21cef71eeaaf9de54b826` remains unresolved
historical evidence, not a proven typo or equivalent version. The owner-adopted
local review remains frozen at
`5fb61f732f72e93b6c4ab9dd5459a6829468ce0ac209acfd9b2f00f63556ce06`, including its
final blank line. No renewed provenance investigation was performed.

Actual starting inventory: 1,448 untracked paths and 2,702 tracked/untracked
regular files. Canonical sorted path→SHA-256 inventory commitment:
`61edb24aa02db65a93332e62aeb61751552c49eb8cf5838c2d80e575c7d51d63`.
Only this new report is added. No existing artifact, runtime result, application,
backend contract, dependency or ledger is changed; no commits or remote operations.

## 2. D1 — prior-bundle carriage conflicts with preserved limits

The approved candidate §3 requires `nr.retained-bundle.v1` to contain common
header C plus `{manifest,files}`, where files are all seven original files,
each represented by `{name,encoding,bytes}` with base64 content. Its §7 also
requires the complete original invocation's typed closure, and captures every
new object in the outer base64 closure. Supplied prior bundles cannot be silently
dropped or downgraded to absence. Proof P8 requires a verified-prior-bundle valid
twin. §8 retains all existing byte/string ceilings, including 256 KiB per object,
512 KiB closure and 4,096-byte ordinary strings.

Measured source: committed
`2026-09-23-next-measurement-release-evidence/committed-only-delivery.zip`,
149,319 archive bytes, SHA-256
`d1608a25394c9ce7229d8d4517bf7ccc35fb43277e75fd2b420536948bdc8867`.
Its Git blob equals the current committed blob and its release-manifest commitment.
All 43 regular members were recovered in memory and verified against their
retained inventory. The measured `result/` bundle is actual accepted selector
delivery evidence at tested implementation
`23b60a42c2279fc228168967d47491b8983658fb`, not the old synthetic 835-byte fixture.
Its manifest SHA-256 is
`8d88a43b5536326fb6020947ba8afe56fd59abace501be06fdd9b75ce6d86239`.
All six listed payload byte lengths and hashes were independently checked against
that manifest. The source's historical passing receipt was read, not rerun.

| Original file | Exact bytes | Base64 content bytes in proposed prior object |
| --- | ---: | ---: |
| build.json | 26,165 | 34,888 |
| closure.json | 175,931 | 234,576 |
| invocation.json | 504 | 672 |
| manifest.json | 972 | 1,296 |
| policy.json | 876 | 1,168 |
| result.json | 10,694 | 14,260 |
| trace.json | 17,707 | 23,612 |
| **Total** | **232,849** | **310,472** |

Constructing the specified prior object **in memory only**, with id `prior`,
revision 1, null predecessor, exact parsed original manifest and lexically sorted
seven files, gives canonical size **311,968 bytes** and SHA-256
`553b78f5d7a4123255e6543e434a7bf642ee8401362f609283a93fb0013559df`.
This is a static encoding measurement, not an admitted fixture or runtime result.
No file containing that object was written.

Three related consequences of the single carriage design:

1. **Ordinary string boundary:** four file values exceed 4,096 encoded bytes.
   The largest is 234,576. Maintained `measurement_wire.decode` grants transport
   handling to the outer closure; it does not automatically exempt a typed
   `nr.retained-bundle.v1` object's internal strings. The candidate provides no
   explicit nested-transport exception. Treating arbitrary embedded strings as
   transport would be a policy interpretation needing approval, not mechanical
   fixture generation.
2. **Object boundary:** 311,968 exceeds 262,144 by **49,824 bytes**. A string
   exception alone cannot make the object fit. Shortening the example's five-byte
   logical ID cannot remove the measured structural excess.
3. **Complete closure boundary:** base64 encoding that prior object takes
   **415,960 bytes**. The original 19 required objects already contribute
   **172,836 base64 content bytes** to closure. Their sum is **588,796**, exceeding
   the 524,288-byte closure ceiling by **64,508**, before outer metadata, E1,
   execution/exposure/authority objects or the new build. This is a strict lower
   bound, not a complete reassessment-bundle measurement. Embedded duplicates and
   separately required typed members have different carriage roles; the frozen
   grammar does not authorize replacing either representation with a digest.

This demonstrates that the specified encoding cannot carry this accepted bundle
under the preserved policies. It does **not** prove every conceivable smaller
prior bundle impossible or measure a general reassessment capacity. An unsupported
large request may rightly refuse; however, silently reducing P8 to a refusal,
dropping its optional-but-supplied bundle, or replacing real build/evidence with
undersized synthetic content would not establish the promised supported valid
twin. A declared restriction to smaller prior bundles would need an explicit
supported envelope and a genuine recoverable valid example, not an assumed fit.

## 3. Measurement method, oracle and accounting

Only standard-library byte/JSON/base64/archive operations were used. No application
imports, public facade execution, tests, future selector/reassessment runtime,
dependency acquisition or physical measurements were used.

Reproduce the static check from the committed archive:

1. Read `result/{build,closure,invocation,manifest,policy,result,trace}.json` in
   memory; verify every manifest payload length and digest.
2. Construct exactly C with schema `nr.retained-bundle.v1`, profile
   `measurement-reassessment/v1`, id `prior`, revision 1, predecessor null;
   add the parsed manifest and file rows sorted by filename with encoding `base64`.
3. Serialize UTF-8 with sorted keys, compact separators, no LF and
   `ensure_ascii=False`. Count bytes and SHA-256; count base64 bytes of this object.
4. Sum the lengths of the original closure's `members[*].bytes`, then add the
   new object's base64 length. This intentionally excludes all framing/new
   reassessment dependencies, proving only the lower bound above.

The base64 count also follows the independent arithmetic identity
`4 * ceil(raw_bytes / 3)` for each file. Both calculations are by the same author;
they are not independently staffed review evidence or an empirical oracle.
The observed corpus maximum here is one accepted bundle and its hypothetical
encoding, not maxima for the not-yet-generated reassessment corpus. Runtime work,
refusal timing, CPU/wall/RSS, new trace/output sizes and complete retained fit are
**unmeasured**. No expected reassessment conclusions were derived from a runtime.

Exact preparation accounting at this stop:

- 12 named approved proof groups inventoried: P1, P2, P3, P3b, P4, P5, P6, P7,
  P8, P9, P10, P10b. These groups contain multiple future twins; they are not
  12 fixed commands or a completed case matrix.
- 1 historical archive inspected; 43 regular members integrity-checked; 7 original
  bundle files statically sized; 1 proposed encoding sized in memory.
- 0 reassessment fixtures, expected-output files, command-matrix entries or
  candidate packages generated; 0 application/proof commands executed.
- 0 new harness-only controls. Manual C remains unresolved and has no executable
  case. Manual adoption remains outside the application. No carried-forward
  142-command total is claimed for this different capability.

## 4. Consolidated owner decision and preparation continuation

**Recommended smallest decision:** authorize a narrow documentation amendment for
prior-bundle carriage that preserves complete exact recovery while avoiding
nested duplication, with unchanged numerical ceilings. A promising option is
content-addressed, shared carriage plus an explicit byte-exact reconstruction
contract for the seven original files. Such a design must specify which exact
bytes are stored, any deterministic reconstruction recipe, authority/type joins,
digest comparison, traversal, accounting and refusal precedence. Hashes alone
are insufficient. This option is a recommendation for specification work, not a
newly adopted format or a claim that it fits; preparation must measure it before
any package approval.

Alternatives needing explicit disposition: retain the frozen format and approve
a demonstrated smaller supported prior-bundle envelope with real valid twins;
or propose a reassessment-only resource-policy amendment. No increased ceiling,
nested-string exemption, compressed format, sidecar discovery, missing ancestry
or runtime callback is authorized or applied by this report. Existing nm,
thermal/governed and backend policies remain unchanged under every option.

After that decision, complete one coherent recoverable package: precise amended
carriage/schema commitments, independently reviewable implementation slices,
full valid/adverse fixtures and same-author hand oracle with separate arithmetic
check, exact command accounting, complete byte/work measurements and recovery
manifest. Include actual-build binding and independent input reconstruction,
observation admission, support qualification and reassessment in the delivery
contract; never consume expected-result bytes as computation. No package should
claim readiness until P8's valid route, full history/closure and all other approved
groups have consistent and measured carriage.

Semantic conclusions remain owner-approved: exact containment; model-relative
compatibility/conditional incompatibility/unresolved; complete domain intersections;
fixed captured-baseline eligibility; unverified local chronology; exact authority;
manual adoption. D1 does not reopen those choices or the historical review-digest
discrepancy. No physical acquisition, empirical validity, pre-exposure custody,
automatic pruning/reranking or backend extension follows. IN-001 and CI-001 remain
open and unselected. Implementation and proof execution remain separately gated.

END OF REASSESSMENT PREPARATION DISCREPANCY — NO PACKAGE READY.
