# Measurement-result reassessment — focused independent re-review

Documentation review only, 2026-09-23. No proof, tests, application execution,
implementation or remote operation was performed.

## Reviewed authority and provenance

I am the separately staffed `reassessment_focused_reviewer` agent. I did not author
the candidate. I read the complete lead proposal, newly frozen local review and
corrected candidate, then inspected the maintained decoder, typed references,
public-evidence reconstruction and support-qualification composition. I reported
two consequential contract ambiguities to the lead, who corrected the candidate;
I independently checked the resulting clauses. This is independent reviewer
staffing in the same model/tool environment, not external human review, physical
custody evidence or independent empirical validation.

Verified local HEAD: `15bd9dcb1559898944149cab0ec78b962019ab50`.

| Input | Verified SHA-256 |
| --- | --- |
| [Lead proposal](2026-09-23-measurement-result-reassessment-lead-proposal.md) | `6a11958e692d620be6cacd9a84ef2332eb6bf23fb42edc2a4276ba3045864f28` |
| [Newly frozen local review](2026-09-23-measurement-result-reassessment-independent-adversarial-review.md) | `5fb61f732f72e93b6c4ab9dd5459a6829468ce0ac209acfd9b2f00f63556ce06` |
| [Corrected candidate](2026-09-23-measurement-result-reassessment-corrected-candidate.md) | `04db2d0ecd2e825f61285e37106c08b735dcf6ae3f86b467626cd0e47eed94e3` |

Local review independently checked as 20,682 bytes, 211 lines, marker on line 210
and final blank line. Earlier commitment
`9909d9e7a439f97ae255ffe39402e9232bda4144acf21cef71eeaaf9de54b826`
remains unresolved historical evidence. The owner-adopted reconciliation records
only the local version recovered and an earlier task-output capture matching it.
This focused review does not repeat that archive investigation, recover the missing
version, infer a typo or establish byte equivalence to that earlier commitment.
Frozen inputs were not edited.

## Verdict and dispositions

**Suitable for owner design consideration; no remaining blocking defect found.**
This does not freeze the contract or approve implementation. Remaining findings:
**0 critical, 0 high, 0 medium, 0 low defects**.
Historical H1/H2/M1/L1 are individually resolved at specification level. Two medium
ambiguities discovered during this review were corrected before the reviewed final
candidate. No passing runtime or capacity evidence follows.

| Finding | Disposition and substantive reason |
| --- | --- |
| H1 | Resolved. §§3–4 use one publicly admitted exact scalar, consistent units and exact rational containment lo ≤ x ≤ hi. Reversed/inconsistent envelopes refuse `OBSERVATION_UNCERTAINTY_INCONSISTENT`, exit 3, before observation decoding/qualification; unavailable x is not presumed contained. P2 supplies both directions and valid/earlier-unit twins. |
| H2 | Resolved by rejecting the original review's proposed custody tier, not by implementing it. §5 independently reports verified content/reference relationships and declared chronology. A retained bundle never establishes when an operator first learned a result. Internally consistent false chronology can pass and is explicitly disclosed as undetectable. No `provably_pre_exposure` output is permitted. |
| M1 | Resolved. §6 gates measurement conclusions on exact frozen E0 eligibility. Baseline-ineligible H retain their prior reasons and null outcome cells; the result neither eliminates nor resurrects them. A separately authorized revised baseline creates another assessment. The frozen local review did not assert permanent ineligibility across all future versions. |
| L1 | Resolved. Point assumptions canonicalize to [x,x] while preserving their declared basis and explicit lack of a zero-physical-error guarantee; hard [x,x] may agree computationally without becoming the same evidentiary claim. |
| FR-M1, discovered here | Resolved. The initial candidate left `original_selection_pin` without an explicit target/equality rule. Final §4 phase 3 requires equality to original I.selection.sha256, resolved as `nm.selection.v1` for I.request; mismatch refuses before assessment. This is selection authority, not an unrecoverable digest of a computed result. The new authority pin remains independent. |
| FR-M2, discovered here | Resolved. Rational interval intersection alone could count a singleton 1/3 despite the declared finite-decimal scalar domain. Final §4 explicitly restricts intersections to that domain; a singleton counts only when included by both sets and its reduced denominator has only factors 2 and 5. P3b contrasts 1/3 and 1/2. Original branch identities remain retained; no nm decoder or ranking semantics are rewritten. |

Two further proof-wording observations were also closed in the final candidate:

- **FR-L1, resolved:** P10b now explicitly instantiates a correctly shaped,
  substituted `original_selection_pin` and matching equality twin, distinct from
  the earlier external-authority-pin guard. This closes the proof-coverage omission;
  these remain future obligations, not executed tests.
- **FR-L2, resolved:** Phase 4 explicitly distinguishes zero observation-envelope
  intersection/support qualification from earlier decoder grammar/integrity
  validation. Future counters must follow that distinction. P2's short “decoding”
  wording is read under this explicit precedence, not as zero earlier validation.

## Mathematical and epistemic checks

For each eligible H, B is every nonempty decoder/envelope intersection in the
supported scalar domain. All B cells must permit to report compatibility; all
must carry justified exclusions to report conditional incompatibility. Mixed,
missing, unavailable or opposing contributions yield unresolved. No complement
exclusion follows from a positive permit. Qualification includes all nominated
sources for the selected H/P, not a favorable subset, and checks all-outcome row
validity before interpreting B. Missing unrelated cells do not become evidence
against H; original whole-set ranking remains untouched.

Independent set reasoning confirms point 50 and [49,50] occupy L, while [50,51]
occupies L and H. At 70, [70,71] occupies H and X. Finite decimals are dense, so a
nonempty interval interior contains supported values; the stated reduced-denominator
criterion decides endpoint-only membership exactly. Containment guarantees at
least the admitted x, preventing vacuous all-permit/all-exclude results. Gaps and
overlap are technical refusals under the existing complete-partition contract,
including gaps away from the current envelope; they cannot be dropped locally.

All eligible H excluding B gives a model/prediction mismatch, never nearest-fit
selection. Zero compatible with any unresolved H is incomplete assessment. Zero
baseline-eligible H is its own disposition, not a vacuous mismatch. Every original
H remains visible. Conclusions remain conditional on supplied synthetic premises
and execution/hold attestations, not observed physical truth or causal falsification.

I disagree with the frozen review's suggestion that local manifest chronology can
establish `provably_pre_exposure`, its unqualified “observed reality” description,
and its cross-platform identical-replay assurance. The candidate correctly rejects
or narrows all three. Historical/retrospective results are allowed; no universal
acquisition-after-baseline assumption is imposed. Reviewer agreement supplies no
missing custody guarantee.

## Consequential contract and lifecycle checks

The new profile separates E1 observation bytes, decoded interpretation, exact
original E0/H/P/O/S, local authority and derived conclusions. Correctly rehashed
substitution still encounters semantic joins. Separate permission blocks downstream
assessment; unavailable E0/E1, unknown execution conditions and unknown/confidence-only
uncertainty retain distinct reasons. Prior-bundle integrity is optional evidence;
if supplied, its bytes, full closure and exact I binding are mandatory.

Required references and predecessors are retained through revision 1. Sharing is
not a cycle; digest-before-cycle public cases and synthetic traversal coverage
remain distinct. Historical requests validate integrity/joins/reconstruction and
containment without retrospectively determining current eligibility. Original nm
builds are retained dependencies; the nr executable must explicitly support those
input contracts and bind its own real build/environment/policy. Reassessment does
not impersonate historical selector replay.

Replay independently reconstructs, admits, qualifies and derives semantic outputs
from captured bytes, while fresh physical counters remain outside semantic equality.
Safe capture and no-overwrite publication are proposed obligations, not verified
new functionality. Combined closure, embedded bundle and two-snapshot capacity
are unmeasured. Existing ceilings are preserved; insufficient fit must refuse,
not truncate or silently increase capacity. No backend prerequisite was demonstrated.

Manual adoption remains outside this profile. There is no automatic pruning,
reranking, observation mutation or implicit transfer of assessment permission to
physical acquisition. A future selector request requires explicit nominations,
authority and traceable adopted interpretation; its complete-matrix policy remains.

## Owner choices and next gate

Owner decisions remain: approve one scalar result/one P and hard-envelope semantics;
approve branch-local unanimity and exact baseline precedence; approve truthful local
exposure declarations and separate permission; approve derived reporting/manual-only
adoption; approve the proposed profile, commands, closure and historical-input/new-build
contract. Resource feasibility and any exact build-owned policy package require later
bounded preparation and explicit approval. No numerical capacity or runtime success
is established here.

Recommend owner review of this candidate and its explicit proof obligations before
contract approval or separately scoped fixture/resource preparation. Implementation
and proof execution remain unauthorized. C remains unresolved; IN-001 and CI-001
remain open and unselected. No probabilities, cost ranking, acquisition, empirical
validity, global optimality or new platform/durability promise follows.

END OF FOCUSED REASSESSMENT REVIEW — DOCUMENTATION ONLY.
