"""Static public-fixture construction, not reassessment/application execution.

Reuses existing pure public contracts to keep absent evidence on the exact E0
model revision. No store, query service, application command or ledger writes.
"""
import base64
import copy
import json
from pathlib import Path
from backend.state_classification import StateClassificationResult
from backend.constraint_evaluation.contracts import ConstraintEvaluationResult, derive_candidate_evaluation
from backend.semantic_compatibility import VariableSemanticCompatibilityResult
from backend.state_classification.derivation import derive_classification

p=Path(__file__).resolve().parent
w=json.loads((p/'authority/witness.json').read_bytes())
e=next(json.loads(base64.b64decode(m['bytes'])) for m in w['members'] if m['reference']['kind']=='nm.evidence.v1')
o=e['snapshot'];u=json.loads((p/'authority/snapshot-unavailable.json').read_bytes())
revision=o['state']['material']['revision']
def transplant(v,old):
    if isinstance(v,dict):
        if 'revision_id' in v and 'record_ids' in v and 'model_id' in v:return copy.deepcopy(revision)
        if isinstance(old,dict):
            if 'material' in v and 'material' in old:return copy.deepcopy(old)
            return {k:transplant(x,old.get(k)) for k,x in v.items()}
        return {k:transplant(x,None) for k,x in v.items()}
    if isinstance(v,list):return [transplant(x,old[i] if isinstance(old,list) and i<len(old) else None) for i,x in enumerate(v)]
    return v
original=StateClassificationResult.model_validate(o);cs=[]
for i,row in enumerate(u['constraint_evaluations']):
    es=VariableSemanticCompatibilityResult.model_validate(transplant(row['semantic_compatibility'],o['constraint_evaluations'][i]['semantic_compatibility']))
    con=original.constraint_evaluations[i].constraint
    cs.append(ConstraintEvaluationResult(constraint=con,as_of=original.as_of,semantic_compatibility=es,candidates=tuple(derive_candidate_evaluation(con,es,j) for j in range(len(es.candidates))),ruleset_version='cn001.1'))
args=dict(state=original.state,state_anchor_id=original.state_anchor_id,context=original.context,as_of=original.as_of,condition_sources=original.condition_sources,constraint_evaluations=tuple(cs))
v=StateClassificationResult(**args,**derive_classification(**args))
b=json.dumps(v.model_dump(mode='json'),sort_keys=True,separators=(',',':')).encode()
out=p/'authority/snapshot-unavailable-same-model.json'
if out.exists():assert out.read_bytes()==b
else:out.write_bytes(b)
print(json.dumps(dict(bytes=len(b),status='static_public_contract_reconstruction_only',application_executions=0)))
