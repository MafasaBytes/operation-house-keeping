"""Finish static preparation records. No application execution or future runtime.

This records planned command obligations and observed byte/graph counts. Command
rows are data, never dispatched. This script only writes inside this new package.
"""
import base64
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import zipfile

P=Path(__file__).resolve().parent
def C(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def H(b):return hashlib.sha256(b).hexdigest()
def put(n,v):(P/n).write_bytes(C(v))
def refkey(r):return r['kind'],r['sha256']
def refs(v):
    if isinstance(v,dict):
        if set(v)=={'kind','sha256'}:yield v
        else:
            for x in v.values():yield from refs(x)
    elif isinstance(v,list):
        for x in v:yield from refs(x)
def dimensions(v):
    stack=[(v,1)];nodes=depth=0
    while stack:
        x,d=stack.pop();nodes+=1;depth=max(depth,d)
        if isinstance(x,dict):stack.extend((y,d+1) for y in x.values())
        if isinstance(x,list):stack.extend((y,d+1) for y in x)
    return nodes,depth

cases=json.loads((P/'cases.json').read_bytes());measure=json.loads((P/'input-measurements.json').read_bytes())
spec=importlib.util.spec_from_file_location('frozen_reconstruction',P/'authority/reconstruct.py')
checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
expected_files=json.loads((P/'authority/expected-files.json').read_bytes())
work=[];recoveries=[];active=set()
for case in cases:
    d=P/'cases'/case['id'];meta=json.loads((d/'input.json').read_bytes())
    pool={refkey(r):(P/'objects'/(r['sha256']+'.'+r['kind'])).read_bytes() for r in meta['members']};active.update(pool)
    parsed={k:json.loads(b) for k,b in pool.items() if k[0]!='nm.basis'}
    edges={}
    for k,v in parsed.items():
        es=list(refs(v))
        if k[0]=='nm.invocation.v1':es += [dict(kind='nm.build.v1',sha256=v['build_identity']),dict(kind='nm.resource-policy.v1',sha256=v['resource_policy'])]
        edges[k]=[refkey(r) for r in es]
    contexts=[k for k in parsed if k[0] in ('nm.request.v1','nr.request.v2')]
    scoped_expansions=visits=scanned=public_nodes=0
    for root in contexts:
        done=set();pending=[root]
        while pending:
            k=pending.pop()
            if k in done:continue
            done.add(k);scoped_expansions+=1;scanned+=len(pool[k])
            # Contextual validity of ancestor requests is a separate context;
            # their content remains in global closure, never truncated.
            v=parsed.get(k,{})
            for target in edges.get(k,[]):
                visits+=1
                if v.get('predecessor') and target==refkey(v['predecessor']):continue
                if target[0] in ('nm.request.v1','nr.request.v2') and target!=root:continue
                pending.append(target)
        public_nodes+=sum(dimensions(parsed[k]['snapshot'])[0] for k in done if k[0]=='nm.evidence.v1')
    role_ref_uses=role_nodes=role_bytes=reconstructed=recipe_encoded_raw=manifest_hash_bytes=0
    descriptors=[(k,v) for k,v in parsed.items() if k[0]=='nr.retained-bundle.v2']
    for dk,desc in descriptors:
        required={dk,refkey(desc['closure']['invocation'])}
        required.update(refkey(r) for r in desc['closure']['members'])
        for f in desc['files']:
            if 'reference' in f['source']:required.add(refkey(f['source']['reference']))
        witness=dict(schema='nr.carriage-witness.v2',descriptor=dict(kind=dk[0],sha256=dk[1]),members=[dict(reference=dict(kind=k[0],sha256=k[1]),encoding='base64',bytes=base64.b64encode(pool[k]).decode()) for k in sorted(required)])
        # The approved checker requires the exact original transport schema.
        witness['schema']=json.loads((P/'authority/witness.json').read_bytes())['schema']
        files,report=checker.recover(C(witness))
        for row in expected_files:assert len(files[row['name']])==row['bytes'] and H(files[row['name']])==row['sha256']
        recoveries.append(dict(case=case['id'],descriptor_sha256=dk[1],members=len(required),files=expected_files,original_directory_used=False))
        reconstructed+=sum(map(len,files.values()))
        recipe_encoded_raw+=sum(len(pool[refkey(r)]) for r in desc['closure']['members'])
        manifest_hash_bytes+=sum(len(b) for n,b in files.items() if n!='manifest.json')
        for f in desc['files']:
            if 'reference' not in f['source']:continue
            k=refkey(f['source']['reference'])
            if k[0]!='nm.basis':continue
            v=json.loads(pool[k]);role_bytes+=len(pool[k]);role_nodes+=dimensions(v)[0]
            rr=list(refs(v));role_ref_uses+=len(rr)
            for r in rr:assert refkey(r) in pool,(case['id'],'retained output reference missing',r)
    raw=sum(map(len,pool.values()));ordinary_edges=sum(map(len,edges.values()))
    # Separate counters: no assertion that this chosen finite scan schedule is
    # the future runtime's physical implementation or an upper CPU/RSS bound.
    work.append(dict(case=case['id'],unique_capture_bytes=raw,closure_transport_member_checks=len(pool),
        typed_reference_occurrences=ordinary_edges,retained_role_reference_uses=role_ref_uses,
        total_reference_uses_including_transport=ordinary_edges+role_ref_uses+len(pool),
        total_edge_visit_schedule=ordinary_edges+visits+role_ref_uses+len(pool),
        scoped_expansions=scoped_expansions,scoped_edge_visits=visits,scoped_scanned_bytes=scanned,
        public_reconstruction_nodes_by_scope=public_nodes,retained_role_json_nodes=role_nodes,
        retained_role_scan_bytes=role_bytes,reconstructed_prior_bytes=reconstructed,
        reconstructed_prior_manifest_hash_bytes=manifest_hash_bytes,
        base64_encode_raw_bytes_for_new_closure=raw,base64_encode_raw_bytes_for_prior_recipe=recipe_encoded_raw,
        replay_base64_decode_raw_bytes=raw+recipe_encoded_raw,
        hash_input_bytes_once=raw,physical_reads=None,physical_writes=None,wall_ns=None,peak_rss_bytes=None))
put('work-measurements.json',dict(schedule='unique intrinsic parsing; each declared request context scanned separately; retained-role references separately checked; physical runtime unmeasured',cases=work))
put('prior-recovery-checks.json',dict(application_executions=0,recoveries=recoveries))

commands=[];diagnostics=[]
def cmd(ident,case,operation,expect,setup=None):
    args=['python','-m','applications.bounded_decision_workflow','reassessment-'+operation]
    if operation=='evaluate':args+=['--invocation','{CASE}/invocation.json','--objects-dir','{CASE}/objects','--authority-pin','{PIN}','--output-dir','{NEW}']
    elif operation=='verify':args+=['--bundle','{BUNDLE}']
    else:args+=['--bundle','{BUNDLE}','--output-dir','{NEW}']
    commands.append(dict(id=ident,case=case,argv=args,setup=setup or 'Materialize only this case input.members; bind actual executable mechanically before semantic use.',expected=expect,status='planned_not_executed'))
for case in cases:
    exp=case['expected'];cmd('E-'+case['id'],case['id'],'evaluate',dict(exit=exp['exit'],stdout='receipt_plus_LF' if exp['exit']==0 else 'empty',stderr='empty' if exp['exit']==0 else 'diagnostic_plus_LF',oracle='cases/'+case['id']+'/expected.json',bundle='complete' if exp['exit']==0 else 'absent'))
    if exp['diagnostic']:diagnostics.append(dict(case=case['id'],**exp['diagnostic'],exit=exp['exit'],exact_template='cases/'+case['id']+'/stderr.expected'))
replays=['P1-point60','P1-point40','P2-valid','P3-cross','P3b-third','P3b-half','P5-mismatch','P5-missing','P5-conflict','P6-multiple','P7-wouldpermit','P7-newbaseline','P8-before','P8-after','P8-unknown','P9-retrospective','P10-denied','P10-no-observation','P10-no-baseline','P10-shared_four']
for case in replays:
    for op in ['verify','replay']:cmd(op[0].upper()+'-'+case,case,op,dict(exit=0,stdout='receipt_plus_LF',stderr='empty',semantic_result_trace='unchanged' if op=='replay' else 'not_recomputed'), 'Copy only seven retained files to isolated approved ext4 root; original inputs and preparation pool unavailable; use same actual build. Each replay NEW is unique.')

controls=[]
def control(ident,mutation,code,exit=3,stage='capture_or_closure',operation='evaluate',base='P8-before',layer='public',twin='E-P8-before'):
    row=dict(id=ident,base=base,mutation=mutation,expected_code=code,exit=exit,stage=stage,layer=layer,nearest_valid_twin=twin)
    controls.append(row)
    if layer=='public':cmd('D-'+ident,base,operation,dict(exit=exit,code=code,stdout='receipt_plus_LF' if exit==0 else 'empty',stderr='empty' if exit==0 else 'diagnostic_plus_LF',bundle='complete' if exit==0 else 'no_success'),mutation)

for name,code in [('unknown_recipe','PRIOR_RECIPE_INVALID'),('recipe_extra','PRIOR_RECIPE_INVALID'),('missing_member','REQUIRED_REFERENCE_MISSING'),('substituted_bytes','REFERENCE_DIGEST_MISMATCH'),('missing_recipe_member','PRIOR_CLOSURE_MEMBER_MISMATCH'),('duplicate_recipe_member','PRIOR_RECIPE_INVALID'),('incompatible_role','PRIOR_FILE_ROLE_MISMATCH'),('manifest_mismatch','PRIOR_MANIFEST_COMMITMENT_MISMATCH'),('missing_file','PRIOR_BUNDLE_INCOMPLETE')]:
    control(name,'Embed exact carriage-controls/'+name+'.json descriptor/member variant into P8-before; rehash exposure/Q/authority/I; preserve nominated prior I and original manifest expectations; no repair from global pool.',code)
control('missing-ancestor','Remove nr.request.v2 predecessor bytes from P10-shared_four only; keep every referencing digest unchanged.','REQUIRED_REFERENCE_MISSING',base='P10-shared_four',twin='E-P10-shared_four')
control('digest-before-cycle','Replace predecessor target bytes with a reference back to active Q without recomputing the promised digest.','REFERENCE_DIGEST_MISMATCH',base='P10-shared_four',twin='E-P10-shared_four')
control('identity-collision','Use two original nm requests carried by one declaration, as in context8. In one context change H1 requirements and rehash its owning P/S/Q references, retaining its logical ID and revision; the other context retains original H1. Both context graphs are byte-consistent but global same-kind/ID/revision collision refuses before interpretation.', 'IDENTITY_COLLISION',base='P10-context8',twin='E-P10-context8')
control('extra-closure','Add unrelated correctly hashed member to retained closure and update manifest; leave declared roots unchanged.','EXTRANEOUS_CLOSURE_MEMBER',operation='verify')
control('wrong-build','Correctly shaped nr.build.v2 from different executable; rehash I and dependent references; do not change executing build.','BUILD_IDENTITY_MISMATCH',stage='phase_1')
control('prepared-build','Use exact prepared bytes unchanged; no binding substitution.','NONEXECUTABLE_BUILD_WITNESS',stage='phase_1')
control('wrong-policy','Correctly hash policy with changed ceiling and rebind I; executing approved policy unchanged.','RESOURCE_POLICY_IDENTITY_MISMATCH',stage='phase_1')
control('wrong-profile','Replace new observation semantic profile with thermal profile; correctly rehash dependent references.','PROFILE_MISMATCH',stage='phase_1')
control('v1-wrapper','Supply authority/v1-wrapper-reconstructed.json as one required object: 311,968 bytes, exactly reconstructed against the discrepancy report commitment (originally measured only in memory). The unchanged 262,144-byte object guard refuses before semantic version inspection. This is an oversized historical control, not version-rejection evidence.','RESOURCE_LIMIT_EXCEEDED',exit=4,stage='capture')
control('v1-header','Replace only the small top-level invocation schema/profile with nr.invocation.v1 / measurement-reassessment/v1 and rehash the supplied invocation. This is a version-dispatch control, not an accepted historical bundle.','PROFILE_VERSION_UNSUPPORTED',stage='phase_1')
control('forged-verify','Exchange H1/H2 permitted/excluded cell claims and resulting compatible/incompatible statuses in retained P1-point60 result; update corresponding summary and claimed result/trace reasons coherently. Preserve every input, authority, support and build reference. Canonicalize, rehash changed result/trace and their manifest entries. Byte-integrity and joins pass; only independent qualification exposes the lie.','INTEGRITY_ONLY_COMPLETE',exit=0,operation='verify',base='P1-point60',stage='verification',twin='V-P1-point60')
control('forged-replay','Use the same self-consistently rehashed forged bundle as forged-verify; independently recompute from closure.','REPLAY_SEMANTIC_MISMATCH',operation='replay',base='P1-point60',stage='semantic_comparison',twin='R-P1-point60')
for ident,mutation in [('escape','Set objects directory path through ../ outside approved runtime root.'),('symlink','Replace a required member by symlink to identical bytes.'),('fifo','Replace required member with FIFO; must not wait for a writer.'),('directory','Replace required member with a directory.'),('member-race','Test harness swaps named inode after safe open; opened bytes cannot authorize subsequent replacement.'),('root-race','Test harness renames/replaces input or output root during held-descriptor operation.')]:
    codes={'escape':'PATH_COMPONENT_UNSAFE','symlink':'PATH_FINAL_SYMLINK','fifo':'PATH_SPECIAL_FILE','directory':'PATH_SPECIAL_FILE','member-race':'INPUT_CHANGED_DURING_READ','root-race':'PATH_COMPONENT_UNSAFE'}
    control(ident,mutation,codes[ident],exit=5,stage='path',layer='harness_only' if ident.endswith('race') else 'public')
control('collision','NEW already contains a sentinel file; preserve exact sentinel and all existing bytes.','OUTPUT_COLLISION',exit=5,stage='path')
control('incomplete','Remove manifest from copied bundle; preserve other files.','BUNDLE_INCOMPLETE',exit=3,operation='verify',stage='phase_1')
control('write-fault','Inject short write/error before manifest publication through test-only filesystem seam; no completion receipt.','RETENTION_WRITE_FAILED',exit=6,stage='publication',layer='harness_only')
control('interrupt','Interrupt after result write before manifest; next verify diagnoses incomplete with exit 3. Interrupted process status is separately recorded, not assumed to be this exit. No rollback/cleanup of unrelated files.','BUNDLE_INCOMPLETE',exit=3,stage='phase_1',layer='harness_only')
control('fsync-fault','Inject directory fsync failure after visible manifest; report complete_visible_durability_unknown, never unconditional success.','RETENTION_DIR_FSYNC_FAILED',exit=6,stage='publication',layer='harness_only')
control('broken-stream','Close stdout before receipt; signal internal/channel failure without inventing a delivered diagnostic.','OUTPUT_CHANNEL_FAILURE',exit=7,stage='receipt',layer='harness_only')
control('unknown-flag','Append --computed-result or --synthetic-digest to approved argv.','USAGE_ERROR',exit=2,stage='usage')
for ident,mutation in [('direct-cycle','Internal resolver maps A to A.'),('indirect-cycle','Internal resolver maps A to B to A.'),('diamond-sharing','Internal resolver maps A to B/C, each to D.')]:
    control(ident,mutation,'CYCLE' if ident!='diamond-sharing' else 'VALID_SHARING',exit=3 if ident!='diamond-sharing' else 0,stage='actual_traversal',layer='internal_algorithm')
control('ordering','Permute construction and file enumeration while retaining canonical semantic arrays and bytes. Compare complete semantic outputs.','UNCHANGED_SEMANTICS',exit=0,stage='all',layer='harness_only',base='P3-cross')
put('delivery-controls.json',dict(status='proposed exact transformations; no runtime executed',controls=controls))
put('diagnostic-catalog.json',dict(core=diagnostics,delivery=[{k:r[k] for k in ['id','expected_code','exit','stage']} for r in controls],ordering='phase; code; ASCII pointer; exact reference; existing nm subvalidator retains its own ordering; path/resource checks at operation',note='Delivery message keys are lower-case code. Target points to offending declared reference/field; filesystem targets are null bounded fallback. No successful receipt carries INTEGRITY_ONLY_COMPLETE as a diagnostic.'))

policy=json.loads(next((P/'objects').glob('*.nm.resource-policy.v1')).read_bytes())
resource=[]
for name,ceiling in policy['limits'].items():
    known={'unique_objects':['P10-objects128','P10-objects129'],'request_chain':['P10-shared_four','P10-fifth'],'request_contexts':['P10-context8','P10-context9'],'integer_digits':['P10-rational128','P10-rational129']}
    if name in known:resource.append(dict(dimension=name,ceiling=ceiling,layer='public_core',cases=known[name]));continue
    resource.append(dict(dimension=name,ceiling=ceiling,layer='internal_guard_and_integrated_tightened_limit',obligation='Actual counter at N admits next zero-work operation; attempted N+1 refuses before allocation/work. Separately use a valid real case, derive its measured demand d, invoke with limit d and d-1 where d>1 and other guards allow; preserve complete refusal and no truncation. Do not claim jointly realizable maximum valid inputs when another ceiling dominates.',expected='RESOURCE_LIMIT_EXCEEDED with dimension, attempted, limit; nearest valid d twin'))
    for adverse in (False,True):
        cmd('B-'+name+('-below' if adverse else '-fit'),'P10-shared_four','evaluate',dict(exit=4 if adverse else 0,code='RESOURCE_LIMIT_EXCEEDED' if adverse else None,dimension=name if adverse else None,stdout='empty' if adverse else 'receipt_plus_LF',stderr='diagnostic_plus_LF' if adverse else 'empty'), 'Before this pair, record independently inspected guard demand d for '+name+' on real bound P10-shared_four (including reservations, not only emitted bytes). Canonical limits file has only this dimension: d'+('-1' if adverse else '')+'. No calibration from expected semantic conclusions. If a preceding unavoidable guard prevents isolation, preserve evidence and report this pair unqualified; internal probe is not a substitute.')
        commands[-1]['argv']+=['--limits','{LIMITS}/'+name+('-below' if adverse else '-fit')+'.json']
        if name=='diagnostic_bytes':
            commands[-1]['case']='P2-below'
            commands[-1]['setup']='Use bound P2-below. Let d be the complete containment diagnostic UTF-8 length including LF. Set only diagnostic_bytes to d'+('-1' if adverse else '')+'. The bounded fallback keeps original stage/retry/bundle state but null target/resource; it does not replace the original historical evidence.'
            commands[-1]['expected']=dict(exit=4 if adverse else 3,code='DIAGNOSTIC_LIMIT_EXCEEDED' if adverse else 'OBSERVATION_UNCERTAINTY_INCONSISTENT',stdout='empty',stderr='diagnostic_plus_LF',bundle='absent')
put('resource-obligations.json',dict(existing_policy_sha256='a4a4c8016b35ab78a2b98797234a9a014f46a9bd891e45977477efd3be4ae22c',dimensions=resource,planned_boundary_probes=2*len(resource),application_commands='The four materialized public pairs are already in core matrix; remaining internal and demand-calibrated invocations are separately counted runtime qualification obligations, not fabricated fixed byte fixtures. Their actual calibrated argv and demand must be retained before executing.',safety=policy['safety_ceiling_proposals']))
put('command-matrix.json',dict(status='proposed_not_executed',commands=commands,counts=dict(core_evaluate=len(cases),standalone_verify=len(replays),standalone_replay=len(replays),delivery_public=sum(r['layer']=='public' for r in controls),resource_calibrated=2*(len(resource)-4),total=len(commands),application_executions=0),internal_and_fault_controls=sum(r['layer']!='public' for r in controls),resource_guard_pairs=len(resource),manual_dossiers=['C remains unresolved; conflicting source assumptions are not adjudicated','Chronology false-but-consistent declaration may pass; no custody proof','Derived hypothesis report requires separate manual adoption; no implicit next request'],note='Not the selector 142-command matrix. Runtime guard calibration supplies 20 pairs of scalar operational limits, not semantic oracle outputs. Harness controls are separately accounted; no command is implicitly executed by preparation.'))
summary=dict(cases=len(cases),groups=dict(sorted(Counter(x['group'] for x in cases).items())),completed=sum(x['expected']['exit']==0 for x in cases),refused=sum(x['expected']['exit']!=0 for x in cases),maxima={k:max(r[k] for r in measure) for k in measure[0] if k!='case'},work_maxima={k:max(r[k] for r in work) for k in work[0] if k!='case' and isinstance(work[0][k],int)},active_cas_objects=len(active),inactive_preparation_objects=len(list((P/'objects').iterdir()))-len(active))
put('measured-summary.json',summary)
print(json.dumps(dict(cases=len(cases),commands=len(commands),recovered_prior_instances=len(recoveries),work_maxima=summary['work_maxima']),sort_keys=True))
