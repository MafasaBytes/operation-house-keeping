# Proposed reassessment v2 accounting and resource policy

This proposes accounting for the approved v2 semantics under the unchanged nm
policy `a4a4c8016b35ab78a2b98797234a9a014f46a9bd891e45977477efd3be4ae22c`.
Its historical `proposed_not_approved` text is preserved; the selector owner later
approved those numerical limits. This document does not rewrite that object,
increase an allowance, or assert reassessment runtime capacity. The new build's
contract digest binds this accounting document and the package manifest.

## Charge rules and enforcement points

| Dimension | Proposed mandatory charge and guard |
| --- | --- |
| Unique objects / capture | Every distinct `(kind,digest)` has one complete captured raw byte object. Check kind, declared raw size, object limit and aggregate reservation before reading/decoding. Sharing avoids duplicate storage, not later reference or contextual work. The invocation is included. Input overrides and separately read retained files still count as physical reads. |
| Reference occurrences | Count every declared typed field occurrence, descriptor file/recipe occurrence, retained output reference check and transport-index entry. Output references only check declared closure; they never discover inputs. Do not deduplicate equal incoming references. |
| Edge visits / scoped expansions | Charge each attempted traversal, retained-role lookup and transport lookup. Charge intrinsic graph traversal plus every owning request-context scan; completed shared targets avoid repeated expansion only within that scan. An active-path target is a cycle. Different contextual obligations are not cached as one claim. |
| Context scan bytes | Charge complete bytes scanned in each distinct request context, plus retained-file role scans; sharing across contexts does not erase scans. Count at operation before scanning. Root ancestry is complete globally; each predecessor request is a separately validated context, not a second unbounded recursion into history. |
| JSON | Parse ordinary objects and manifest/result/trace file roles with existing ordinary string/depth/node guards. Count their actual parsed nodes. Only the outer closure's base64 transport has its derived string allowance. Retained output JSON is not opaque merely because carried as nm.basis. |
| Public reconstruction | Account E0/E1 separately, each required historical context and actual repeated reconstruction. Cache immutable owning-model reconstruction only with exact identity; contextual joins remain charged. Existing stricter public input guards continue to apply. |
| Decode / hash | Measure all base64 input/output raw bytes, all actual hash inputs, every original manifest commitment check and every repeated decode. No compression exemption. Capture counters and work counters are distinct; an unchanged cached byte still incurs a new contextual validation charge. |
| Prior reconstruction | Reserve exact canonical framing plus base64 lengths before construction. Each complete original file retains its original bound; the original seven-file aggregate retains 1 MiB. Keep exact original manifest/member bytes. Reconstructing 232,849 bytes is work even if none is written to disk. |
| New retention | Reserve exact invocation/closure/result/trace/build/policy and the approved manifest ceiling before creating output. Charge duplicated build/policy inspection files. Enforce each file bound and complete 1 MiB bundle; manifest last. Exhaustion refuses, with no truncation or claimed partial success. |
| Physical work | Instrument actual read/write calls and byte counts, executable/dependency hashing, copies/decodes, wall time and peak RSS. Manifest physical fields retain their specified layout; detailed work instrumentation belongs in qualification evidence. None of the preparation nulls is a measured runtime value. |

Counters are operational, not evidence of model validity. Intrinsic validation may
be reused only for identical content and role; role incompatibility refuses. Shared
material can carry multiple legitimate roles only if every required validator and
join passes. Four complete revisions per chain, eight owning request contexts and
128 unique objects are conjunctions, not a promise that all dimensions can reach
their maxima simultaneously. All ancestors through revision 1 remain mandatory.

`work-measurements.json` supplies a reproducible finite *static scan schedule*, not
runtime measurements. It separately counts intrinsic edges, scoped scans, role
references and transport checks; its aggregate edge counter includes all four.
The table measures full supplied inputs even for refusals. It does not assert that
a refused execution would reach or charge every represented operation. Qualification
must retain actual refusal timing, visited work and zero downstream work.

## Measured fit and the build-size condition

The largest assembled seven-file specimen is P7-newbaseline: **520,938 bytes**,
with **478,220 bytes** of closure and **353,434 captured raw bytes**. It carries a
**26,398-byte nonexecutable build specimen** and complete earlier assessment
history. These are preparation sizes, not successful deliveries. The original
232,849-byte prior-bundle example separately recovers exactly in every designated
prior-carriage case. The 219,976-byte approved prior-only transport is not the new
package measurement.

Holding P7-newbaseline's other bytes fixed, the closure consists of 443,020 bytes
plus `4 * ceil(B / 3)` for the new build's raw bytes B. The unchanged 524,288-byte
closure ceiling therefore permits **B <= 60,951** for that exact structure. At
60,952 bytes the framing is four bytes over. At the separate build ceiling of
65,536 bytes, closure would be **530,404 bytes**, **6,116 over**. That simultaneous
maximum corner does not fit, even though the whole-bundle reserve is 627,697 bytes.

This is a reported conjunction constraint, not a new 60,951-byte policy or an
excuse to omit executable sources. The real future build manifest must enumerate
all required source/dependency identity and fit every required valid case after
mechanical binding. Its size cannot be measured before implementation exists.
If it does not fit, stop for an owner decision; do not silently narrow the required
case, omit ancestry, fragment a build or increase a ceiling. No general promise is
made for arbitrary previously retained bundles up to 1 MiB. Their complete v2
carriage plus observation and history must satisfy every existing bound.

`measured-summary.json` gives all corpus maxima, including deliberate refusals:
129 objects, nine contexts, five revisions and 129-digit numerals are adverse
fixtures, not supported capacity. Their nearest valid twins use 128/eight/four/128.
Refusal diagnostics peak at 704 bytes including LF; receipts at 312, result at
7,333, trace at 14,445, and ordinary object at 86,811. Maximum parsed depth is 16.
Exact current counts, role work and graph charges are machine-readable rather
than estimated from a prior-material witness.

## Future qualification obligations

`resource-obligations.json` lists every existing limit and exact-limit/plus-one
guard obligations. Four full public pairs are already materialized. The other
dimensions have explicit internal guard pairs and separately listed real-input
commands with calibrated guard demand d and d-1. Demand includes reservations;
it is not inferred from successful output length. Diagnostic size uses the actual
refusal twin and bounded fallback. If isolation is impossible because an earlier
guard dominates, retain that fact as a coverage limitation rather than claiming a
full public maximum. Internal probes do not establish public admission.

The existing safety ceilings (512 MiB address space, 64 MiB retained runtime corpus,
30 seconds per command) are not raised or newly measured here. Measure actual
build hashing, reconstruction, fault paths and representative history/shared-DAG
work before claiming feasibility. Fixture/recovery archive bytes are preparation
material, separately measured from a retained runtime corpus. Allocate immutable
runtime runs on approved ext4 locations; stop before exhausting an approved corpus
budget and request an explicit evidence-retention plan if necessary. Do not delete
earlier runtime evidence to manufacture capacity.

END OF PROPOSED REASSESSMENT RESOURCE ACCOUNTING.
