# Proposed bounded implementation slices

No slice is authorized by this package. Prerequisites are owner approval of the
exact package/accounting policy, followed by explicit implementation authorization.
The accepted semantics and v2 amendment are already approved; those are not runtime
qualification. All ownership below is application-owned unless explicitly delegated
to an existing public contract. Preserve legacy commands, policies and results.

## Slice 1 — Captured contracts, closure and executable identity

Implement closed v2 shapes, canonical parsing, exact typed references, nomination
joins, identity collision rules, complete ancestors, sharing versus active cycles,
the fixed prior-bundle recipe and mandatory retained-file roles. Reserve reconstruction
before allocation; enforce all unchanged policies. Capture through maintained safe
file admission, not unchecked loaders. Derive real executable/dependency/contract
identity, including the current nr contract and supported historical nm contract.
Reject prepared witnesses and shaped substitutions. Historical nm builds are content
dependencies, not assertions of execution under the new build.

Red-first obligations: v2 exact prior recovery, role/recipe/manifest/member attacks,
missing ancestry, coherent identity twins, four/five revisions, eight/nine contexts,
128/129 objects, capture/string/node/work guards, cross-profile material and actual
build/policy substitutions. Public digest precedence and test-only cycle/diamond
tests remain separately labelled. No qualification, reassessment, CLI publication
or claimed semantic replay belongs to this slice. No production bypass is permitted.

## Slice 2 — Public observation admission, authority and baseline

Compose owning public E0/E1 reconstruction and admission. Enforce exact nominations,
procedure/decoder/evidence/context/unit joins, original selection pin and independent
new permission. Preserve acquisition/hold and exposure declarations as assertions.
Check uncertainty containment and chronology consistency before interpretation.
Retain baseline status for the exact captured assessment, including unavailable
and ineligible rows; don't attribute their absence or contradiction to E1.

Red-first obligations: inconsistent versus contained x/envelope; unknown versus
admitted observation; public unavailable baseline; denied/unknown/permitted authority;
procedure/context/decoder substitutions and coherent twins; declared chronology
versus verified content, and contradictory declarations. Assert zero branch/support
work after the corresponding gate. Existing public reconstruction is not counted
as outcome decoding. No support qualification, ranking, adoption or CLI delivery.

## Slice 3 — Full-envelope qualification and derived reporting

Implement exact finite-decimal interval intersections, including endpoint-only 1/3
versus 1/2. Reuse supplied-support qualification over every selected H/P outcome
for row validity and every intersecting branch for the conclusion. Preserve missing,
conflicting and unavailable sources; never infer a complement from a positive.
Emit every original H, reasoned statuses, result, trace and dependency references.
Do not call ranking or adopt a derived interpretation.

Red-first obligations: all P1–P9 mathematical/epistemic cases, no-fit/multiple-fit,
mixed branches, row-all-excluded refusal, retrospective predecessor disclosure and
revised-baseline twins. Compare to the frozen hand oracle and separate static check;
never rewrite them from runtime output. Exercise construction/file-order invariance.
No acquisition, next-request generation or automatic reranking.

## Slice 4 — Maintained commands, retention and semantic replay

Wire exactly the three documented reassessment commands. Use captured bytes for
all computation, complete seven-file retention, no-overwrite publication, manifest
last, exact counters and honest incomplete/durability states. Integrate real build
binding from Slice 1. Verification must not be advertised as recomputation.
Replay recovers the closure, independently re-admits E0/E1, repeats gates/baseline/
support qualification/assessment and compares newly derived result and trace.
There is no caller-supplied computed result or runtime callback boundary.

Red-first obligations: real admitted and withholding deliveries; isolated same-build
replay with original input directories absent; rehashed semantic forgery; required
authority/closure/build/policy/profile substitutions; unsafe files, collisions,
incomplete bundles and interrupted publication. Test the actual CLI/filesystem on
the approved ext4 runtime location. Existing thermal/governed/measurement routes
need affected regressions. Do not defer semantic replay to the qualification slice.

## Slice 5 — Runtime qualification and final release evidence

Execute the owner-approved exact command matrix and separately accounted internal
guard/traversal and manual dossier obligations. Measure physical reads/writes,
decode/reconstruction/hash/scoped work, time/RSS, complete retained fit, refusal
timing and partial-publication state. No static maximum substitutes for this work.
Exercise all applicable exact-limit/plus-one, history, resource, fault, channel and
recovery controls. Preserve failed invocations and ordinary repair red/fixed evidence.
Report skips/environment restrictions separately. No untested platform guarantees.

Run the full repository suite, required application gates and clean-environment
delivery against the final candidate. Demonstrate committed-only recovery after
authorized documentation/artifact commits, real command evaluation/verify/replay,
and unchanged legacy behavior. Distinguish tested code from administrative commits.
Final release documentation covers local attestation, same-author oracle provenance,
bounded history and manual adoption. Slice acceptance and final owner acceptance
remain separate gates; do not allocate an ADR or successor milestone.

## Binding and discrepancy discipline

The prepared build is intentionally rejected by production. A future harness binds
the actual clean nr executable before semantic cases, records its exact source and
dependency identity, and updates only mechanical references/accounting/commitments.
The nr build logical ID should be the 64-character SHA of its canonical identity
body (the seven candidate §3 body fields), with revision 1 and null predecessor;
the factory compares the entire derived witness. This avoids pretending two actual
build bodies are one mutable build revision. It is a package wire choice for owner
approval, not authentication. Existing nm build IDs remain unchanged: historical
same-kind/ID/revision collisions must still refuse rather than be renamed.

Stop if binding/required closure exceeds any effective limit, a proof expectation
requires changed semantics, or a dependency/backend change is necessary. Do not
truncate an ancestor, remove a candidate, substitute an expected result, omit a
source file from real build identity, weaken a guard or silently narrow support.
Ordinary implementation defects should proceed to green within an authorized slice.

END OF PROPOSED REASSESSMENT IMPLEMENTATION PLAN.
