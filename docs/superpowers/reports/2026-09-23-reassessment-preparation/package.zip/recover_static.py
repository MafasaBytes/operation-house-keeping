"""Recover a preparation archive in a NEW directory and verify static evidence.

Usage: python recover_static.py PACKAGE.zip NEWDIR
No original input directory, imports from the application, network or local cache.
Does not execute the prepared application commands or confer executable identity.
"""
import base64
import hashlib
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import sys
import zipfile

def H(b):return hashlib.sha256(b).hexdigest()
def C(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def safe_names(z):
    names=z.namelist();assert len(names)==len(set(names))
    for info in z.infolist():
        p=PurePosixPath(info.filename)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in info.filename
        assert not info.is_dir() and (info.external_attr>>16)&0o170000 in (0,0o100000)
    return names
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def main(archive,dest):
    assert not dest.exists();dest.mkdir()
    with zipfile.ZipFile(archive) as z:
        names=safe_names(z);manifest=json.loads(z.read('MANIFEST.json'))
        assert set(names)=={'MANIFEST.json'}|{x['path'] for x in manifest['files']}
        for row in manifest['files']:
            b=z.read(row['path']);assert len(b)==row['bytes'] and H(b)==row['sha256']
            f=dest/row['path'];f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
        (dest/'MANIFEST.json').write_bytes(z.read('MANIFEST.json'))
    source=dest/'authority/next-measurement-frozen-authority.zip'
    with zipfile.ZipFile(source) as z:
        safe_names(z)
        for n,d in [('package.zip','a6e48ea447444e4f7c12993d9567905978c2a0c8972414e0ac421df47cd2217f'),('MANIFEST.json','18ed716ab327944f700b8e00b30235512a9ea6d5b41f49e87ab88b343680e2ea'),('recovery.json','ecfe3f62d796a21edc5509419206aebb68d46d8d3f10736d6708c412110a8dac')]:assert H(z.read(n))==d
        old=json.loads(z.read('MANIFEST.json'))
        with zipfile.ZipFile(io.BytesIO(z.read('package.zip'))) as inner:
            safe_names(inner)
            for row in old['files']:
                b=inner.read(row['path']);assert H(b)==row['sha256'] and len(b)==row['bytes']
    checker=module('standalone_static',dest/'check_static.py');cases=checker.main(dest)
    original=module('standalone_original',dest/'authority/reconstruct.py')
    original_files,original_report=original.recover((dest/'authority/witness.json').read_bytes())
    for row in json.loads((dest/'authority/expected-files.json').read_bytes()):assert H(original_files[row['name']])==row['sha256'] and len(original_files[row['name']])==row['bytes']
    # Exact original recovery from each complete NEW retained closure, not from
    # authority/witness or global pool. Refused cases have no retained closure.
    counts=0
    for case in json.loads((dest/'cases.json').read_bytes()):
        path=dest/'cases'/case['id']/'closure.json'
        if not path.exists():continue
        closure=json.loads(path.read_bytes());pool={(m['reference']['kind'],m['reference']['sha256']):base64.b64decode(m['bytes'],validate=True) for m in closure['members']}
        for k,b in pool.items():
            if k[0]!='nr.retained-bundle.v2':continue
            descriptor=json.loads(b);need={k,(descriptor['closure']['invocation']['kind'],descriptor['closure']['invocation']['sha256'])}
            need.update((r['kind'],r['sha256']) for r in descriptor['closure']['members'])
            need.update((f['source']['reference']['kind'],f['source']['reference']['sha256']) for f in descriptor['files'] if 'reference' in f['source'])
            wire=C(dict(schema='nr.carriage-witness.v2',descriptor=dict(kind=k[0],sha256=k[1]),members=[dict(reference=dict(kind=x[0],sha256=x[1]),encoding='base64',bytes=base64.b64encode(pool[x]).decode()) for x in sorted(need)]))
            files,_=original.recover(wire);assert files==original_files;counts+=1
    receipt=dict(schema='reassessment-static-recovery/v2',archive_sha256=H(archive.read_bytes()),manifest_sha256=H((dest/'MANIFEST.json').read_bytes()),files=len(manifest['files']),payload_bytes=sum(x['bytes'] for x in manifest['files']),cases=cases['cases'],groups=cases['proof_groups'],completed_new_closures_with_exact_original_recovery=counts,original_files=7,original_bytes=sum(map(len,original_files.values())),application_executions=0,original_bundle_directory_used=False,application_imports=False,network=False,local_cache=False,status='static_bytes_and_math_recovered; no production replay or build acceptance')
    print(json.dumps(receipt,sort_keys=True))
    return receipt
if __name__=='__main__':main(Path(sys.argv[1]),Path(sys.argv[2]))
