# Reassessment v2 bounded preparation readiness

Status: one exact-package candidate for owner review. Static preparation is
complete; implementation, application proof and runtime-capacity claims remain
unauthorized. Actual executable binding is a mandatory future prerequisite, with
the concrete size condition below. No semantic amendment beyond the approved v2
carriage/accounting amendment is proposed here.

## Authority and preservation

Starting/current checkpoint is `15bd9dcb1559898944149cab0ec78b962019ab50`, branch
`main`; locally recorded `origin/main` agrees. No remote operation was performed.
The owner's earlier publication statement is not fresh remote verification.
Starting inventory measured **2,722 regular tracked/untracked files and 1,468
untracked paths**. `starting-inventory.json` and `preservation.json` retain exact
commitments and the unchanged-file check. Tracked/index state remained clean.
All new artifacts belong solely to this preparation directory; no ledger, backend,
dependencies, runtime results, permissions or frozen documents were changed.

The approved amendment SHA is
`d7136af5c4a086361e92be159d9aadc3c9d552d315dc2b2a3ecbf7df952a1676`;
its recovery archive SHA is
`cd07349f8b639e57f92ad38e073a8953e54d6506e4695354595a405e8d05a674`.
Both were checked before use; all 16 archive members and seven recovered files
matched. `authority/commitments.json` pins the proposal, corrected candidate,
focused review, discrepancy and v2 amendment. Their exact bytes are retained.

The earlier review commitment
`9909d9e7a439f97ae255ffe39402e9232bda4144acf21cef71eeaaf9de54b826`
remains unresolved historical evidence. The owner-adopted recovered review is
`5fb61f732f72e93b6c4ab9dd5459a6829468ce0ac209acfd9b2f00f63556ce06`,
20,682 bytes/211 lines, with the final blank line preserved. An earlier task-output
capture matched that local version; this does not prove identity with the missing
commitment. No earlier receipt or finding was rewritten or relabelled a typo.

## Coverage and oracle

| Approved group | Core cases | Decisive coverage |
| --- | ---: | --- |
| P1 | 3 | scalar 60/40 and hard degenerate envelope; model-relative conclusions |
| P2 | 5 | x below/above/reversed interval, contained twin, incompatible unit |
| P3 | 6 | crossing/closed endpoints and exact points 50/70 |
| P3b | 2 | exact singleton 1/3 excluded from decimal domain, 1/2 included |
| P4 | 5 | local/remote gaps, overlap, valid partition, unsupported literal decoder |
| P5 | 6 | no fit, missing/conflicting/unavailable support, irrelevant gap, positive-only |
| P6 | 3 | mixed envelope unresolved, multiple fits, all-excluded row invalid |
| P7 | 4 | frozen baseline-ineligible on permit/exclude, none eligible, explicit new baseline |
| P8 | 7 | present/absent prior, asserted before/after/unknown, timestamps absent/present, contradiction |
| P9 | 8 | procedure/decoder/context stale-support joins and coherent twins, retrospective revision |
| P10 | 19 | permission, hold/acquisition, public absence, uncertainty, four/five history, contexts/objects/digits |
| P10b | 4 | original/external pins, valid twin, result digest is not authority |

Total **72 core cases: 51 completed reports, 21 technical refusals**. Completed
withholding remains a report. Original H/P/S and every required ancestor remain;
no unobserved fit or missing support eliminates a hypothesis. Original prediction
and new observation are separate. No local byte/hash/timestamp proves when the
operator first knew a result. Manual adoption and no reranking remain explicit.

The proposed command matrix has **180 invocation rows**: 72 core evaluations,
20 standalone verifications, 20 independent replays, 28 public delivery controls,
and 40 calibrated resource-boundary invocations. These are **planned, zero run**.
Ten additional internal/fault controls (including three graph tests) and 24
internal resource guard pairs are separately identified; the four materialized
public resource pairs are already in the core count. Three manual dossiers cover
unresolved C, nonprovable custody and manual adoption. The selector's old 142
commands and six harness-only controls are not reused as reassessment counts.

Delivery mutations and exact phase/code/exit expectations are specified in
`delivery-controls.json` and `diagnostic-catalog.json`. Paths, actual build hashes,
physical manifest counters and calibrated operational demand are runtime-bound
parameters, not invented passing evidence. Core semantic expectations never come
from runtime output. Runtime calibration cannot change those expectations or a
ceiling. Unisolatable resource pairs remain explicitly unqualified, not silently
replaced by internal probes. Production has no synthetic resolver or bypass option.

The lead hand-derived the oracle; a separately written **same-author** checker
uses exact rational intersections and supplied source signs. That is independence
from the future runtime, not independent-reviewer evidence. The frozen focused
review predates and does not endorse this fixture package. `static-checks.json`
records all 72 closure/hash/identity checks and the applicable math; it also checks
that P9 substitutions isolate their intended stale join and valid twins cohere.
`shape-checks.json` records 666 emitted shape checks, with its limited schema
keyword coverage disclosed. `public-input-checks.json` records 13 distinct public
snapshot reconstructions using existing pure public contracts, not application
admission or reassessment execution. No tests of a future runtime were run.

## Complete carriage, measurements and recovery

All complete case templates include the full seven files: invocation, closure,
result, trace, build, policy and manifest. `input-measurements.json` measures full
new observation/authority/uncertainty/support/history plus outputs, not merely the
219,976-byte prior-material witness. The largest specimen is **520,938 bytes**,
with **478,220-byte closure**, **353,434 captured bytes**, **7,333-byte result**,
and **14,445-byte maximum trace** (maxima may belong to different cases).
Core diagnostic/receipt maxima are 704/312 bytes including LF. The 26,398-byte new
build specimen is explicitly nonexecutable. All valid specimens fit unchanged
byte/graph limits; intentional 129-object/nine-context/five-revision/129-digit
cases refuse. Their full stored preparation inputs remain recoverable.

The static scan schedule peaks at 398 reference/transport/role uses, 967 aggregate
edge visits, 154 scoped expansions, 1,360,243 scoped scan bytes, and 29,469 public
reconstruction nodes. Role validation adds up to 208 output-reference checks and
1,076 JSON nodes. Prior reconstruction is 232,849 bytes and its six manifest hash
checks cover 231,877 bytes. New-closure encode raw bytes peak at 353,434; prior
recipe encoding adds 129,617; replay decode raw work peaks at 415,725. These are
static schedules, not measured CPU/RSS/physical reads or a runtime upper bound.

**Real-build fit remains conditional:** the largest closure permits at most
60,951 raw bytes for its new build with other current bytes fixed. Substituting
the separate 65,536-byte build ceiling yields 530,404 closure bytes, exceeding
524,288 by 6,116. The package does not promise this simultaneous maximum. No
source, evidence or ancestor may be dropped to fit. If the actual complete build
fails a required valid case, stop for owner direction; no limit increase or
supported-input restriction is silently approved. See RESOURCES.md for formulas.

Ten static carriage variants comprise one exact-recovery twin and nine malformed,
missing, substituted, role-incompatible or commitment-invalid twins; the approved
reconstruction checker accepts only the valid one. Ten assembled input cases carry
the accepted original prior material, including a deliberate history-exhaustion
case. Six completed retained closures independently recover the original seven
files without the original directory. `prior-recovery-checks.json` records input
recovery; the final recovery receipt records completed retained-closure recovery.

The obsolete 311,968-byte v1 wrapper was reconstructed from the frozen fields and
exact original files against its recorded SHA
`553b78f5d7a4123255e6543e434a7bf642ee8401362f609283a93fb0013559df`.
It was originally measured in memory only. Its newly recovered bytes are labelled
historical oversized material. Resource refusal precedes version validation;
a separate small v1-header control tests version dispatch. Neither is a supported
v2 input. Historical v1 documents and original manifests are unchanged.

`MANIFEST.json` commits the one package's exact members; `package.zip` retains
them, and `recovery-receipt.json` binds archive/manifest/readiness digests and exact
payload/archive sizes. Recovery verifies nested frozen-package commitments and
case-local closure, then reconstructs the original files using only captured new
closures. The archive is a preparation transport, not a 1 MiB runtime bundle.
External Python and, for owning-contract checks, the existing dependency environment
remain prerequisites; no dependency acquisition or executable compatibility claim.

## Remaining owner gates

Approve or reject this exact package, its proposed closed wire/diagnostic choices,
five-slice plan and versioned accounting interpretation under unchanged limits.
Real-build logical ID derives from the complete seven-field identity body; no
caller label confers executable identity. Actual runtime safety, all fault/stream
checks and real semantic replay remain mandatory implementation/qualification work.
No observed static contradiction requires another semantic amendment. The concrete
build-size and conjunctive-capacity qualifications above remain unresolved until a
real executable can be bound and measured.

Implementation requires a separate scoped authorization after exact-package approval.
No automatic discovery, physical acquisition, probabilities, causal truth, empirical
accuracy, globally best diagnosis or autonomous control is delivered by preparation.
C remains unresolved; IN-001 and CI-001 remain open and unselected. Local attestation,
same-author oracle, platform/durability limitations and manual adoption are unchanged.

END OF REASSESSMENT V2 PREPARATION READINESS REPORT.
