"""Static component controls against the approved reconstruction checker only."""
import base64
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_static_checker',P/'authority/reconstruct.py')
checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
C=checker.canonical;H=checker.digest;K=checker.key
base=json.loads((P/'authority/witness.json').read_bytes())

def variant(mode):
    w=copy.deepcopy(base);pool={K(m['reference']):base64.b64decode(m['bytes']) for m in w['members']}
    old=K(w['descriptor']);d=json.loads(pool[old]);del pool[old]
    def file_row(n):return next(r for r in d['files'] if r['name']==n)
    if mode=='unknown_recipe':file_row('closure.json')['source']={'recipe':'arbitrary_patch'}
    elif mode=='recipe_extra':d['closure']['path']='../original-directory/closure.json'
    elif mode=='missing_member':
        victim=next(k for k in pool if k[0]=='nm.evidence.v1');del pool[victim]
    elif mode=='substituted_bytes':
        victim=next(k for k in pool if k[0]=='nm.evidence.v1');pool[victim]=pool[victim]+b' '
    elif mode=='missing_recipe_member':d['closure']['members'].pop()
    elif mode=='duplicate_recipe_member':d['closure']['members'].append(d['closure']['members'][-1])
    elif mode=='incompatible_role':
        row=file_row('result.json');del pool[K(row['source']['reference'])]
        original_build=next(k for k in pool if k[0]=='nm.build.v1')
        wrong=('nm.basis',original_build[1]);pool[wrong]=pool[original_build]
        row['source']['reference']=dict(kind=wrong[0],sha256=wrong[1])
    elif mode=='manifest_mismatch':
        row=file_row('manifest.json');oldm=K(row['source']['reference']);v=json.loads(pool.pop(oldm))
        next(r for r in v['files'] if r['name']=='result.json')['sha256']='0'*64
        b=C(v);k=('nm.basis',H(b));pool[k]=b;row['source']['reference']=dict(kind=k[0],sha256=k[1])
    elif mode=='missing_file':d['files']=[r for r in d['files'] if r['name']!='manifest.json']
    elif mode!='shared_valid':raise ValueError(mode)
    b=C(d);new=('nr.retained-bundle.v2',H(b));pool[new]=b;w['descriptor']=dict(kind=new[0],sha256=new[1])
    w['members']=[dict(reference=dict(kind=k[0],sha256=k[1]),encoding='base64',bytes=base64.b64encode(b).decode()) for k,b in sorted(pool.items())]
    return C(w),pool

results=[];out=P/'carriage-controls';out.mkdir(exist_ok=True)
for name in ['shared_valid','unknown_recipe','recipe_extra','missing_member','substituted_bytes','missing_recipe_member','duplicate_recipe_member','incompatible_role','manifest_mismatch','missing_file']:
    wire,pool=variant(name);(out/(name+'.json')).write_bytes(wire)
    integrity=all(H(b)==k[1] for k,b in pool.items())
    accepted=True
    try:
        files,report=checker.recover(wire)
    except (AssertionError,KeyError,ValueError):
        accepted=False
    if accepted:
        assert name=='shared_valid',('unexpected static acceptance',name)
        for row in json.loads((P/'authority/expected-files.json').read_bytes()):
            assert len(files[row['name']])==row['bytes'] and H(files[row['name']])==row['sha256']
        outcome='exact_original_recovery'
    else:
        assert name!='shared_valid', 'valid recovery refused'
        outcome='static_refusal'
    assert integrity==(name!='substituted_bytes')
    results.append(dict(case=name,bytes=len(wire),sha256=H(wire),all_present_member_hashes_match=integrity,outcome=outcome))
(P/'carriage-static-checks.json').write_bytes(C(dict(checks=results,application_executions=0,scope='approved static reconstruction checker; not production admission or runtime guard evidence')))
print(json.dumps(dict(checks=len(results),application_executions=0)))
