"""Static owning-contract reconstruction of fixture snapshots only.

Requires the existing accepted checkout and environment. This does not invoke any
application command, selector, proposed reassessment, store or proof harness.
"""
import hashlib
import json
import platform
from pathlib import Path
import pydantic
from backend.state_classification import StateClassificationResult

P=Path(__file__).resolve().parent
cases=json.loads((P/'cases.json').read_bytes());refs=set()
for case in cases:
    for r in json.loads((P/'cases'/case['id']/'input.json').read_bytes())['members']:
        if r['kind']=='nm.evidence.v1':refs.add(r['sha256'])
checked=[]
for digest in sorted(refs):
    b=(P/'objects'/(digest+'.nm.evidence.v1')).read_bytes();assert hashlib.sha256(b).hexdigest()==digest
    v=json.loads(b);snapshot=v['snapshot'];obj=StateClassificationResult.model_validate(snapshot)
    assert obj.model_dump(mode='json')==snapshot
    checked.append(dict(evidence_sha256=digest,snapshot_bytes=len(json.dumps(snapshot,sort_keys=True,separators=(',',':')).encode())))
result=dict(scope='static input public-schema/model consistency; not admission or application proof',application_executions=0,python=platform.python_version(),pydantic=pydantic.__version__,checked=checked)
(P/'public-input-checks.json').write_text(json.dumps(result,sort_keys=True,separators=(',',':')))
print(json.dumps(dict(unique_public_snapshots=len(checked),application_executions=0)))
