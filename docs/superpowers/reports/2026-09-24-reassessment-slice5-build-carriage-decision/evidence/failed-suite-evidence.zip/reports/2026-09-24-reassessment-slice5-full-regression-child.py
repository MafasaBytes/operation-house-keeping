"""Single full-regression child: accounting/routing only; production stays unchanged."""
import contextlib,hashlib,json,os,sys,time
from pathlib import Path
REPO=Path('/mnt/d/operation-house-keeping')
ROOT=Path('/home/mafasa/operation-house-keeping-runtime/bounded-decision-workflow/test-workspaces/nr-slice5-qualification-r1/regressions/full-repository-suite-once')
COLLECT='--collect-only' in sys.argv
sys.path.insert(0,str(REPO));sys.path.insert(0,str(REPO/'tests/reassessment_profile'))
import subprocess
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='40fbb7b0a5ea5251179a9661c782a41cf7356ed6'
from applications.bounded_decision_workflow.reassessment_build import identity
assert hashlib.sha256(identity()).hexdigest()=='6cef6e1f4915e95ac4a02058e86bfe88cd8eea05cd6c7f2d027bc5780754b4b8'

def wire(v):return json.dumps(v,sort_keys=True,separators=(',',':')).encode()
def scan(root):
 v=dict(bytes=0,files=0,directories=0,physical=0)
 for here,ds,fs in os.walk(root,followlinks=False):
  try:v['physical']+=os.lstat(here).st_blocks*512;v['directories']+=1
  except FileNotFoundError:continue
  for n in fs+[n for n in ds if (Path(here)/n).is_symlink()]:
   try:s=os.lstat(Path(here)/n)
   except FileNotFoundError:continue
   v['bytes']+=s.st_size;v['files']+=1;v['physical']+=s.st_blocks*512
 return v
# Route only the old delivery harness's filesystem/accounting functions.
import delivery_budget as db
db.ROOT=ROOT/'delivery';active=0

def inventory():
 v=scan(db.ROOT)
 assert v['bytes']+active<=16777216 and v['files']<=1024 and v['directories']<=40
 counts={k:0 for k in db.CAPS}
 for here,ds,fs in os.walk(db.ROOT,followlinks=False):
  for n in fs+[n for n in ds if (Path(here)/n).is_symlink()]:
   p=Path(here)/n;counts[p.relative_to(db.ROOT).parts[0]]+=p.lstat().st_size
 return dict(categories=counts,total=v['bytes'],allocated=v['physical'],files=v['files'],directories=v['directories'])
def record(value):
 inventory();paths=sorted((db.ROOT/'indexes').glob('*.json'));previous=paths[-1]
 raw=wire(dict(previous_sha256=hashlib.sha256(previous.read_bytes()).hexdigest(),**value))
 assert sum(p.stat().st_size for p in paths)+len(raw)<=262144
 with (db.ROOT/'indexes'/f'{len(paths):04d}-record.json').open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
@contextlib.contextmanager
def reserve(category,size,label):
 global active
 inventory();active+=size
 try:
  inventory();record(dict(event='reserve',category=category,bytes=size,label=label));yield
 finally:
  active-=size;record(dict(event='observed',label=label,inventory=inventory()))
def directory(category,label):
 inventory();p=db.ROOT/category/label;p.mkdir();return p
def put(path,raw):
 with reserve(path.relative_to(db.ROOT).parts[0],len(raw),str(path.relative_to(db.ROOT))):
  with path.open('xb') as f:f.write(raw)
for name in ['inventory','record','reserve','directory','put']:setattr(db,name,globals()[name])
if not COLLECT:
 db.ROOT.mkdir()
 for name in db.CAPS:(db.ROOT/name).mkdir()
 (db.ROOT/'indexes/0000-identity.json').write_bytes(wire(dict(candidate='40fbb7b0a5ea5251179a9661c782a41cf7356ed6',routing='charged full-regression envelope; original Slice 4 root read-only')))

import pytest
class Evidence:
 def __init__(self):self.last=0;self.peak=dict(bytes=0,files=0,directories=0,physical=0);self.reports=0
 def pytest_collection_finish(self,session):
  data=dict(candidate='40fbb7b0a5ea5251179a9661c782a41cf7356ed6',collect_only=COLLECT,nodes=[dict(id=i.nodeid,skip=[str(m.kwargs.get('reason','')) for m in i.iter_markers('skip')]) for i in session.items])
  with (ROOT/('collection-preflight.json' if COLLECT else 'collection-executed.json')).open('xb') as f:f.write(wire(data))
 def check(self,force=False):
  if COLLECT or (not force and time.monotonic()-self.last<2):return
  self.last=time.monotonic();v=scan(ROOT)
  for k in v:self.peak[k]=max(self.peak[k],v[k])
  b=json.loads((ROOT/'launch-budget.json').read_bytes())['non_suite_baseline']
  limits=dict(bytes=268435456,files=65536-b['files'],directories=24576-b['directories'],physical=1572864000-b['physical'])
  margin=dict(bytes=8388608,files=1024,directories=512,physical=16777216)
  if any(v[k]+margin[k]>limits[k] for k in v):
   with (ROOT/'budget-stop.json').open('xb') as f:f.write(wire(dict(observed=v,limits=limits,required_next_test_margin=margin)))
   pytest.exit('Retained-resource preflight margin exhausted; no retry authorized',returncode=91)
 def pytest_runtest_setup(self,item):self.check()
 def pytest_runtest_logreport(self,report):
  self.reports+=1
  v=dict(node=report.nodeid,when=report.when,outcome=report.outcome,duration=report.duration,longrepr=str(report.longrepr) if report.failed or report.skipped else None)
  with (ROOT/'node-results.jsonl').open('ab') as f:f.write(wire(v)+b'\n')
 def pytest_sessionfinish(self,session,exitstatus):
  if not COLLECT:
   v=scan(ROOT)
   for k in v:self.peak[k]=max(self.peak[k],v[k])
   with (ROOT/'child-usage.json').open('xb') as f:f.write(wire(dict(observed_highwater=self.peak,final=v,exit=exitstatus,node_report_count=self.reports,measurement='sampled, plus checks between tests; reserved ceiling is distinct from observed highwater')))
args=['-o','addopts=','-p','no:cacheprovider','tests/','--deselect=tests/applications/bounded_decision_workflow/test_s7_release.py::test_two_clean_roots_twelve_constructions_and_exact_replay','--deselect=tests/applications/bounded_decision_workflow/test_s7_release.py::test_accepted_s6_archive_recovers_in_clean_matching_build']
if COLLECT:args+=['--collect-only','-qq']
else:args+=['-ra','--basetemp='+str(ROOT/'tmp/pytest-once'),'--junitxml='+str(ROOT/'full-suite.xml')]
raise SystemExit(pytest.main(args,plugins=[Evidence()]))
