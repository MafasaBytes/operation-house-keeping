"""Preflight then exactly one full regression; outputs and failures retained."""
import importlib.util,json,os,resource,selectors,signal,subprocess,sys,time
from pathlib import Path
REPO=Path('/mnt/d/operation-house-keeping');REPORTS=REPO/'docs/superpowers/reports'
s=importlib.util.spec_from_file_location('amended',REPORTS/'2026-09-24-reassessment-slice5-amended-budget.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
ROOT=q.ROOT/'regressions/full-repository-suite-once';SOURCE=q.ROOT/'checkouts/source-0';CHILD=REPORTS/'2026-09-24-reassessment-slice5-full-regression-child.py'
F='40fbb7b0a5ea5251179a9661c782a41cf7356ed6';A='358d2867db478494ca8b6e6475b83fdd53a9750c'
def records():return [json.loads(p.read_bytes()) for p in sorted((q.ROOT/'indexes').glob('*record.json'))]
def scan(root):
 v=dict(bytes=0,files=0,directories=0,physical=0)
 for here,ds,fs in os.walk(root,followlinks=False):
  try:v['directories']+=1;v['physical']+=os.lstat(here).st_blocks*512
  except FileNotFoundError:continue
  for n in fs+[n for n in ds if (Path(here)/n).is_symlink()]:
   try:s=os.lstat(Path(here)/n)
   except FileNotFoundError:continue
   v['bytes']+=s.st_size;v['files']+=1;v['physical']+=s.st_blocks*512
 return v

def ready():
 assert q.sha((REPORTS/'2026-09-24-reassessment-slice5-bounded-completion.md').read_bytes())=='3490d34cb2909f6b7e47710630cab0a0e8e312bf6bb5938714a47bb590e74d84'
 assert subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()==A
 assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==F
 assert not subprocess.check_output(['git','-C',str(REPO),'status','--porcelain','--untracked-files=no'])
 assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'])
 assert set(subprocess.check_output(['git','-C',str(REPO),'diff','--name-only',F,'--','applications','backend','tests'],text=True).splitlines())=={'tests/reassessment_profile/qualification_delivery_tail.py','tests/reassessment_profile/qualification_resources.py','tests/reassessment_profile/qualification_retry19.py'}
 assert any(r.get('event')=='owner_full_regression_retention_amendment' for r in records())

def command(collect):
 a=['bwrap','--unshare-user','--unshare-pid','--die-with-parent','--ro-bind','/','/','--bind',str(ROOT),str(ROOT),'--ro-bind',str(SOURCE/'.git'),str(REPO/'.git'),'--ro-bind',str(SOURCE/'applications'),str(REPO/'applications'),'--ro-bind',str(SOURCE/'backend'),str(REPO/'backend'),'--proc','/proc','--dev','/dev','--chdir',str(REPO),sys.executable,str(CHILD)]
 if collect:a+=['--collect-only']
 return a

def run(collect):
 prefix='preflight2' if collect else 'full-suite';argv=command(collect)
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',GIT_OPTIONAL_LOCKS='0',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',TMPDIR=str(ROOT/'tmp'),BDW_UNSUPPORTED_FILE=str(REPO/'README.md'),BDW_UNSUPPORTED_OUTPUT_PARENT=str(REPO),NR_ATTEMPT='full-once',NR_OUTPUT_CATEGORY='outputs');env.pop('PYTHONPATH',None)
 q.record(dict(event='full_regression_preflight_command' if collect else 'command',tag=prefix,head=F,argv=argv,environment={k:env[k] for k in ['PYTHONDONTWRITEBYTECODE','PYTHONNOUSERSITE','GIT_OPTIONAL_LOCKS','PYTEST_DISABLE_PLUGIN_AUTOLOAD','TMPDIR','BDW_UNSUPPORTED_FILE','BDW_UNSUPPORTED_OUTPUT_PARENT','NR_ATTEMPT','NR_OUTPUT_CATEGORY']},write_root=str(ROOT),network='host loopback available for existing local HTTP tests; no acquisition'))
 def bounds():
  resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648));resource.setrlimit(resource.RLIMIT_FSIZE,(8388608,8388608))
 start=time.monotonic();last=0;peak=dict(bytes=0,files=0,directories=0,physical=0);reason=None;total=0
 with (ROOT/(prefix+'.stdout')).open('xb') as so,(ROOT/(prefix+'.stderr')).open('xb') as se:
  child=subprocess.Popen(argv,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=bounds,start_new_session=True)
  sel=selectors.DefaultSelector();sel.register(child.stdout,selectors.EVENT_READ,so);sel.register(child.stderr,selectors.EVENT_READ,se)
  while sel.get_map():
   if time.monotonic()-start>(300 if collect else 7200) and reason is None:reason='timeout';os.killpg(child.pid,signal.SIGKILL)
   for key,_ in sel.select(.2):
    b=os.read(key.fileobj.fileno(),4096)
    if not b:sel.unregister(key.fileobj);continue
    if total+len(b)>2097152:
     if reason is None:reason='stream_limit';os.killpg(child.pid,signal.SIGKILL)
     b=b[:max(0,2097152-total)]
    key.data.write(b);key.data.flush();total+=len(b)
   if time.monotonic()-last>5:
    last=time.monotonic();v=scan(ROOT)
    for k in v:peak[k]=max(peak[k],v[k])
    if v['bytes']>260046848 and reason is None:reason='near_suite_byte_ceiling';os.killpg(child.pid,signal.SIGKILL)
  status=child.wait();sel.close()
 v=scan(ROOT)
 for k in v:peak[k]=max(peak[k],v[k])
 result=dict(exit=status,termination=reason,seconds=time.monotonic()-start,observed_peak=peak,final=v,streams_bytes=total,stdout_sha256=q.sha((ROOT/(prefix+'.stdout')).read_bytes()),stderr_sha256=q.sha((ROOT/(prefix+'.stderr')).read_bytes()))
 q.record(dict(event='full_regression_preflight_result' if collect else 'command_result',tag=prefix,head=F,**result))
 print(json.dumps(result),flush=True)
 return result

ready()
if sys.argv[1:]==['--preflight']:
 assert ROOT.is_dir() and not (ROOT/'collection-preflight.json').exists()
 with q.transaction('full-regression-preflight-only2',{'regressions':2097152},files=24,dirs=12):
  q.record(dict(event='full_suite_preflight_storage_claim',bytes=2097152,charged_within_total_full_suite_envelope=268435456,test_executions=0,slot_consumed=False))
  result=run(True)
  q.record(dict(event='full_suite_preflight_complete',ready=result['exit']==0 and result['termination'] is None,tests_executed=0,slot_consumed=False))
elif sys.argv[1:]==['--run-once']:
 assert any(r.get('event')=='full_suite_preflight_complete' and r['ready'] for r in records())
 assert not any(r.get('event')=='regression_envelope_claim' and r.get('id')=='full-repository-suite' for r in records())
 used=scan(ROOT);baseline=q.census()
 growth=268435456-used['bytes'];files=65536-baseline['files']-64;dirs=24576-baseline['directories']-16
 q.reserve({'regressions':growth,'indexes':262144},files=files+2,dirs=dirs)
 with q.transaction('full-regression-once',{'regressions':growth,'indexes':245760},files=files,dirs=dirs):
  q.record(dict(event='regression_envelope_claim',id='full-repository-suite',slot=1,head=F,cap=268435456,already_charged_preparation_bytes=used['bytes'],remaining_reserved_bytes=growth,retries=0,expected='all selected nodes pass or retain documented optional-dependency skips; exactly two completed S7 nodes separately credited',peak_coexistence='existing retained corpus plus all test material; no runner cleanup; finite highwater headroom and whole-slot reservation before launch'))
  b=dict(bytes=baseline['total']-used['bytes'],files=baseline['files']-used['files']+64,directories=baseline['directories']-used['directories']+16,physical=baseline['physical']-used['physical']+1048576)
  q.put(ROOT/'launch-budget.json',q.wire(dict(non_suite_baseline=b,original_census=baseline,existing_suite=used,full_suite_cap=268435456,files=65536,directories=24576,physical=1572864000)))
  result=run(False)
  q.record(dict(event='full_regression_once_complete',head=F,result=result,inventory=q.census(),retry_remaining=0))
else:raise SystemExit('explicit preflight or run-once required')
