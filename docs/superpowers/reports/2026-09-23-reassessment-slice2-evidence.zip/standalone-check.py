"""Standalone captured-input recapture and Slice 2 admission, not semantic replay."""
import base64,json,tempfile,subprocess
from pathlib import Path
from dataclasses import asdict
from applications.bounded_decision_workflow.measurement_wire import key,sha
from applications.bounded_decision_workflow.measurement_contracts import canonical_json_bytes as wire
from applications.bounded_decision_workflow.reassessment_capture import capture
from applications.bounded_decision_workflow.reassessment_admission import admit
here=Path(__file__).parent
raw=(here/'candidate/P8-before-closure.json').read_bytes(); c=json.loads(raw)
root=Path(tempfile.mkdtemp(prefix='nr-slice2-standalone-')); objects=root/'objects';objects.mkdir()
for m in c['members']:
 b=base64.b64decode(m['bytes'],validate=True);r=m['reference'];assert sha(b)==r['sha256']
 (objects/(r['sha256']+'.'+r['kind'])).write_bytes(b)
 if r==c['invocation']:iv=b
(root/'invocation.json').write_bytes(iv)
g=capture(root/'invocation.json',objects,c['authority_pin']);a=admit(g)
assert g.closure_bytes==raw
previous=json.loads((here/'candidate/capture-work.json').read_bytes())['probes'][0]['admission']
assert json.loads(wire(asdict(a)))==previous
files=next(iter(g.prior_bundles.values()));assert sum(map(len,files.values()))==232849
out=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),root=str(root),scope='standalone structural recapture and public admission, not branch qualification or semantic reassessment replay',original_directory_supplied=False,objects=len(g.objects),same_closure_bytes=True,same_admission=True,recovered_files=[dict(name=n,bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())],logical=g.work.logical,physical=g.work.physical)
(here/'standalone-recovery.json').write_bytes(wire(out));print(wire(out).decode())
